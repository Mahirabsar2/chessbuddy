const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const K = require('../../app/src/main/assets/js/coaches.js');
const C = require('../../app/src/main/assets/js/clock.js');
const A = require('../../app/src/main/assets/js/avatars.js');
console.log('coaches.js + clock.js + avatars.js');
test('roster: at least 12 original coaches, unique ids, every tier has lines, valid avatar SVG', () => {
  assert.ok(K.COACHES.length >= 12 && K.byId('mittens')); assert.strictEqual(new Set(K.COACHES.map(c => c.id)).size, K.COACHES.length);
  K.COACHES.forEach(c => { ['top', 'good', 'book', 'slip', 'bad'].forEach(t => assert.ok(c.lines[t].length >= 2, c.id + ' ' + t)); assert.ok(/^<svg[\s\S]*<\/svg>$/.test(A.svg(c.av)), c.id); assert.ok(c.style.length > 30 && c.elo > 0); });
  assert.ok(K.COACHES.every(c => !/chess\.com|magnus|hikaru|levy|botez/i.test(JSON.stringify(c))), 'no third-party names');
});
test('comments name the move, the best move and the evaluation swing for bad classes', () => {
  const coach = K.byId('viktor');
  const bad = K.comment(coach, { ply: 5, san: 'Qh5', cls: 'blunder' }, { bestSan: 'Nf3', evBefore: '+0.3', evAfter: '-2.1' });
  assert.ok(/Qh5 is a blunder/.test(bad) && /Nf3 was best/.test(bad) && /\+0\.3 → -2\.1/.test(bad), bad);
  assert.ok(/brilliant/.test(K.comment(K.byId('rocco'), { ply: 9, san: 'Nxf7', cls: 'brilliant' }, {})));
  assert.ok(/book move in the Italian Game/.test(K.comment(coach, { ply: 3, san: 'Bc4', cls: 'book' }, { opening: 'Italian Game' })));
  assert.ok(/not analysed/.test(K.comment(coach, { ply: 1, san: 'e4', cls: null }, {})));
  ['brilliant', 'great', 'best', 'excellent', 'good', 'book', 'inaccuracy', 'mistake', 'miss', 'blunder'].forEach(cls => assert.ok(K.comment(K.byId('sam'), { ply: 2, san: 'e5', cls }, { bestSan: 'd5' }).includes('e5'), cls));
});
test('AI persona prompt keeps facts first and denies being a real person', () => {
  const p = K.systemFor(K.byId('zen'), 'BASE'); assert.ok(p.startsWith('BASE') && /Coach Zen/.test(p) && /never the chess facts/.test(p) && /not claim to be any real person/.test(p));
});
test('clock: starts after both sides moved, increments from move 2, flags the side that runs out', () => {
  const c = new C.Clock(C.byId('3+2')); assert.strictEqual(c.running, null);
  c.onMove('w', 1000); assert.strictEqual(c.running, null); c.onMove('b', 2000); assert.strictEqual(c.running, 'w');
  assert.strictEqual(c.tick(5000), null); assert.strictEqual(c.t.w, 180000 - 3000);
  c.onMove('w', 5000); assert.strictEqual(c.t.w, 180000 - 3000 + 2000); assert.strictEqual(c.running, 'b');
  assert.strictEqual(c.tick(5000 + 181000), 'b'); assert.strictEqual(c.t.b, 0); assert.strictEqual(c.running, null);
});
test('clock: hold() stops time while paused; serialize/restore round-trips; formatting', () => {
  const c = new C.Clock(C.byId('5+0')); c.onMove('w', 0); c.onMove('b', 10); c.hold(5000); c.tick(5100); assert.ok(300000 - c.t.w < 200);
  const r = C.restore(c.serialize()); assert.strictEqual(r.t.w, c.t.w); assert.strictEqual(r.running, 'w');
  assert.strictEqual(C.fmt(65000), '1:05'); assert.strictEqual(C.fmt(9400), '0:09.4'); assert.strictEqual(C.fmt(-5), '0:00.0'); assert.strictEqual(C.fmt(600000), '10:00');
});
test('time controls include untimed and common presets', () => { assert.strictEqual(C.byId('none').base, 0); assert.ok(C.TCS.length >= 8 && C.byId('zzz').id === 'none'); });
done('coaches.js + clock.js');
