const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const R = require('../../app/src/main/assets/js/review.js');
const O = require('../../app/src/main/assets/js/openings.js');
const { Chess } = require('../helpers/load-chessjs')();
console.log('review.js + openings.js');
const cp = v => ({ type: 'cp', value: v });
const hist = sans => { const g = new Chess(); sans.forEach(s => g.move(s)); return Array.from(g.history({ verbose: true })); };

test('thresholds follow chess.com expected-points bands', () => {
  assert.deepStrictEqual([0.01, 0.03, 0.08, 0.15, 0.3].map(R.tier), ['excellent', 'good', 'inaccuracy', 'mistake', 'blunder']);
  assert.ok(Math.abs(R.ep(cp(0)) - 0.5) < 1e-9 && R.ep({ type: 'mate', value: 3 }) === 1 && R.ep({ type: 'mate', value: -2 }) === 0);
});
test('accuracy and rating estimate are monotonic and bounded', () => {
  assert.ok(R.moveAccuracy(0.6, 0.6) > 99 && R.moveAccuracy(0.9, 0.2) < 8);
  assert.ok(R.ratingFromAccuracy(60) < R.ratingFromAccuracy(80) && R.ratingFromAccuracy(100) === 3000 && R.ratingFromAccuracy(0) === 250);
});
test('best / blunder from consecutive evaluations; per-side summary', () => {
  const h = hist(['e4', 'e5', 'Qh5']);
  const pos = [{ score: cp(30), best: 'e2e4' }, { score: cp(25), best: 'e7e5' }, { score: cp(20), best: 'g1f3' }, { score: cp(450), best: 'g8f6' }];
  const r = R.compute(h, pos);
  assert.strictEqual(r.rows[0].cls, 'best'); assert.strictEqual(r.rows[1].cls, 'best');
  assert.ok(['mistake', 'blunder'].includes(r.rows[2].cls), r.rows[2].cls); assert.ok(r.rows[2].loss > 0.1);
  assert.strictEqual(r.summary.b.counts.best, 1); assert.strictEqual(r.summary.w.moves, 2); assert.ok(r.summary.w.accuracy < r.summary.b.accuracy);
  assert.strictEqual(r.graph.length, 4);
});
test('Great: best move when the second-best line is much worse', () => {
  const h = hist(['e4']);
  const r = R.compute(h, [{ score: cp(60), best: 'e2e4', second: cp(-300) }, { score: cp(-50), best: 'e7e5' }]);
  assert.strictEqual(r.rows[0].cls, 'great');
  assert.strictEqual(R.compute(h, [{ score: cp(60), best: 'e2e4', second: cp(40) }, { score: cp(-50), best: 'e7e5' }]).rows[0].cls, 'best');
});
test('Brilliant: best move that is a sacrifice and not already winning; never when already crushing', () => {
  const h = hist(['e4']), pos = [{ score: cp(80), best: 'e2e4', second: cp(-200) }, { score: cp(-70), best: 'e7e5' }];
  assert.strictEqual(R.compute(h, pos, { isSacrifice: () => true }).rows[0].cls, 'brilliant');
  const crushing = [{ score: cp(1500), best: 'e2e4', second: cp(1400) }, { score: cp(-1400), best: 'e7e5' }];
  assert.notStrictEqual(R.compute(h, crushing, { isSacrifice: () => true }).rows[0].cls, 'brilliant');
});
test('Book overrides ordinary ratings for theory moves', () => {
  const h = hist(['e4']), pos = [{ score: cp(30), best: 'd2d4' }, { score: cp(-25), best: 'e7e5' }];
  assert.strictEqual(R.compute(h, pos, { isBook: () => true }).rows[0].cls, 'book');
});
test('Miss: opponent erred, you had a winning chance and missed it (plain Mistake without the opponent error)', () => {
  const h = hist(['f3', 'Nc6']);
  const pos = [{ score: cp(20), best: 'e2e4' },          // White to move
               { score: cp(400), best: 'e7e5' },         // after 1.f3 Black is much better (White blundered)
               { score: cp(100), best: 'e2e4' }];        // after 1...Nc6 White is only slightly worse for Black: Black threw the advantage away
  const r = R.compute(h, pos);
  assert.ok(['mistake', 'blunder'].includes(r.rows[0].cls)); assert.strictEqual(r.rows[1].cls, 'miss');
  const quiet = R.compute(h, [{ score: cp(20), best: 'f2f3' }, { score: cp(400), best: 'e7e5' }, { score: cp(100), best: 'e2e4' }]);   // 1.f3 was best: no opponent error
  assert.notStrictEqual(quiet.rows[1].cls, 'miss');
});
test('table for the AI lists every move with expected-point loss and the opening', () => {
  const h = hist(['e4', 'e5', 'Qh5']);
  const pos = [{ score: cp(30), best: 'e2e4' }, { score: cp(25), best: 'e7e5' }, { score: cp(20), best: 'g1f3' }, { score: cp(450), best: 'g8f6' }];
  const r = R.compute(h, pos), t = R.table(h, r, i => ({ 2: 'Nf3' }[i]), 'King’s Pawn Game');
  assert.ok(/Opening: King/.test(t) && /2\. Qh5 \(White\) — (Mistake|Blunder), lost [0-9.]+ expected points, best was Nf3/.test(t) && /Summary:/.test(t));
});
test('mate scores never produce NaN', () => {
  const h = hist(['f3', 'e5', 'g4', 'Qh4#']);
  const pos = [{ score: cp(0), best: 'e2e4' }, { score: cp(10), best: 'e7e5' }, { score: cp(0), best: 'e2e4' }, { score: { type: 'mate', value: 1 }, best: 'd8h4' }, { score: { type: 'mate', value: 0 }, best: null }];
  const r = R.compute(h, pos); assert.ok(r.rows.every(x => Number.isFinite(x.loss))); assert.ok(r.graph.every(Number.isFinite));
});
test('opening book: every line is legal chess, names resolve, book depth is detected', () => {
  O.LINES.forEach(([name, line]) => { const g = new Chess(); line.split(' ').forEach(m => { try { g.move(m); } catch (e) { throw new Error(name + ': illegal ' + m); } }); });
  assert.strictEqual(O.nameFor(['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6'], 8), 'Ruy Lopez, Morphy Defense');
  assert.strictEqual(O.nameFor(['d4', 'd5', 'c4', 'e6', 'Nc3'], 5), 'Queen’s Gambit Declined');
  assert.ok(O.inBook(['e4', 'c5', 'Nf3'], 3) && !O.inBook(['e4', 'c5', 'Qh5'], 3) && O.nameFor(['a3'], 1) === null);
});
done('review.js + openings.js');
