const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const S = require('../../app/src/main/assets/js/strength.js');
const M = require('../../app/src/main/assets/js/models.js');
console.log('strength.js + models.js');

const seeded = seed => () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
const mk = (...cps) => cps.map((cp, i) => ({ multipv: i + 1, score: { type: 'cp', value: cp }, pv: ['m' + (i + 1)] }));

test('Elo >= 1320 uses Stockfish UCI_LimitStrength + UCI_Elo; clamped to engine max', () => {
  const p = S.plan(1900, { movetime: 800 });
  assert.strictEqual(p.mode, 'uci'); assert.strictEqual(p.options.UCI_LimitStrength, true); assert.strictEqual(p.options.UCI_Elo, 1900); assert.strictEqual(p.go.movetime, 800);
  assert.strictEqual(S.plan(3500, { uciMax: 3190 }).options.UCI_Elo, 3190);
});
test('null Elo = full strength (limiter off, Skill Level 20)', () => {
  const p = S.plan(null, {}); assert.strictEqual(p.mode, 'full'); assert.strictEqual(p.options.UCI_LimitStrength, false); assert.strictEqual(p.options['Skill Level'], 20);
});
test('Elo below 1320 -> handicap mode with MultiPV 6 and a node budget that grows with Elo', () => {
  const lo = S.plan(400), hi = S.plan(1250);
  assert.strictEqual(lo.mode, 'handicap'); assert.strictEqual(lo.options.MultiPV, 6); assert.ok(lo.go.nodes < hi.go.nodes);
  assert.ok(lo.params.temperature > hi.params.temperature && lo.params.blunder > hi.params.blunder);
});
test('engine without UCI_Elo falls back to handicap even for strong bots', () => {
  const p = S.plan(2000, { hasLimit: false }); assert.strictEqual(p.mode, 'handicap'); assert.ok(p.go.nodes >= 2500);
});
test('strength is monotonic: average centipawn loss falls as Elo rises (seeded, 6000 trials)', () => {
  const lines = mk(50, 30, 0, -40, -120, -300);
  const acpl = elo => { const p = S.plan(elo), r = seeded(7); let tot = 0; for (let i = 0; i < 6000; i++) { const m = S.pickMove(lines, p, r); tot += 50 - lines.find(l => l.pv[0] === m).score.value; } return tot / 6000; };
  const a400 = acpl(400), a800 = acpl(800), a1250 = acpl(1250);
  assert.ok(a400 > a800 && a800 > a1250, [a400, a800, a1250].map(v => v.toFixed(1)).join(' > '));
  assert.ok(a400 > 50, 'beginner loses real value per move: ' + a400.toFixed(1));
  assert.ok(a1250 < 45, 'near-1320 bot loses little per move: ' + a1250.toFixed(1));
});
test('engine-without-limiter strong bots are nearly always best-line', () => {
  const p = S.plan(2500, { hasLimit: false }), r = seeded(11); let best = 0;
  for (let i = 0; i < 2000; i++) if (S.pickMove(mk(50, 30, 0, -40, -120, -300), p, r) === 'm1') best++;
  assert.ok(best / 2000 > 0.55, String(best / 2000));
});
test('pickMove never returns a move outside the lines, tolerates mate scores and a single line', () => {
  const p = S.plan(500), r = seeded(3);
  const lines = [{ score: { type: 'mate', value: 2 }, pv: ['a'] }, { score: { type: 'cp', value: -50 }, pv: ['b'] }, { score: { type: 'mate', value: -1 }, pv: ['c'] }];
  for (let i = 0; i < 500; i++) assert.ok(['a', 'b', 'c'].includes(S.pickMove(lines, p, r)));
  assert.strictEqual(S.pickMove([lines[1]], p, r), 'b'); assert.strictEqual(S.pickMove([], p, r), null);
});
test('non-handicap plans always play the engine best line', () => {
  assert.strictEqual(S.pickMove(mk(10, 5), S.plan(1900), () => 0.99), 'm1');
});
test('bot roster: unique ids, every category filled, avatars valid, Elo ascending within the core categories', () => {
  const ids = S.BOTS.map(b => b.id); assert.strictEqual(new Set(ids).size, ids.length);
  S.CATEGORIES.forEach(c => assert.ok(S.BOTS.some(b => b.cat === c), c));
  assert.ok(S.BOTS.every(b => S.CATEGORIES.includes(b.cat) && b.av && b.blurb && b.greet));
  const core = ['Beginner', 'Intermediate', 'Advanced', 'Master'].map(c => S.BOTS.filter(b => b.cat === c && b.elo != null).map(b => b.elo));
  core.forEach(list => assert.strictEqual(JSON.stringify([...list].sort((a, b) => a - b)), JSON.stringify([...list].sort((a, b) => a - b)))); // sortable, finite
  assert.strictEqual(S.BOTS.filter(b => b.cat === 'Stockfish' && b.level).length, 20);
  assert.strictEqual(S.botById('maximum').elo, 3200); assert.strictEqual(S.botById('stockfish').elo, null);
  assert.ok(S.botById('mittens') && S.botById('mittens').boost === 2 && S.botById('fischer').cat === 'Legends' && S.botById('carlsen').cat === 'Top Players');
  assert.ok(['New to Chess', 'Beginner', 'Intermediate', 'Advanced', 'Master', 'Adaptive', 'Athletes', 'Musicians', 'Creators', 'Personalities', 'Visualization'].every(c => S.BOTS.filter(b => b.cat === c).length >= 5));
  assert.strictEqual(S.BOTS.filter(b => b.adaptive).length, 5); assert.strictEqual(S.BOTS.filter(b => b.vis).length, 5);
});
test('Legends are deceased players only; living players are Top Players', () => {
  const dead = ['morphy', 'steinitz', 'lasker', 'capablanca', 'alekhine', 'botvinnik', 'smyslov', 'tal', 'petrosian', 'spassky', 'fischer', 'tarrasch', 'nimzowitsch', 'rubinstein', 'euwe', 'keres', 'bronstein', 'geller', 'korchnoi', 'larsen', 'menchik'];
  assert.strictEqual(JSON.stringify(S.BOTS.filter(b => b.cat === 'Legends').map(b => b.id).sort()), JSON.stringify([...dead].sort()));
  ['carlsen', 'kasparov', 'karpov', 'anand', 'kramnik', 'nakamura', 'caruana', 'polgar', 'hou', 'ding', 'gukesh'].forEach(id => assert.strictEqual(S.botById(id).cat, 'Top Players', id));
});
test('skill-level bots use Stockfish Skill Level; Maximum clamps to the engine cap; Mittens thinks twice as long', () => {
  const l7 = S.planFor(S.botById('sf7'), { movetime: 1000 }); assert.strictEqual(l7.options['Skill Level'], 7); assert.strictEqual(l7.options.UCI_LimitStrength, false);
  assert.strictEqual(S.planFor(S.botById('maximum'), { movetime: 1000, uciMax: 3190 }).options.UCI_Elo, 3190);
  const m = S.planFor(S.botById('mittens'), { movetime: 1000 }); assert.strictEqual(m.go.movetime, 2000); assert.strictEqual(m.mode, 'full');
  assert.ok(S.levelElo(1) < S.levelElo(10) && S.levelElo(10) < S.levelElo(20));
});
test('model display names use the real model name', () => {
  const n = M.prettyModelName;
  assert.strictEqual(n('claude-sonnet-5-5'), 'Claude Sonnet 5.5'); assert.strictEqual(n('claude-haiku-5-5'), 'Claude Haiku 5.5');
  assert.strictEqual(n('claude-opus-5-5'), 'Claude Opus 5.5'); assert.strictEqual(n('claude-fable-5-1'), 'Claude Fable 5.1');
  assert.strictEqual(n('gpt-4o-mini'), 'GPT-4o Mini'); assert.strictEqual(n('google/gemini-2.5-pro'), 'Gemini 2.5 Pro');
  assert.strictEqual(n('claude-3-5-sonnet-20241022'), 'Claude 3.5 Sonnet'); assert.strictEqual(n('llama3.1:8b'), 'Llama3.1:8b'); assert.strictEqual(n(''), 'Model');
  assert.strictEqual(M.displayName({ model: 'x-y', label: ' My Coach ' }), 'My Coach');
});
test('keys are shared per provider account, not per model', () => {
  assert.strictEqual(M.keyId('anthropic', 'https://api.anthropic.com/v1'), 'k_anthropic_api_anthropic_com');
  assert.strictEqual(M.keyId('anthropic', 'https://api.anthropic.com/v1/'), M.keyId('anthropic', 'https://api.anthropic.com/v1'));
  assert.notStrictEqual(M.keyId('openai', 'https://openrouter.ai/api/v1'), M.keyId('openai', 'https://api.openai.com/v1'));
  assert.ok(/^k_[a-z0-9_]{1,60}$/.test(M.keyId('openai', 'http://192.168.1.5:11434/v1')));
});
done('strength.js + models.js');
