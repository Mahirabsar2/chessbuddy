# ChessBuddy v0.4.0 — status

## Delivered
Everything in README.md: bot grid with 167 bots in 15 categories, Stockfish levels, Mittens, coaches, chess.com-style review, clocks, drag-and-drop, animations, sounds,
new game screen, settings that survive updates, backup/restore.

## Verified (actually run in the build sandbox)
- 70 logic tests: perft (5 positions), UCI client, provider requests/images, prompts + move parser, review model + opening book (all lines legal), strength/roster, coaches/clock.
- 34 UI tests in headless Chromium with a **test-only** mock Android bridge: first move as White/Black, strength options reaching the engine, drag and drop, immovable pieces, capture-square layout regression,
  captured pieces, figurines, eval bar, clocks, promotion, checkmate, undo/flip, hint, AI vs AI, engine crash/missing, export, screenshots in requests, AI-model players, review screen, coaches, bot grid,
  settings upgrade safety, backup/restore.
- All Java classes compile against Android API stubs; URL-safety policy passes 17 JVM cases.

## Not verified
Gradle/NDK build of this version (your GitHub run does it), behaviour on a real phone for the new features (sounds, haptics-free), real Stockfish strength calibration, real API calls from this sandbox.

## Ideas
Puzzles, lessons, premoves, board/piece themes, online play.
