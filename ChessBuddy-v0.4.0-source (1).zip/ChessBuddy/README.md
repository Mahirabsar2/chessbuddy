# ChessBuddy 0.4

A chess.com-style Android chess app with a **real Stockfish** engine, 167 bots, coaches, a chess.com-style Game Review, and AI models
(Claude and any OpenAI-compatible service) that can coach you or play against you.

**Build:** see `BUILD_ON_GITHUB.md` (upload this folder to your GitHub repo; Actions builds the APK). **Status:** `PROJECT_STATUS.md`.

## Play
- **Bots** screen like chess.com: greeting bubble, name + rating + flag, 5-column avatar grid, time-control + colour dock, big Play button.
  Categories: New to Chess, Beginner, Intermediate, Advanced, Master, **Adaptive** (gets stronger/gentler with your results), **Stockfish** (Levels 1–20, Maximum 3200, full strength),
  **Top Players** (living grandmasters), **Legends** (deceased players, e.g. Fischer, Morphy, Tal), Athletes, Musicians, Creators, Personalities, Characters (incl. **Mittens**), **Visualization** (hidden pieces). Crowns show your wins.
- Human vs bot / AI model, AI vs AI, pass-and-play. **Time controls** (1 min … 30 min, increments), clocks, low-time warning, timeout results.
- Game screen: **figurine move strip**, **evaluation bar on top** (or side/off), **captured pieces under the name** with material lead, Options / Analysis / Back / Forward bar, review earlier moves, takeback, hint, flip.
- **Drag and drop** (only pieces that can move can be picked up) or tap; animations (off/fast/medium/slow), sound effects, auto-queen, legal-move dots, last-move highlight, coordinates, white-always-on-bottom.

## Game Review (chess.com model)
Brilliant, Great, Best, Excellent, Good, Book, Inaccuracy, Mistake, Miss, Blunder from expected-points loss; accuracy per side, estimated performance, opening name,
evaluation graph, step-through with a badge on the board and a best-move arrow, Retry, and "Explain" with your AI model. Run it from **Analysis** or after any game.

## Coaches
12 original coaches (incl. Mittens) with their own wording for every rating, voice (optional), and a matching AI-chat style. Play against any coach at a chosen Elo.

## AI models
Models appear by name (Claude Sonnet 5.5 …); any OpenAI-compatible endpoint works. Prompts include the text board, FEN, every move explained, tactical facts, Stockfish lines, legal moves and a board screenshot.
Keys are Keystore-encrypted and never visible to JavaScript.

## Your data survives updates
Settings, models, progress, current game and archive are stored under stable keys and migrated, never reset. Android auto-backup is on (API keys are excluded by design).
Settings → Data → **Back up / Restore** exports models, settings and archive as text.

## Stockfish
Compiled in CI from the official source (`scripts/build_stockfish_android.sh`) and run as a child process over UCI. If it cannot start the app says so; it never fakes moves. Settings has a real on-device self-test.
Strength: UCI_Elo limiter, Skill Level for the Level bots, and a handicap mode for very low Elo.

## Not included
Puzzles, lessons, social/online play, premoves, and chess.com's own bots/coaches/artwork (they are licensed or trademarked; ChessBuddy ships original characters). Board/piece themes were intentionally not copied.

## Tests (not in the APK)
`node tests/run-all.js` (70 logic tests), `node tests/ui/ui.test.js` (34 browser tests with a test-only mock bridge), `tests/java/run.sh` (Java compile against stubs + URL policy).
