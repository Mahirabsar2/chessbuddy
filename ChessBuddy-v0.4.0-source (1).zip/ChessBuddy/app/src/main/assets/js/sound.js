/* ChessBuddy sound effects, synthesized with WebAudio (no audio files). Silent where WebAudio is unavailable. */
(function (root) {
  'use strict';
  var ac = null, master = null, enabled = true;
  function ctx() {
    try {
      if (!ac) {
        var C = root.AudioContext || root.webkitAudioContext;
        if (!C) return null;
        ac = new C(); master = ac.createGain(); master.gain.value = 0.7; master.connect(ac.destination);
      }
      if (ac.state === 'suspended') ac.resume();
      return ac;
    } catch (e) { return null; }
  }
  function noise(a, t, dur, freq, q, gain) {
    var n = Math.max(1, Math.floor(a.sampleRate * dur)), buf = a.createBuffer(1, n, a.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    var src = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain();
    src.buffer = buf; f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(master); src.start(t);
  }
  function tone(a, t, freq, dur, type, gain) {
    var o = a.createOscillator(), g = a.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02);
  }
  var S = {
    move: function (a, t) { noise(a, t, 0.07, 1100, 1.4, 0.55); tone(a, t, 180, 0.05, 'sine', 0.25); },
    capture: function (a, t) { noise(a, t, 0.1, 800, 1, 0.9); tone(a, t, 140, 0.1, 'sine', 0.45); },
    castle: function (a, t) { S.move(a, t); S.move(a, t + 0.1); },
    check: function (a, t) { S.move(a, t); tone(a, t + 0.03, 740, 0.1, 'triangle', 0.22); tone(a, t + 0.14, 988, 0.12, 'triangle', 0.22); },
    promote: function (a, t) { S.move(a, t); [523, 659, 784].forEach(function (f, i) { tone(a, t + 0.08 + i * 0.07, f, 0.12, 'triangle', 0.2); }); },
    start: function (a, t) { tone(a, t, 392, 0.12, 'triangle', 0.22); tone(a, t + 0.12, 523, 0.18, 'triangle', 0.22); },
    end: function (a, t) { [523, 392, 330].forEach(function (f, i) { tone(a, t + i * 0.16, f, 0.22, 'triangle', 0.25); }); },
    illegal: function (a, t) { tone(a, t, 120, 0.14, 'sawtooth', 0.15); },
    tick: function (a, t) { tone(a, t, 1500, 0.03, 'square', 0.08); }
  };
  root.CBSound = {
    setEnabled: function (b) { enabled = !!b; },
    unlock: function () { ctx(); },
    play: function (kind) { if (!enabled || !S[kind]) return; try { var a = ctx(); if (a) S[kind](a, a.currentTime); } catch (e) { /* ignore */ } }
  };
})(typeof window !== 'undefined' ? window : globalThis);
