/* ChessBuddy board renderer: one function draws any chess.js position into a host element.
 * Used by the Play board, the Coach mini-board and the History replay. */
(function (root) {
  'use strict';
  var FILES = 'abcdefgh';

  function build(host) {
    host.innerHTML = '';
    for (var i = 0; i < 64; i++) {
      var d = document.createElement('div');
      d.className = 'sq';
      d.setAttribute('role', 'gridcell');
      host.appendChild(d);
    }
  }

  function pieceName(p) {
    var n = { p: 'pawn', n: 'knight', b: 'bishop', r: 'rook', q: 'queen', k: 'king' }[p.type];
    return (p.color === 'w' ? 'white ' : 'black ') + n;
  }

  /**
   * o: { flipped, selected, legal:{sq:true}, captures:{sq:true}, last:{from,to}|null, check:sq|null,
   *      hint:{from,to}|null, coords:boolean }
   */
  function draw(host, chess, o) {
    o = o || {};
    if (host.children.length !== 64) build(host);
    var board = chess.board();
    var legal = o.legal || {}, caps = o.captures || {};
    for (var i = 0; i < 64; i++) {
      var r = Math.floor(i / 8), c = i % 8;
      var rank = o.flipped ? r : 7 - r;           // 0..7 -> rank 1..8
      var file = o.flipped ? 7 - c : c;
      var sq = FILES[file] + (rank + 1);
      var el = host.children[i];
      var p = board[7 - rank][file];
      var cls = 'sq ' + ((rank + file) % 2 === 0 ? 'dark' : 'light');
      if (o.selected === sq) cls += ' sel';
      if (o.last && (o.last.from === sq || o.last.to === sq)) cls += ' last';
      if (o.check === sq) cls += ' check';
      if (o.hint && (o.hint.from === sq || o.hint.to === sq)) cls += ' hint';
      if (legal[sq]) cls += caps[sq] ? ' capt' : ' legal';
      el.className = cls;
      el.setAttribute('data-sq', sq);
      var key = p ? p.color + p.type : '';
      if (el.getAttribute('data-pc') !== key) {
        el.setAttribute('data-pc', key);
        var old = el.querySelector('svg.pc');
        if (old) el.removeChild(old);
        if (p) {
          var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
          svg.setAttribute('class', 'pc'); svg.setAttribute('viewBox', '0 0 45 45');
          var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
          use.setAttributeNS('http://www.w3.org/1999/xlink', 'href', '#' + p.color + p.type.toUpperCase());
          use.setAttribute('href', '#' + p.color + p.type.toUpperCase());
          svg.appendChild(use); el.insertBefore(svg, el.firstChild);
        }
      }
      el.setAttribute('aria-label', sq + (p ? ', ' + pieceName(p) : ', empty'));
      var old = el.querySelector('span.mk'); if (old) el.removeChild(old);
      if (o.badge && o.badge.sq === sq) { var mk = document.createElement('span'); mk.className = 'mk'; mk.style.background = o.badge.color; mk.textContent = o.badge.text; el.appendChild(mk); }
      // coordinates: ranks on the left column, files on the bottom row
      var rk = el.querySelector('i.rk'), fl = el.querySelector('i.fl');
      var wantRk = o.coords !== false && c === 0, wantFl = o.coords !== false && r === 7;
      if (wantRk) { if (!rk) { rk = document.createElement('i'); rk.className = 'rk'; el.appendChild(rk); } rk.textContent = String(rank + 1); } else if (rk) el.removeChild(rk);
      if (wantFl) { if (!fl) { fl = document.createElement('i'); fl.className = 'fl'; el.appendChild(fl); } fl.textContent = FILES[file]; } else if (fl) el.removeChild(fl);
    }
  }

  /** Square of the king that is in check, or null. */
  function checkSquare(chess) {
    if (!chess.inCheck()) return null;
    var turn = chess.turn(), b = chess.board();
    for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++) {
      var p = b[r][c];
      if (p && p.type === 'k' && p.color === turn) return FILES[c] + (8 - r);
    }
    return null;
  }

  /** Draws a best-move arrow over a board (from/to squares); pass null to clear. */
  function arrow(host, from, to, flipped) {
    var wrap = host.parentNode, old = wrap.querySelector('svg.arrows'); if (old) wrap.removeChild(old);
    if (!from || !to) return;
    function c(sq) { var f = 'abcdefgh'.indexOf(sq[0]), r = +sq[1], col = flipped ? 7 - f : f, row = flipped ? r - 1 : 8 - r; return [(col + 0.5) * 12.5, (row + 0.5) * 12.5]; }
    var a = c(from), b = c(to), dx = b[0] - a[0], dy = b[1] - a[1], len = Math.sqrt(dx * dx + dy * dy) || 1, ux = dx / len, uy = dy / len;
    var tipX = b[0] - ux * 1.2, tipY = b[1] - uy * 1.2, baseX = tipX - ux * 4.2, baseY = tipY - uy * 4.2, px = -uy * 2.6, py = ux * 2.6;
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'arrows'); svg.setAttribute('viewBox', '0 0 100 100');
    svg.innerHTML = '<line x1="' + a[0] + '" y1="' + a[1] + '" x2="' + baseX + '" y2="' + baseY + '" stroke="rgba(129,182,76,.92)" stroke-width="2.6" stroke-linecap="round"/><polygon points="' + tipX + ',' + tipY + ' ' + (baseX + px) + ',' + (baseY + py) + ' ' + (baseX - px) + ',' + (baseY - py) + '" fill="rgba(129,182,76,.92)"/>';
    wrap.appendChild(svg);
  }
  root.CBBoard = { draw: draw, checkSquare: checkSquare, pieceName: pieceName, arrow: arrow };
})(window);
