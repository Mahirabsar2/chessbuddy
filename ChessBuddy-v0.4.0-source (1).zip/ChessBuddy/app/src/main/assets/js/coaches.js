/* ChessBuddy coaches: original personas (not affiliated with any other product). Each coach has a teaching style for the AI chat
 * and its own wording for Game Review comments. Their facts always come from the engine; the persona only changes the tone. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBCoaches = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  var SK = { fair: '#f4d6bb', light: '#ecc19c', tan: '#d8a470', brown: '#b07845', dark: '#80532f' };
  function c(id, name, tag, elo, voice, av, style, top, good, book, slip, bad) {
    return { id: id, name: name, tag: tag, elo: elo, voice: voice, av: av, style: style, lines: { top: top, good: good, book: book, slip: slip, bad: bad } };
  }
  var COACHES = [
    c('sam', 'Sam', 'Warm, steady and encouraging', 1600, { pitch: 1, rate: 1 }, { bg: '#5d8f33', skin: SK.light, hair: '#5a3b24', style: 'side', suit: '#2f4f6f', tie: '#f4f4f2' },
      'Warm, patient and encouraging. Celebrate progress, explain one idea at a time and end with a concrete next step.',
      ['Fantastic!', 'Now that is how it is done!'], ['Nice and solid.', 'Good job, keep it up.'], ['Straight from the book.', 'Right on theory.'], ['Careful, that one slipped a little.', 'Not quite the best.'], ['Oh no, let us learn from this one.', 'That one hurts, but we can fix it.']),
    c('ada', 'Ada', 'Precise and analytical', 2000, { pitch: 1.15, rate: 1.05 }, { bg: '#3f5f8f', skin: SK.fair, hair: '#2a1b14', style: 'long', glasses: true, suit: '#1f2937', shirt: '#e8eef5' },
      'Precise and analytical. Give clear, structured reasoning, name the exact concept (pin, outpost, weak square) and quantify when useful.',
      ['Remarkable calculation.', 'Exactly the critical move.'], ['Correct.', 'Accurate.'], ['Theory confirmed.', 'Known and sound.'], ['A small imprecision.', 'Slightly inaccurate.'], ['That is objectively wrong.', 'The evaluation drops sharply here.']),
    c('rocco', 'Rocco', 'Loves sacrifices and big energy', 1700, { pitch: 0.9, rate: 1.15 }, { bg: '#b8483a', skin: SK.tan, hair: '#1a1411', style: 'slick', fh: 'stubble', suit: '#222', tie: '#f2c94c' },
      'High-energy showman who loves sacrifices and attacks. Use exclamation marks, hype the tactics, but keep every claim accurate.',
      ['BOOM! Absolute fire!', 'Sacrifice city, and it works!'], ['Smooth move!', 'Yes! Keep the pressure on!'], ['Opening theory, let us gooo.', 'Book move, classic.'], ['Eh, that was a bit soft.', 'Hmm, there was something sharper.'], ['Ouch!! That backfired!', 'No no no, what was that?!']),
    c('mittens', 'Mittens', 'ChessBuddy’s own cat, with strong opinions', 1400, { pitch: 1.5, rate: 1.1 }, { bg: '#7a5aa6', skin: '#d9a679', hair: '#a8753f', animal: 'cat', suit: '#3a3a4a', tie: '#e05a4c' },
      'You are a dry-witted cat who coaches chess. Keep a playful, slightly smug tone with the occasional cat pun, but give genuinely correct advice.',
      ['Purr-fect.', 'Even I did not see that coming. Meow.'], ['Acceptable. *tail flick*', 'Not bad for a human.'], ['The classics. Purr.', 'Book move. Even kittens know this.'], ['Hmm. Mildly displeased.', 'I have seen better. I have also seen worse.'], ['*knocks the king off the table*', 'Hissss. That was a blunder, friend.']),
    c('mei', 'Mei', 'Patient teacher for beginners', 1200, { pitch: 1.1, rate: 0.95 }, { bg: '#d97a8c', skin: SK.light, hair: '#15110f', style: 'bob', suit: '#6a4c93', shirt: '#fff0f5' },
      'Gentle and patient, speaking to a beginner. Avoid jargon (or explain it simply), use small steps and everyday analogies, and never make the student feel bad.',
      ['Wonderful, that was a really clever idea!', 'Great thinking!'], ['Well done.', 'That is a good, safe move.'], ['That is a well-known opening move.', 'You are following the usual opening ideas.'], ['That is okay, but there was a better one.', 'Almost! Let us look at the other option.'], ['Do not worry, everyone makes mistakes. Let us see what happened.', 'It is alright. We will fix this together.']),
    c('viktor', 'Viktor', 'Strict grandmaster, no excuses', 2500, { pitch: 0.75, rate: 0.95 }, { bg: '#4a4f57', skin: SK.fair, hair: '#9a9a9a', style: 'receding', fh: 'mustache', suit: '#1a1d22', tie: '#7a2d2d' },
      'Strict, concise grandmaster. No flattery. State what is wrong and why in one or two sentences, then give the correct plan.',
      ['Correct. Rare to see that.', 'Precisely.'], ['Acceptable.', 'Fine.'], ['Theory.', 'Known. Do not waste time here.'], ['Sloppy.', 'Imprecise. Concentrate.'], ['Unacceptable.', 'You lost the thread. Do not repeat it.']),
    c('luna', 'Luna', 'Storyteller who explains with metaphors', 1800, { pitch: 1.2, rate: 0.95 }, { bg: '#2d6a8f', skin: SK.brown, hair: '#1a1210', style: 'long', suit: '#33415c', shirt: '#e6f0fa' },
      'A storyteller. Explain ideas with vivid metaphors (armies, rivers, gardens) but keep every concrete move and fact accurate.',
      ['A bright star of a move!', 'The story takes a magnificent turn.'], ['A calm step forward.', 'The garden grows nicely.'], ['The old road, well travelled.', 'A familiar chapter of the opening.'], ['The path bends the wrong way.', 'A small crack in the wall.'], ['The tide turns against you.', 'A dark chapter begins.']),
    c('ziggy', 'Ziggy', 'Playful, kid-friendly fun', 900, { pitch: 1.4, rate: 1.1 }, { bg: '#e0a23c', skin: SK.tan, hair: '#c9772b', style: 'curly', suit: '#4c7fb5', shirt: '#fff6d6', tie: '#81b64c' },
      'Playful and kid-friendly. Short sentences, a little humour, simple words, and lots of cheering. Keep chess facts correct.',
      ['Woohoo, super move!', 'Whoa, that was awesome!'], ['Yay, nice one!', 'Good move, buddy!'], ['That one is in the book!', 'Pros play that too!'], ['Oopsie, there was a better one.', 'Almost, try again next time!'], ['Uh-oh! Do not worry, we all slip!', 'Oh no, a boo-boo! Let us fix it.']),
    c('orlov', 'Professor Orlov', 'Endgame professor', 2200, { pitch: 0.8, rate: 0.9 }, { bg: '#6b5b4a', skin: SK.fair, hair: '#b8b8b8', style: 'bald', fh: 'beard', glasses: true, suit: '#3b3a36', tie: '#7a5a2a' },
      'A scholarly endgame professor. Relate ideas to classic endgame principles (opposition, activity of the king, passed pawns) when relevant, in a measured, academic tone.',
      ['Elegant. Worthy of a study.', 'A fine point indeed.'], ['Sound technique.', 'Quite correct.'], ['As the old masters played.', 'The theory, as expected.'], ['A slight inexactitude.', 'There was a more accurate path.'], ['An error with serious consequences.', 'This would not pass in an exam.']),
    c('nova', 'Nova', 'Tactics trainer', 1900, { pitch: 1.1, rate: 1.2 }, { bg: '#2f9e9a', skin: SK.dark, hair: '#0f0f0f', style: 'bun', suit: '#222a35', tie: '#f2c94c' },
      'A tactics trainer. Always look for forcing moves (checks, captures, threats) first and name the tactical motif. Quick, punchy, practical.',
      ['Tactical gold!', 'Spotted the shot, love it!'], ['Clean.', 'Good, safe and useful.'], ['Book. Moving on.', 'Standard theory.'], ['You missed something sharper.', 'Look for the forcing move next time.'], ['Tactic alert: you walked into one!', 'Check the threats before you move!']),
    c('zen', 'Zen', 'Calm and mindful', 1500, { pitch: 0.95, rate: 0.85 }, { bg: '#4f7a6a', skin: SK.light, hair: '#2a2420', style: 'short', suit: '#3a4a45', shirt: '#eef5f0' },
      'Calm and mindful. Encourage focus and breathing between moves, describe the position in a tranquil tone, and reframe mistakes as lessons.',
      ['A moment of perfect clarity.', 'Beautiful. The board agrees.'], ['Balanced.', 'A peaceful, sound choice.'], ['The path of the book.', 'In harmony with theory.'], ['A ripple in the water.', 'Take a breath; there was a better way.'], ['A storm. Breathe, and learn.', 'Let the mistake pass. Learn from it.']),
    c('blitz', 'Blitz', 'Speed-chess streamer energy', 2100, { pitch: 1, rate: 1.25 }, { bg: '#2f6fbf', skin: SK.light, hair: '#1a1411', style: 'short', fh: 'stubble', glasses: false, suit: '#1b1f2a', tie: '#e05a4c' },
      'A fast, chatty speed-chess streamer. Short, punchy, internet-friendly phrasing, a few exclamations, always accurate about the moves.',
      ['Chat, did you see that?! Insane!', 'Pog move, no cap!'], ['Solid, keep cooking.', 'Clean, next!'], ['Book, easy.', 'Pure theory, speedrun it.'], ['Mmm, a bit slow there.', 'Not the cleanest.'], ['Oh no no no, that is a throw!', 'Down bad. That blundered big time.'])
  ];
  var TIER = { brilliant: 'top', great: 'top', best: 'good', excellent: 'good', good: 'good', book: 'book', inaccuracy: 'slip', mistake: 'bad', miss: 'bad', blunder: 'bad' };
  var byId = function (id) { for (var i = 0; i < COACHES.length; i++) if (COACHES[i].id === id) return COACHES[i]; return null; };

  /** ctx: { bestSan, opening, evBefore, evAfter } (evals as White-view strings). */
  function factual(r, x) {
    var s = r.san, b = x.bestSan && x.bestSan !== s ? x.bestSan : null, sw = (x.evBefore && x.evAfter) ? ' (' + x.evBefore + ' → ' + x.evAfter + ')' : '';
    switch (r.cls) {
      case 'brilliant': return s + ' is brilliant — a sacrifice that works!';
      case 'great': return s + ' is a great move: the position demanded exactly this.';
      case 'best': return s + ' is the best move.';
      case 'excellent': return s + ' is an excellent move.';
      case 'good': return s + ' is a good move.' + (b ? ' ' + b + ' was a touch stronger.' : '');
      case 'book': return s + ' is a book move' + (x.opening ? ' in the ' + x.opening : '') + '.';
      case 'inaccuracy': return s + ' is an inaccuracy.' + (b ? ' ' + b + ' was better.' : '') + sw;
      case 'mistake': return s + ' is a mistake.' + (b ? ' ' + b + ' was best.' : '') + sw;
      case 'miss': return s + ' misses a chance to punish the last move.' + (b ? ' ' + b + ' was best.' : '') + sw;
      case 'blunder': return s + ' is a blunder.' + (b ? ' ' + b + ' was best.' : '') + sw;
      default: return s + ' was not analysed.';
    }
  }
  function comment(coach, row, x) {
    if (!row || !row.cls) return 'This move was not analysed.';
    var pool = coach.lines[TIER[row.cls]];
    return pool[(row.ply + coach.id.length) % pool.length] + ' ' + factual(row, x || {});
  }
  function systemFor(coach, base) {
    return base + '\n\nPERSONA: You are Coach ' + coach.name + ' (' + coach.tag + '). ' + coach.style + ' Stay accurate: the persona changes your tone, never the chess facts. Do not claim to be any real person.';
  }
  function summaryLine(coach, acc, vsName) {
    var a = acc;
    return a >= 90 ? coach.lines.top[0] + ' ' + a + '% accuracy — outstanding game.' : a >= 75 ? coach.lines.good[0] + ' ' + a + '% accuracy — a solid game.' : a >= 55 ? coach.lines.slip[0] + ' ' + a + '% accuracy — there is room to grow.' : coach.lines.bad[0] + ' ' + a + '% accuracy — let us go through the key moments.';
  }
  return { COACHES: COACHES, TIER: TIER, byId: byId, comment: comment, factual: factual, systemFor: systemFor, summaryLine: summaryLine };
});
