/* ChessBuddy strength control for Stockfish bots.
 *  - Elo >= engine minimum (1320): Stockfish's own calibrated limiter (UCI_LimitStrength + UCI_Elo).
 *  - Elo below that (or an engine without UCI_Elo): "handicap" mode. Stockfish still does the search
 *    (real engine, honest top lines) but with a small node budget, and the move is then chosen among its
 *    MultiPV lines with Elo-dependent randomness (softmax over centipawn loss + occasional slips).
 *  - Elo null: full strength. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBStrength = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  var clamp = function (x, a, b) { return Math.max(a, Math.min(b, x)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };

  function cpOf(score) {
    if (!score) return 0;
    if (score.type === 'cp') return score.value;
    return score.value > 0 ? 10000 - score.value : -10000 - score.value;
  }

  /** o: { movetime, uciMin, uciMax, hasLimit } -> { mode, options, go, multipv, params } */
  function plan(elo, o) {
    o = o || {};
    var movetime = o.movetime || 1000, uciMin = o.uciMin || 1320, uciMax = o.uciMax || 3190;
    var hasLimit = o.hasLimit !== false;
    if (elo == null) return { mode: 'full', elo: null, options: { UCI_LimitStrength: false, 'Skill Level': 20, MultiPV: 1 }, go: { movetime: movetime }, multipv: 1 };
    if (hasLimit && elo >= uciMin) {
      return { mode: 'uci', elo: Math.min(elo, uciMax), options: { UCI_LimitStrength: true, UCI_Elo: Math.min(elo, uciMax), 'Skill Level': 20, MultiPV: 1 }, go: { movetime: movetime }, multipv: 1 };
    }
    var t = clamp((elo - 200) / 1800, 0, 1);
    var nodes = Math.round(Math.exp(lerp(Math.log(30), Math.log(1800), t)));
    var strong = elo >= uciMin;                       // engine without UCI_Elo support
    var low = clamp((elo - 200) / (uciMin - 200), 0, 1), high = clamp((elo - uciMin) / (uciMax - uciMin), 0, 1);
    var params = strong
      ? { temperature: lerp(60, 10, high), blunder: lerp(0.04, 0, high), maxLoss: lerp(250, 60, high) }
      : { temperature: lerp(240, 60, low), blunder: lerp(0.3, 0.04, low), maxLoss: lerp(900, 250, low) };
    return {
      mode: 'handicap', elo: elo,
      options: { UCI_LimitStrength: false, 'Skill Level': 20, MultiPV: 6 },
      go: { nodes: strong ? Math.max(nodes, 2500) : nodes },
      multipv: 6,
      params: params
    };
  }

  /** lines: engine info lines (best first); returns the chosen line's first move (UCI). */
  function pickMove(lines, p, rng) {
    rng = rng || Math.random;
    var usable = (lines || []).filter(function (l) { return l && l.pv && l.pv.length && l.score; });
    if (!usable.length) return null;
    if (usable.length === 1 || !p || p.mode !== 'handicap') return usable[0].pv[0];
    var best = cpOf(usable[0].score);
    var cand = usable.map(function (l, i) { return { move: l.pv[0], loss: clamp(best - cpOf(l.score), 0, 5000), i: i }; })
      .filter(function (c) { return c.i === 0 || c.loss <= p.params.maxLoss; });
    if (cand.length > 1 && rng() < p.params.blunder) {
      var others = cand.slice(1);
      return others[Math.floor(rng() * others.length)].move;
    }
    var w = cand.map(function (c) { return Math.exp(-c.loss / p.params.temperature); });
    var sum = w.reduce(function (a, b) { return a + b; }, 0), r = rng() * sum;
    for (var i = 0; i < cand.length; i++) { r -= w[i]; if (r <= 0) return cand[i].move; }
    return cand[0].move;
  }

  /** Plan for a bot object: Stockfish "Skill Level" bots, boosted full-strength bots, otherwise the Elo plan. */
  function planFor(p, o) {
    o = o || {};
    var movetime = (o.movetime || 1000) * (p.boost || 1);
    if (p.level) return { mode: 'skill', elo: p.elo, options: { UCI_LimitStrength: false, 'Skill Level': p.level, MultiPV: 1 }, go: { movetime: movetime }, multipv: 1 };
    var pl = plan(p.elo, { movetime: movetime, uciMin: o.uciMin, uciMax: o.uciMax, hasLimit: o.hasLimit });
    return pl;
  }
  function levelElo(l) { return Math.round((1350 + (l - 1) * 100) / 50) * 50; }

  function category(elo) {
    if (elo == null) return 'Master';
    return elo < 1000 ? 'Beginner' : elo < 1700 ? 'Intermediate' : elo < 2400 ? 'Advanced' : 'Master';
  }

  /* Bot roster. Fictional characters; Stockfish skill levels; "Grandmasters" (living) and "Legends" (deceased) are famous players whose
   * NAMES are used as a tribute. Every bot is Stockfish limited to a target Elo (approximate peak rating or historical estimate); it does not
   * imitate the person's style, is not affiliated with or endorsed by them, and uses an original illustration. */
  var SK = { fair: '#f4d6bb', light: '#ecc19c', tan: '#d8a470', brown: '#b07845', dark: '#80532f', deep: '#5c3a22' };
  function bot(id, name, elo, cat, blurb, av) { return { id: id, name: name, elo: elo, cat: cat, blurb: blurb, av: av }; }
  var ROBOT = function (hue, accent) { return { animal: 'robot', bg: 'hsl(' + hue + ',38%,34%)', accent: accent || '#81b64c' }; };
  var BOTS = [
    bot('pip', 'Pip', 400, 'Beginner', 'Just learned the rules. Loves pushing pawns, forgets about defence.', { bg: '#7fb04a', skin: SK.light, hair: '#c9772b', style: 'curly', suit: '#4c7fb5', tie: '#f2c94c' }),
    bot('poppy', 'Poppy', 550, 'Beginner', 'Plays fast and loose and loves a surprise attack.', { bg: '#d66a8c', skin: SK.tan, hair: '#2b1d14', style: 'bun', suit: '#8e44ad', shirt: '#ffe8f0' }),
    bot('maple', 'Maple', 700, 'Beginner', 'Friendly and careless. Great for your first wins.', { bg: '#4f9d5d', skin: SK.fair, hair: '#8a4b25', style: 'bob', suit: '#2e7d5b' }),
    bot('biscuit', 'Biscuit', 850, 'Beginner', 'Cheerful, but sometimes forgets to protect the queen.', { bg: '#e0a23c', skin: SK.brown, hair: '#1f1a17', style: 'short', suit: '#b5462f', tie: '#fff' }),
    bot('sunny', 'Sunny', 1000, 'Intermediate', 'Knows the basics, still hangs pieces now and then.', { bg: '#e8c04a', skin: SK.light, hair: '#e3b23c', style: 'side', suit: '#3b6ea5' }),
    bot('cleo', 'Cleo', 1150, 'Intermediate', 'Loves bishops and long diagonals.', { bg: '#2f9e9a', skin: SK.dark, hair: '#1a1411', style: 'long', suit: '#7b3f8c' }),
    bot('quill', 'Quill', 1250, 'Intermediate', 'Plays sensible chess with the odd blunder.', { bg: '#8b5a3c', skin: SK.fair, hair: '#6b4a2b', style: 'slick', glasses: true, suit: '#33415c', tie: '#c0392b' }),
    bot('marlow', 'Marlow', 1500, 'Intermediate', 'A steady club player. Punishes loose pieces.', { bg: '#3c7a96', skin: SK.tan, hair: '#222', style: 'short', fh: 'stubble', suit: '#2b3a4a', tie: '#e0e6ea' }),
    bot('juno', 'Juno', 1750, 'Advanced', 'Solid tactics and decent endgames.', { bg: '#6b4a9e', skin: SK.light, hair: '#3a2a1c', style: 'bob', glasses: true, suit: '#222a3a' }),
    bot('atlas', 'Atlas', 2000, 'Advanced', 'Strong positional play. Rarely drops material.', { bg: '#a14b32', skin: SK.brown, hair: '#151515', style: 'bald', fh: 'beard', suit: '#1f2a36', tie: '#d9b44a' }),
    bot('rune', 'Rune', 2150, 'Advanced', 'Calm and patient. Waits for you to slip.', { bg: '#41697a', skin: SK.fair, hair: '#d8d0b8', style: 'long', fh: 'goatee', suit: '#2f3b45' }),
    bot('vega', 'Vega', 2300, 'Advanced', 'Expert level. Calculates deeply and converts advantages.', { bg: '#a33d78', skin: SK.tan, hair: '#1a1a1a', style: 'slick', suit: '#201f2e', tie: '#e8e8e8' }),
    bot('orion', 'Orion', 2600, 'Master', 'Master strength. Mistakes are very rare.', { bg: '#2d7f86', skin: SK.light, hair: '#8f8f8f', style: 'receding', fh: 'mustache', glasses: true, suit: '#1c2733' }),
    bot('titan', 'Titan', 2900, 'Master', 'Grandmaster-level pressure from move one.', { bg: '#5a3d8f', skin: SK.dark, hair: '#0f0f0f', style: 'bald', fh: 'stubble', suit: '#15151c', tie: '#c0392b' }),
    bot('stockfish', 'Stockfish 19', null, 'Stockfish', 'The full-strength engine. No limits.', ROBOT(140, '#81b64c')),
    bot('maximum', 'Maximum', 3200, 'Stockfish', 'The strongest limited setting: Stockfish held at 3200 Elo (or the engine’s own cap).', ROBOT(0, '#e05a4c'))
  ];
  for (var L = 1; L <= 20; L++) {
    BOTS.push({ id: 'sf' + L, name: 'Stockfish Level ' + L, elo: levelElo(L), level: L, cat: 'Stockfish', av: ROBOT(150 + L * 8, L > 14 ? '#e05a4c' : L > 7 ? '#f2c94c' : '#81b64c'),
      blurb: L === 20 ? 'Skill level 20 of 20: the engine at its strongest setting.' : 'Skill level ' + L + ' of 20 (about ' + levelElo(L) + ' Elo).' });
  }
  var GM = [
    bot('karpov', 'Anatoly Karpov', 2780, 'Top Players', 'World Champion 1975–85, a master of the positional squeeze.', { bg: '#4f6f6a', skin: SK.fair, hair: '#9a8466', style: 'side', suit: '#2a3340', tie: '#b3b8c0' }),
    bot('polgar', 'Judit Polgár', 2735, 'Top Players', 'Strongest female player in history, peak rating about 2735.', { bg: '#b04a6a', skin: SK.light, hair: '#2b1d14', style: 'long', suit: '#23303f' }),
    bot('hou', 'Hou Yifan', 2686, 'Top Players', 'Multiple-time Women’s World Champion.', { bg: '#a83d3d', skin: SK.light, hair: '#15110f', style: 'bob', suit: '#222831' }),
    bot('gukesh', 'Gukesh D', 2794, 'Top Players', 'World Champion since 2024, the youngest ever.', { bg: '#e07a2f', skin: SK.brown, hair: '#0f0f0f', style: 'short', suit: '#243447', tie: '#f2f2f2' }),
    bot('nakamura', 'Hikaru Nakamura', 2816, 'Top Players', 'US grandmaster and speed-chess specialist.', { bg: '#2f6fbf', skin: SK.light, hair: '#1a1411', style: 'short', fh: 'stubble', suit: '#212b3a' }),
    bot('kramnik', 'Vladimir Kramnik', 2817, 'Top Players', 'World Champion 2000–07, famous for the Berlin Wall.', { bg: '#5a6c7c', skin: SK.fair, hair: '#6e5a45', style: 'short', suit: '#222831', tie: '#2f4f7a' }),
    bot('anand', 'Viswanathan Anand', 2817, 'Top Players', 'World Champion 2007–13, famous for lightning-fast calculation.', { bg: '#d6a62f', skin: SK.brown, hair: '#2a2420', style: 'short', suit: '#2b3a55', tie: '#fff' }),
    bot('ding', 'Ding Liren', 2816, 'Top Players', 'World Champion 2023–24, the first from China.', { bg: '#b8483a', skin: SK.light, hair: '#0f0f0f', style: 'short', glasses: true, suit: '#232a35' }),
    bot('caruana', 'Fabiano Caruana', 2844, 'Top Players', 'US grandmaster, 2018 World Championship challenger.', { bg: '#3a5f9a', skin: SK.light, hair: '#2a2019', style: 'short', suit: '#1e2733', tie: '#c0392b' }),
    bot('kasparov', 'Garry Kasparov', 2851, 'Top Players', 'World Champion 1985–2000, peak rating 2851.', { bg: '#8b3a3a', skin: SK.fair, hair: '#1a1410', style: 'side', suit: '#1c1f26', tie: '#c9a43b' }),
    bot('carlsen', 'Magnus Carlsen', 2882, 'Top Players', 'World Champion 2013–23, the highest rating ever (2882).', { bg: '#2f7f9a', skin: SK.fair, hair: '#8a6a45', style: 'short', suit: '#1f2a38', tie: '#d8d8d8' })
  ];
  var LEGENDS = [
    bot('morphy', 'Paul Morphy', 2500, 'Legends', 'American prodigy, regarded as the unofficial world champion around 1858.', { bg: '#6b5b4a', skin: SK.fair, hair: '#1b1410', style: 'side', fh: 'mustache', suit: '#1e1e22', shirt: '#eee' }),
    bot('steinitz', 'Wilhelm Steinitz', 2450, 'Legends', 'The first official World Champion (1886–94).', { bg: '#5d5649', skin: SK.fair, hair: '#9a8f80', style: 'bald', fh: 'beard', suit: '#2a2a2e' }),
    bot('tarrasch', 'Siegbert Tarrasch', 2550, 'Legends', 'German theorist and teacher, a leading master of the early 1900s.', { bg: '#5b6470', skin: SK.fair, hair: '#6a6a6a', style: 'receding', fh: 'beard', glasses: true, suit: '#24272c' }),
    bot('lasker', 'Emanuel Lasker', 2550, 'Legends', 'World Champion for 27 years (1894–1921).', { bg: '#5a6670', skin: SK.fair, hair: '#8c8f93', style: 'receding', fh: 'mustache', suit: '#25282d' }),
    bot('nimzowitsch', 'Aron Nimzowitsch', 2600, 'Legends', 'Influential theorist and author of “My System”.', { bg: '#6a5a6a', skin: SK.fair, hair: '#2a2420', style: 'slick', fh: 'mustache', suit: '#26242a' }),
    bot('rubinstein', 'Akiba Rubinstein', 2600, 'Legends', 'Polish master famed for his rook endgames.', { bg: '#5a6a5a', skin: SK.light, hair: '#1f1a17', style: 'receding', suit: '#262826', tie: '#555' }),
    bot('euwe', 'Max Euwe', 2550, 'Legends', 'Dutch World Champion (1935–37) and a respected teacher.', { bg: '#7a6a3a', skin: SK.fair, hair: '#8f7a55', style: 'side', glasses: true, suit: '#2a2d33' }),
    bot('capablanca', 'José Raúl Capablanca', 2650, 'Legends', 'Cuban World Champion (1921–27), famed for clear, effortless play.', { bg: '#7a6a3a', skin: SK.light, hair: '#1c1612', style: 'slick', suit: '#d8d2c2', shirt: '#fff', tie: '#333' }),
    bot('alekhine', 'Alexander Alekhine', 2650, 'Legends', 'World Champion 1927–35 and 1937–46, a fearsome attacker.', { bg: '#4b5563', skin: SK.fair, hair: '#2a211b', style: 'slick', suit: '#22262e', tie: '#7a2d2d' }),
    bot('smyslov', 'Vasily Smyslov', 2670, 'Legends', 'World Champion 1957–58, known for harmonious, flowing chess.', { bg: '#52606b', skin: SK.light, hair: '#8f8f8f', style: 'side', glasses: true, suit: '#26303a' }),
    bot('petrosian', 'Tigran Petrosian', 2645, 'Legends', '“Iron Tigran”, World Champion 1963–69 and a master of defence.', { bg: '#6a4b3f', skin: SK.tan, hair: '#4a4a4a', style: 'receding', glasses: true, suit: '#222' }),
    bot('larsen', 'Bent Larsen', 2660, 'Legends', 'Danish grandmaster, aggressive and original.', { bg: '#4f6f8a', skin: SK.fair, hair: '#8a6a3a', style: 'side', fh: 'goatee', suit: '#2a313a' }),
    bot('geller', 'Efim Geller', 2680, 'Legends', 'Soviet grandmaster and a great opening theorist.', { bg: '#6a5050', skin: SK.light, hair: '#3a3a3a', style: 'receding', suit: '#2a2326' }),
    bot('spassky', 'Boris Spassky', 2690, 'Legends', 'World Champion 1969–72 with a universal, adaptable style.', { bg: '#546d82', skin: SK.fair, hair: '#d1b878', style: 'slick', suit: '#24303d', tie: '#4a6fa5' }),
    bot('korchnoi', 'Viktor Korchnoi', 2695, 'Legends', 'Fighting grandmaster, twice a World Championship challenger.', { bg: '#5a5a6a', skin: SK.fair, hair: '#8a8a8a', style: 'receding', glasses: true, suit: '#222228' }),
    bot('botvinnik', 'Mikhail Botvinnik', 2700, 'Legends', 'Soviet World Champion and a founder of the Soviet chess school.', { bg: '#7a3f3f', skin: SK.fair, hair: '#9b9b9b', style: 'receding', glasses: true, suit: '#2a2a2a', tie: '#7a2d2d' }),
    bot('keres', 'Paul Keres', 2700, 'Legends', 'Estonian grandmaster, the “eternal second” of the Candidates.', { bg: '#4a6a7a', skin: SK.fair, hair: '#2f2a25', style: 'slick', suit: '#23282f', tie: '#445' }),
    bot('bronstein', 'David Bronstein', 2700, 'Legends', 'Soviet grandmaster who drew the 1951 World Championship match.', { bg: '#6a4a5a', skin: SK.light, hair: '#2a2420', style: 'receding', fh: 'mustache', suit: '#2a2326' }),
    bot('tal', 'Mikhail Tal', 2705, 'Legends', '“The Magician from Riga”, World Champion 1960–61, a daring sacrificer.', { bg: '#7a4a8a', skin: SK.fair, hair: '#1d1612', style: 'side', suit: '#1f2230', shirt: '#eee' }),
    bot('menchik', 'Vera Menchik', 2350, 'Legends', 'The first Women’s World Champion (1927–44).', { bg: '#8a5a6a', skin: SK.fair, hair: '#3a2a1f', style: 'bob', suit: '#3a2f3a', shirt: '#f4eee8' }),
    bot('fischer', 'Bobby Fischer', 2785, 'Legends', 'American World Champion 1972–75, peak rating about 2785.', { bg: '#3d5f8f', skin: SK.fair, hair: '#3a2a1c', style: 'side', suit: '#1f2a3a', tie: '#9aa7b8' })
  ];
  var CHARACTERS = [
    bot('mittens', 'Mittens', null, 'Characters', 'ChessBuddy’s own cat: calm, smug and extremely hard to beat. Plays at full strength and thinks twice as long.', { bg: '#7a5aa6', skin: '#d9a679', hair: '#a8753f', animal: 'cat', suit: '#3a3a4a', tie: '#e05a4c' }),
    bot('captain', 'Captain Blunder', 500, 'Characters', 'Sails boldly into every trap. Delightfully reckless.', { bg: '#2f6f9a', skin: SK.tan, hair: '#2a1f18', style: 'short', fh: 'beard', suit: '#1c3a5a', tie: '#f2c94c' }),
    bot('rose', 'Grandma Rose', 1200, 'Characters', 'Patient, tidy and surprisingly tough in the endgame.', { bg: '#b46a8a', skin: SK.fair, hair: '#d8d8d8', style: 'bun', glasses: true, suit: '#6a3d6a', shirt: '#fff' }),
    bot('gambit', 'Doctor Gambit', 1850, 'Characters', 'Sacrifices a pawn before breakfast and a piece before lunch.', { bg: '#7a3d3d', skin: SK.light, hair: '#2a2a2a', style: 'slick', fh: 'goatee', glasses: true, suit: '#2a1f2f', tie: '#c0392b' }),
    bot('rex', 'Robo-Rex', 2400, 'Characters', 'A tireless tactics machine that never forgets a pin.', ROBOT(210, '#5aa0ff'))
  ];
  CHARACTERS[0].boost = 2;
  GM.sort(function (a, b) { return a.elo - b.elo; }); LEGENDS.sort(function (a, b) { return a.elo - b.elo; });
  /* ---- generated original characters, so every category has a full roster (deterministic: same ids/looks every run) ---- */
  function hashSeed(t) { var h = 2166136261; for (var i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { return function () { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; var t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function genSpec(id) {
    var r = rng(hashSeed(id));
    function pick(a) { return a[Math.floor(r() * a.length)]; }
    var style = pick(['short', 'side', 'slick', 'curly', 'bun', 'long', 'bob', 'receding', 'bald', 'short', 'side']);
    var fem = style === 'long' || style === 'bob' || style === 'bun';
    return { bg: 'hsl(' + Math.floor(r() * 360) + ',' + (30 + Math.floor(r() * 25)) + '%,' + (30 + Math.floor(r() * 12)) + '%)', skin: pick([SK.fair, SK.light, SK.tan, SK.brown, SK.dark, SK.deep]),
      hair: pick(['#1a1411', '#2b1d14', '#5a3b24', '#8a5a2b', '#c9772b', '#e3b23c', '#8f8f8f', '#d8d8d8', '#7a3b2e', '#3a5a8a']), style: style,
      fh: !fem && r() < 0.32 ? pick(['stubble', 'mustache', 'goatee', 'beard']) : 'none', glasses: r() < 0.22,
      suit: pick(['#2f3a4a', '#3b5a7a', '#5a3d6a', '#2e6a5a', '#7a3a3a', '#4a4a52', '#6a5a2e', '#2a4a6a']), tie: r() < 0.4 ? pick(['#c0392b', '#f2c94c', '#e8e8e8', '#81b64c', '#5aa0ff']) : null };
  }
  var NAMES = ('Aiden Amara Anya Arlo Asha Beck Bela Bram Cade Cara Cass Cyrus Dani Dara Dex Dina Edda Eli Elio Emi Enzo Esme Ezra Faye Finn Fola Gia Gus Hana Hugo Iris Ivo Jada Jai Jett Kali Kian Kira Kofi Lana Leo Lila Luca Maia Milo Mina Nadia Nico Nell Odin Olga Omar Opal Pax Pia Quin Rafa Remy Rhea Rio Rosa Saga Sami Seth Sia Taro Tess Theo Uma Vera Vic Wade Willa Xavi Yara Yuki Zane Zara Zeke Abel Ada Aldo Anika Axel Bea Boris Bruno Chloe Cleo2 Dario Dora Eddie Elsa Emil Erin Fabi Flora Gael Greta Hal Ines Ivy Jonas Joss Kai Karl Lars Lena Lior Mara Mateo Nia Noor Oleg Orla Pablo Petra Rudy Rona Sven Tilda Ugo Vera2 Wren Yosef Zoe Alma Bodhi Cato Dev Eira Ford Gwen Hari Ilan Jun Kato Lev Mika Neo Otto Priya Rani Sol Tove Uri Vita Wes Yan Zia').split(' ');
  var USED = {}; BOTS.concat(GM, LEGENDS, CHARACTERS).forEach(function (b) { USED[b.name.toLowerCase()] = 1; });
  NAMES = NAMES.filter(function (n) { return !USED[n.toLowerCase()] && !/\d/.test(n); });
  var nameIx = 0;
  var BLURBS = {
    'New to Chess': ['Learning how the pieces move. Very gentle.', 'Brand new to chess and happy to practise with you.', 'Still checking the rulebook between moves.', 'Plays slowly and leaves plenty of chances.'],
    'Beginner': ['Knows the rules, still misses simple threats.', 'Likes quick attacks and forgets to defend.', 'A friendly opponent for building confidence.', 'Plays natural moves with the occasional slip.'],
    'Intermediate': ['Solid fundamentals and a decent sense of tactics.', 'Develops quickly and looks for easy wins.', 'A club player: punishes loose pieces.', 'Good at attack, shaky in endgames.'],
    'Advanced': ['Strong tactician who rarely hangs material.', 'Plays principled, patient chess.', 'Converts small advantages with care.', 'Hard to surprise and quick to counterattack.'],
    'Master': ['Master-level technique and deep calculation.', 'Mistakes are rare and usually costly for you.', 'Squeezes every small imbalance.', 'Calm under pressure and ruthless in endgames.'],
    'Adaptive': ['Adapts to your results: wins make it stronger, losses make it gentler.', 'Learns your level and stays just out of reach.']
  };
  function gen(prefix, cat, count, minElo, maxElo, extra) {
    var out = [];
    for (var i = 0; i < count; i++) {
      var nm = NAMES[nameIx++ % NAMES.length], id = prefix + (i + 1), r = rng(hashSeed(id + 'b')), pool = BLURBS[cat] || BLURBS.Beginner;
      var b = bot(id, nm, count > 1 ? Math.round((minElo + (maxElo - minElo) * i / (count - 1)) / 10) * 10 : minElo, cat, pool[Math.floor(r() * pool.length)], genSpec(id));
      if (extra) extra(b, i);
      out.push(b);
    }
    return out;
  }
  function named(cat, list, minElo, maxElo, blurb) {
    return list.map(function (nm, i) {
      var id = cat.toLowerCase().replace(/[^a-z]/g, '') + (i + 1);
      return bot(id, nm, Math.round((minElo + (maxElo - minElo) * i / Math.max(1, list.length - 1)) / 10) * 10, cat, blurb, genSpec(id));
    });
  }
  var GENERATED = [].concat(
    gen('nc', 'New to Chess', 5, 250, 450),
    gen('bg', 'Beginner', 11, 500, 1050), gen('im', 'Intermediate', 11, 1100, 1700), gen('ad', 'Advanced', 16, 1800, 2400), gen('ms', 'Master', 8, 2500, 3050),
    gen('ap', 'Adaptive', 5, 600, 2200, function (b) { b.adaptive = true; b.blurb = 'Adapts to your results: wins make it stronger, losses make it gentler.'; }),
    named('Athletes', ['Sprinter Zoe', 'Slam-Dunk Dan', 'Goalie Gus', 'Surfer Kai', 'Boxer Bea', 'Skater Rio', 'Climber Tess', 'Rower Odd'], 600, 2000, 'A fictional sports star who brings the same energy to the chessboard.'),
    named('Musicians', ['DJ Rook', 'Melody', 'Banjo Bill', 'Opera Olga', 'Drummer Dax', 'Synth Sia'], 700, 1900, 'A fictional musician who plays chess to a steady beat.'),
    named('Creators', ['StreamKnight', 'PixelPete', 'ClipQueen', 'VlogVic', 'Podcast Pam', 'Shorts Sami', 'ReelRita', 'GameGuru', 'Chat Charlie', 'Hype Harper'], 800, 2300, 'A fictional online creator who narrates every move to chat.'),
    named('Personalities', ['Baron von Pawn', 'Chef Luigi', 'Sleepy Sam', 'Detective Dara', 'Wizard Wynn', 'Pirate Pearl', 'Astro Ace', 'Farmer Fen', 'Sir Knightly'], 500, 2200, 'A quirky character with a very particular way of playing.')
  );
  var VIS = [0, 1, 2, 3, 4].map(function (i) {
    var names = ['Peek', 'Fade', 'Shadow', 'Ghost', 'Blindfold'], hints = ['Pieces vanish a few seconds after every move.', 'Pieces fade almost at once. Keep the board in your head.', 'Your opponent’s pieces are hidden.', 'Your own pieces are hidden.', 'No pieces at all. Pure visualization.'];
    var b = bot('vis' + (i + 1), 'Visualization: ' + names[i], 1000 + i * 150, 'Visualization', hints[i], { bg: 'hsl(' + (200 + i * 25) + ',35%,32%)', skin: SK.light, hair: '#1f1a17', style: 'short', fh: 'beard', suit: '#7a4a32', blind: i < 2 ? 1 : 2 });
    b.vis = i + 1; return b;
  });
  var FLAGS = { carlsen: '🇳🇴', fischer: '🇺🇸', morphy: '🇺🇸', nakamura: '🇺🇸', caruana: '🇺🇸', capablanca: '🇨🇺', tal: '🇱🇻', anand: '🇮🇳', gukesh: '🇮🇳', ding: '🇨🇳', hou: '🇨🇳', polgar: '🇭🇺', euwe: '🇳🇱', larsen: '🇩🇰', keres: '🇪🇪', lasker: '🇩🇪', tarrasch: '🇩🇪' };
  BOTS = BOTS.concat(GM, LEGENDS, CHARACTERS, GENERATED, VIS);
  BOTS.forEach(function (b) { if (FLAGS[b.id]) b.flag = FLAGS[b.id]; b.greet = 'Hi, I’m ' + b.name + '.'; });
  BOTS.find = BOTS.find || function (f) { for (var i = 0; i < this.length; i++) if (f(this[i])) return this[i]; return null; };
  BOTS.forEach(function (b) { if (b.id === 'mittens') b.greet = 'Meow. (That means: let’s play.)'; });
  var CATEGORIES = ['New to Chess', 'Beginner', 'Intermediate', 'Advanced', 'Master', 'Adaptive', 'Stockfish', 'Top Players', 'Legends', 'Athletes', 'Musicians', 'Creators', 'Personalities', 'Characters', 'Visualization'];
  var botById = function (id) { for (var i = 0; i < BOTS.length; i++) if (BOTS[i].id === id) return BOTS[i]; return null; };

  return { plan: plan, planFor: planFor, levelElo: levelElo, pickMove: pickMove, category: category, cpOf: cpOf, BOTS: BOTS, CATEGORIES: CATEGORIES, botById: botById };
});
