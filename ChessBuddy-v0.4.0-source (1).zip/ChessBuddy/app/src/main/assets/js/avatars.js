/* ChessBuddy avatar illustrations: original flat-style portraits generated from a small spec (no photos, no licensed artwork). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBAvatars = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  var SKIN = { fair: '#f4d6bb', light: '#ecc19c', tan: '#d8a470', brown: '#b07845', dark: '#80532f', deep: '#5c3a22' };
  var DEFAULTS = { bg: '#5d8f33', skin: SKIN.light, hair: '#2b1d14', style: 'short', fh: 'none', glasses: false, suit: '#2f3a4a', shirt: '#f4f4f2', tie: null, brow: null };

  function hairBack(s, hair) {
    if (s === 'long') return '<path d="M17.5 31 C13.5 11 50.5 11 46.5 31 L49 52 L15 52 Z" fill="' + hair + '"/>';
    if (s === 'bob') return '<path d="M18 32 C15 12 49 12 46 32 L45.5 41 L18.5 41 Z" fill="' + hair + '"/>';
    return '';
  }
  function hairFront(s, hair) {
    var short = '<path d="M20 28 C18.6 15 26 11 32 11 C38 11 45.4 15 44 28 C42.6 22.5 39.5 19.6 32 19.6 C24.5 19.6 21.4 22.5 20 28 Z" fill="' + hair + '"/>';
    switch (s) {
      case 'bald': return '<path d="M20.2 27 C19 22 20.5 20 22 19.5 C21.5 22 21.8 25 22.2 28 Z" fill="' + hair + '"/><path d="M43.8 27 C45 22 43.5 20 42 19.5 C42.5 22 42.2 25 41.8 28 Z" fill="' + hair + '"/><ellipse cx="29" cy="17.5" rx="4" ry="1.6" fill="#fff" opacity=".2"/>';
      case 'receding': return '<path d="M20 28 C19 17 25 15 32 15 C39 15 45 17 44 28 C42 24 39 22.5 32 22.5 C25 22.5 22 24 20 28 Z" fill="' + hair + '"/>';
      case 'side': return '<path d="M20 28 C18 14 27 10.5 33 11 C40 11.5 46 16 44 28 C42 21 38 18 30 19 C25 19.5 22 23 20 28 Z" fill="' + hair + '"/><path d="M26 17.5 C31 14.5 38 15.5 42 20" stroke="#fff" stroke-opacity=".18" stroke-width="1.4" fill="none"/>';
      case 'slick': return '<path d="M20.5 27 C19 14 27 10.5 32 10.8 C38 10.8 45.5 14 43.5 27 C41 20 24 20 20.5 27 Z" fill="' + hair + '"/><path d="M24 15 C29 12.5 36 12.5 41 16" stroke="#fff" stroke-opacity=".22" stroke-width="1.3" fill="none"/>';
      case 'curly': return '<g fill="' + hair + '"><circle cx="23" cy="17.5" r="5"/><circle cx="28.5" cy="13.5" r="5"/><circle cx="35.5" cy="13.5" r="5"/><circle cx="41" cy="17.5" r="5"/><circle cx="21.5" cy="23.5" r="4"/><circle cx="42.5" cy="23.5" r="4"/></g>' + short;
      case 'bun': return '<circle cx="32" cy="8.8" r="4.6" fill="' + hair + '"/>' + short;
      default: return short;       // short, long, bob use the same fringe
    }
  }
  function facialHair(f, hair) {
    var must = '<path d="M26.5 35.2 Q29.5 33.4 32 35 Q34.5 33.4 37.5 35.2 Q34.5 37.2 32 36 Q29.5 37.2 26.5 35.2Z" fill="' + hair + '"/>';
    if (f === 'mustache') return must;
    if (f === 'beard') return '<path d="M20.6 31 C20 42.5 26 48 32 48 C38 48 44 42.5 43.4 31 C42 36 38.5 38.8 32 38.8 C25.5 38.8 22 36 20.6 31 Z" fill="' + hair + '"/>' + must;
    if (f === 'goatee') return '<path d="M29 39 C29.5 44.5 34.5 44.5 35 39 C33.5 41 30.5 41 29 39Z" fill="' + hair + '"/>' + must;
    if (f === 'stubble') return '<path d="M20.8 32 C21 41.5 26 45 32 45 C38 45 43 41.5 43.2 32 C41 38 37 40.5 32 40.5 C27 40.5 23 38 20.8 32Z" fill="' + hair + '" opacity=".28"/>';
    return '';
  }

  function robot(s) {
    var d = s.suit || '#2f3a4a', a = s.accent || '#81b64c';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" aria-hidden="true"><rect width="64" height="64" fill="' + s.bg + '"/><circle cx="32" cy="20" r="30" fill="#fff" opacity=".09"/>' +
      '<path d="M32 9 L32 16" stroke="#d8dee4" stroke-width="2.4" stroke-linecap="round"/><circle cx="32" cy="8" r="3" fill="' + a + '"/>' +
      '<path d="M6 64 C6 52 16 48 28 47 L36 47 C48 48 58 52 58 64Z" fill="' + d + '"/><rect x="26" y="40" width="12" height="8" fill="#9aa5b1"/>' +
      '<rect x="15" y="15" width="34" height="27" rx="8" fill="#e3e8ed"/><rect x="19" y="21" width="26" height="12" rx="6" fill="#1b2430"/>' +
      '<circle cx="26.5" cy="27" r="3.2" fill="' + a + '"/><circle cx="37.5" cy="27" r="3.2" fill="' + a + '"/><path d="M26 37 L38 37" stroke="#8b96a3" stroke-width="2" stroke-linecap="round"/>' +
      '<rect x="11" y="23" width="4" height="10" rx="2" fill="#aab4be"/><rect x="49" y="23" width="4" height="10" rx="2" fill="#aab4be"/></svg>';
  }

  /** spec: { bg, skin, hair, style: short|side|slick|bald|receding|curly|bun|long|bob, fh: none|mustache|beard|goatee|stubble, glasses, suit, shirt, tie, brow } */
  function svg(spec) {
    var s = {}, k;
    for (k in DEFAULTS) s[k] = DEFAULTS[k];
    for (k in (spec || {})) if (spec[k] !== undefined) s[k] = spec[k];
    var brow = s.brow || s.hair, p = [], cat = s.animal === 'cat';
    if (s.animal === 'robot') return robot(s);
    p.push('<rect width="64" height="64" fill="' + s.bg + '"/><circle cx="32" cy="20" r="30" fill="#fff" opacity=".09"/>');
    if (cat) p.push('<path d="M20 22 L21 7 L31 15 Z" fill="' + s.skin + '"/><path d="M44 22 L43 7 L33 15 Z" fill="' + s.skin + '"/><path d="M22.5 18 L22.8 11.5 L27.5 15.5 Z" fill="#e8a0a8"/><path d="M41.5 18 L41.2 11.5 L36.5 15.5 Z" fill="#e8a0a8"/>');
    else p.push(hairBack(s.style, s.hair));
    p.push('<path d="M5 64 C5 52 15 47 27 46 L37 46 C49 47 59 52 59 64 Z" fill="' + s.suit + '"/>');
    p.push('<path d="M27.5 36 L36.5 36 L37 47 L27 47 Z" fill="' + s.skin + '"/><path d="M27.5 41 L36.5 41 L36.7 44 C33 46 31 46 27.3 44Z" fill="#000" opacity=".1"/>');
    p.push('<path d="M26 46 L32 56 L38 46 Z" fill="' + s.shirt + '"/>');
    if (s.tie) p.push('<path d="M30.4 50.5 L33.6 50.5 L34.6 62 L32 64 L29.4 62 Z" fill="' + s.tie + '"/>');
    p.push('<ellipse cx="20.3" cy="30" rx="2.2" ry="3.2" fill="' + s.skin + '"/><ellipse cx="43.7" cy="30" rx="2.2" ry="3.2" fill="' + s.skin + '"/>');
    p.push('<ellipse cx="32" cy="29" rx="11.6" ry="13.6" fill="' + s.skin + '"/>');
    if (!cat) p.push(hairFront(s.style, s.hair));
    else p.push('<path d="M32 14 L32 20 M27 15 L28.5 20 M37 15 L35.5 20" stroke="' + s.hair + '" stroke-width="2" stroke-linecap="round" opacity=".55"/>');
    p.push('<path d="M24.3 25.6 Q27.5 23.8 30.6 25.2 M33.4 25.2 Q36.5 23.8 39.7 25.6" stroke="' + brow + '" stroke-width="1.7" fill="none" stroke-linecap="round"/>');
    p.push('<ellipse cx="27.5" cy="29" rx="1.5" ry="1.8" fill="#1d1a17"/><ellipse cx="36.5" cy="29" rx="1.5" ry="1.8" fill="#1d1a17"/><circle cx="28" cy="28.4" r=".5" fill="#fff"/><circle cx="37" cy="28.4" r=".5" fill="#fff"/>');
    p.push('<path d="M32 30 Q30.8 34 32.8 34.7" stroke="#000" stroke-opacity=".28" stroke-width="1.2" fill="none" stroke-linecap="round"/>');
    p.push('<path d="M28.6 38.2 Q32 40.8 35.4 38.2" stroke="#7a3b32" stroke-width="1.5" fill="none" stroke-linecap="round"/>');
    if (cat) p.push('<path d="M30.3 32.2 L33.7 32.2 L32 34.2 Z" fill="#e8a0a8"/><path d="M24 34 L14 32.5 M24 36 L14 37 M40 34 L50 32.5 M40 36 L50 37" stroke="#fff" stroke-opacity=".85" stroke-width=".9" fill="none" stroke-linecap="round"/>');
    else p.push(facialHair(s.fh, s.hair));
    if (s.blind === 1) p.push('<ellipse cx="27.5" cy="29" rx="4.6" ry="4" fill="#1d1d1d"/><path d="M22.5 24.5 L41.5 33" stroke="#1d1d1d" stroke-width="1.6"/>');
    if (s.blind === 2) p.push('<rect x="19" y="25.2" width="26" height="7.6" rx="2" fill="#5aa84a"/><path d="M45 27 L50 24.5 M45 30.5 L50.5 32" stroke="#5aa84a" stroke-width="2.4" stroke-linecap="round"/>');
    if (s.glasses) p.push('<g fill="none" stroke="#222" stroke-width="1.3"><circle cx="27.5" cy="29" r="4.7"/><circle cx="36.5" cy="29" r="4.7"/><path d="M32.2 28.6 L31.8 28.6 M22.8 28.4 L20.6 27.4 M41.2 28.4 L43.4 27.4"/></g>');
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" aria-hidden="true">' + p.join('') + '</svg>';
  }
  return { svg: svg, SKIN: SKIN };
});
