/* ChessBuddy opening book: common named lines (SAN). Used by Game Review for "Book" moves and the opening name. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBOpenings = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  var L = [
    ['King’s Pawn Game', 'e4 e5'], ['Italian Game', 'e4 e5 Nf3 Nc6 Bc4'], ['Giuoco Piano', 'e4 e5 Nf3 Nc6 Bc4 Bc5'],
    ['Giuoco Piano, Main Line', 'e4 e5 Nf3 Nc6 Bc4 Bc5 c3 Nf6 d3'], ['Evans Gambit', 'e4 e5 Nf3 Nc6 Bc4 Bc5 b4'],
    ['Two Knights Defense', 'e4 e5 Nf3 Nc6 Bc4 Nf6'], ['Fried Liver Attack', 'e4 e5 Nf3 Nc6 Bc4 Nf6 Ng5 d5 exd5 Nxd5 Nxf7'],
    ['Ruy Lopez', 'e4 e5 Nf3 Nc6 Bb5'], ['Ruy Lopez, Morphy Defense', 'e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6'],
    ['Ruy Lopez, Closed', 'e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7 Re1 b5 Bb3 d6 c3 O-O'], ['Ruy Lopez, Berlin Defense', 'e4 e5 Nf3 Nc6 Bb5 Nf6'],
    ['Ruy Lopez, Exchange Variation', 'e4 e5 Nf3 Nc6 Bb5 a6 Bxc6'], ['Scotch Game', 'e4 e5 Nf3 Nc6 d4 exd4 Nxd4'], ['Scotch Gambit', 'e4 e5 Nf3 Nc6 d4 exd4 Bc4'],
    ['Four Knights Game', 'e4 e5 Nf3 Nc6 Nc3 Nf6'], ['Ponziani Opening', 'e4 e5 Nf3 Nc6 c3'], ['Petrov’s Defense', 'e4 e5 Nf3 Nf6'],
    ['Petrov’s Defense, Classical', 'e4 e5 Nf3 Nf6 Nxe5 d6 Nf3 Nxe4'], ['Philidor Defense', 'e4 e5 Nf3 d6'], ['Elephant Gambit', 'e4 e5 Nf3 d5'],
    ['Latvian Gambit', 'e4 e5 Nf3 f5'], ['Vienna Game', 'e4 e5 Nc3'], ['Bishop’s Opening', 'e4 e5 Bc4'], ['King’s Gambit', 'e4 e5 f4'],
    ['King’s Gambit Accepted', 'e4 e5 f4 exf4'], ['King’s Gambit Declined', 'e4 e5 f4 Bc5'], ['Danish Gambit', 'e4 e5 d4 exd4 c3'], ['Center Game', 'e4 e5 d4 exd4 Qxd4'],
    ['Sicilian Defense', 'e4 c5'], ['Sicilian Defense, Open', 'e4 c5 Nf3 d6 d4 cxd4 Nxd4'], ['Sicilian Defense, Najdorf', 'e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6'],
    ['Sicilian Defense, Dragon', 'e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6'], ['Sicilian Defense, Scheveningen', 'e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 e6'],
    ['Sicilian Defense, Classical', 'e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 d6'], ['Sicilian Defense, Sveshnikov', 'e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 e5'],
    ['Sicilian Defense, Taimanov', 'e4 c5 Nf3 e6 d4 cxd4 Nxd4 Nc6'], ['Sicilian Defense, Kan', 'e4 c5 Nf3 e6 d4 cxd4 Nxd4 a6'], ['Sicilian Defense, Alapin', 'e4 c5 c3'],
    ['Sicilian Defense, Closed', 'e4 c5 Nc3'], ['Sicilian Defense, Smith-Morra Gambit', 'e4 c5 d4 cxd4 c3'], ['Sicilian Defense, Grand Prix Attack', 'e4 c5 Nc3 Nc6 f4'],
    ['French Defense', 'e4 e6'], ['French Defense, Advance', 'e4 e6 d4 d5 e5'], ['French Defense, Exchange', 'e4 e6 d4 d5 exd5'], ['French Defense, Tarrasch', 'e4 e6 d4 d5 Nd2'],
    ['French Defense, Winawer', 'e4 e6 d4 d5 Nc3 Bb4'], ['French Defense, Classical', 'e4 e6 d4 d5 Nc3 Nf6'], ['Caro-Kann Defense', 'e4 c6'],
    ['Caro-Kann Defense, Advance', 'e4 c6 d4 d5 e5'], ['Caro-Kann Defense, Classical', 'e4 c6 d4 d5 Nc3 dxe4 Nxe4 Bf5'], ['Caro-Kann Defense, Exchange', 'e4 c6 d4 d5 exd5 cxd5'],
    ['Caro-Kann Defense, Panov Attack', 'e4 c6 d4 d5 exd5 cxd5 c4'], ['Pirc Defense', 'e4 d6 d4 Nf6 Nc3 g6'], ['Modern Defense', 'e4 g6'], ['Alekhine’s Defense', 'e4 Nf6'],
    ['Scandinavian Defense', 'e4 d5'], ['Scandinavian Defense, Main Line', 'e4 d5 exd5 Qxd5 Nc3 Qa5'], ['Scandinavian Defense, Modern', 'e4 d5 exd5 Nf6'],
    ['Nimzowitsch Defense', 'e4 Nc6'], ['Owen’s Defense', 'e4 b6'], ['Queen’s Pawn Game', 'd4 d5'], ['Queen’s Gambit', 'd4 d5 c4'], ['Queen’s Gambit Accepted', 'd4 d5 c4 dxc4'],
    ['Queen’s Gambit Declined', 'd4 d5 c4 e6'], ['Queen’s Gambit Declined, Orthodox', 'd4 d5 c4 e6 Nc3 Nf6 Bg5 Be7'], ['Queen’s Gambit Declined, Exchange', 'd4 d5 c4 e6 Nc3 Nf6 cxd5 exd5'],
    ['Slav Defense', 'd4 d5 c4 c6'], ['Semi-Slav Defense', 'd4 d5 c4 c6 Nf3 Nf6 Nc3 e6'], ['Tarrasch Defense', 'd4 d5 c4 e6 Nc3 c5'], ['Albin Counter-Gambit', 'd4 d5 c4 e5'],
    ['Chigorin Defense', 'd4 d5 c4 Nc6'], ['Indian Defense', 'd4 Nf6'], ['King’s Indian Defense', 'd4 Nf6 c4 g6 Nc3 Bg7'], ['King’s Indian Defense, Classical', 'd4 Nf6 c4 g6 Nc3 Bg7 e4 d6 Nf3 O-O Be2'],
    ['King’s Indian Defense, Sämisch', 'd4 Nf6 c4 g6 Nc3 Bg7 e4 d6 f3'], ['Grünfeld Defense', 'd4 Nf6 c4 g6 Nc3 d5'], ['Nimzo-Indian Defense', 'd4 Nf6 c4 e6 Nc3 Bb4'],
    ['Queen’s Indian Defense', 'd4 Nf6 c4 e6 Nf3 b6'], ['Bogo-Indian Defense', 'd4 Nf6 c4 e6 Nf3 Bb4'], ['Catalan Opening', 'd4 Nf6 c4 e6 g3'], ['Benoni Defense', 'd4 Nf6 c4 c5 d5'],
    ['Benko Gambit', 'd4 Nf6 c4 c5 d5 b5'], ['Old Indian Defense', 'd4 Nf6 c4 d6'], ['Budapest Gambit', 'd4 Nf6 c4 e5'], ['Dutch Defense', 'd4 f5'], ['Englund Gambit', 'd4 e5'],
    ['London System', 'd4 d5 Bf4'], ['London System, Indian setup', 'd4 Nf6 Nf3 d5 Bf4'], ['Colle System', 'd4 d5 Nf3 Nf6 e3'], ['Trompowsky Attack', 'd4 Nf6 Bg5'], ['Torre Attack', 'd4 Nf6 Nf3 e6 Bg5'],
    ['English Opening', 'c4'], ['English Opening, Symmetrical', 'c4 c5'], ['English Opening, Reversed Sicilian', 'c4 e5'], ['Zukertort Opening', 'Nf3'], ['Réti Opening', 'Nf3 d5 c4'],
    ['King’s Indian Attack', 'Nf3 d5 g3 Nf6 Bg2'], ['Bird’s Opening', 'f4'], ['Larsen’s Opening', 'b3'], ['Polish Opening', 'b4'], ['Grob Opening', 'g4']
  ];
  var prefixes = {}, lines = L.map(function (x) { return { name: x[0], moves: x[1].split(' ') }; });
  lines.forEach(function (l) { for (var k = 1; k <= l.moves.length; k++) prefixes[l.moves.slice(0, k).join(' ')] = true; });
  lines.sort(function (a, b) { return b.moves.length - a.moves.length; });

  /** True when the first n SAN moves are a known opening line. */
  function inBook(san, n) { return !!prefixes[san.slice(0, n).join(' ')]; }
  /** Deepest named line that is a prefix of the played moves (or null). */
  function nameFor(san, n) {
    var played = san.slice(0, n);
    for (var i = 0; i < lines.length; i++) {
      var m = lines[i].moves;
      if (m.length <= played.length && m.every(function (x, k) { return x === played[k]; })) return lines[i].name;
    }
    return null;
  }
  return { LINES: L, inBook: inBook, nameFor: nameFor };
});
