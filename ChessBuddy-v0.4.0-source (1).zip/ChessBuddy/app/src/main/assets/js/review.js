/* ChessBuddy Game Review. Follows chess.com's published model: every move is rated by the expected points it loses
 * (1 = win, 0 = loss): Excellent <= 0.02, Good <= 0.05, Inaccuracy <= 0.10, Mistake <= 0.20, Blunder above that.
 * Special ratings: Best (the engine's first choice), Great (a critical, hard-to-find move), Brilliant (a good sacrifice),
 * Book (opening theory) and Miss (failing to punish the opponent's error). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./strength.js'));
  else root.CBReview = factory(root.CBStrength);
})(typeof window !== 'undefined' ? window : globalThis, function (Str) {
  'use strict';
  var ORDER = ['brilliant', 'great', 'best', 'excellent', 'good', 'book', 'inaccuracy', 'mistake', 'miss', 'blunder'];
  var LABELS = { brilliant: 'Brilliant', great: 'Great', best: 'Best', excellent: 'Excellent', good: 'Good', book: 'Book', inaccuracy: 'Inaccuracy', mistake: 'Mistake', miss: 'Miss', blunder: 'Blunder' };
  var SYMBOLS = { brilliant: '!!', great: '!', best: '★', excellent: '✓', good: '✓', book: 'B', inaccuracy: '?!', mistake: '?', miss: '×', blunder: '??' };
  var COLORS = { brilliant: '#1baca6', great: '#5c8bb0', best: '#81b64c', excellent: '#96bc4b', good: '#a3b87c', book: '#a88865', inaccuracy: '#f7c631', mistake: '#e6912c', miss: '#e05a4c', blunder: '#c9372c' };

  /** Expected points (0..1) for the side that the engine score belongs to. */
  function ep(score) {
    if (!score) return 0.5;
    if (score.type === 'mate') return score.value > 0 ? 1 : (score.value < 0 ? 0 : 0);
    return 1 / (1 + Math.exp(-0.00368208 * Math.max(-2000, Math.min(2000, score.value))));
  }
  function tier(loss) { return loss <= 0.02 ? 'excellent' : loss <= 0.05 ? 'good' : loss <= 0.10 ? 'inaccuracy' : loss <= 0.20 ? 'mistake' : 'blunder'; }
  function moveAccuracy(winBefore, winAfter) {
    var d = Math.max(0, (winBefore - winAfter) * 100);
    return Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * d) - 3.1669));
  }
  /** Rough performance estimate from accuracy (shown as an estimate only). */
  function ratingFromAccuracy(acc) {
    var pts = [[30, 250], [50, 600], [65, 1000], [75, 1400], [85, 1900], [92, 2300], [97, 2700], [100, 3000]];
    if (acc <= pts[0][0]) return pts[0][1];
    for (var i = 1; i < pts.length; i++) if (acc <= pts[i][0]) { var a = pts[i - 1], b = pts[i]; return Math.round((a[1] + (b[1] - a[1]) * (acc - a[0]) / (b[0] - a[0])) / 50) * 50; }
    return 3000;
  }

  /**
   * history: verbose chess.js history. positions[i] = { score (side to move), best (uci), second (score|null) } for the position BEFORE move i
   * (i = 0..N, N = final position). opts: { isBook(i), isSacrifice(i), legalCount(i), finalTurn }.
   */
  function compute(history, positions, opts) {
    opts = opts || {};
    var rows = [], lastLoss = 0, acc = { w: [], b: [] }, counts = { w: {}, b: {} };
    ORDER.forEach(function (c) { counts.w[c] = 0; counts.b[c] = 0; });
    for (var i = 0; i < history.length; i++) {
      var m = history[i], cur = positions[i], nxt = positions[i + 1];
      if (!cur || !nxt || !cur.score || !nxt.score) { rows.push({ ply: i + 1, san: m.san, color: m.color, cls: null }); lastLoss = 0; continue; }
      var played = m.from + m.to + (m.promotion || '');
      var epBest = ep(cur.score), epAfter = 1 - ep(nxt.score), isBest = played === cur.best;
      var loss = isBest ? 0 : Math.max(0, Math.min(1, epBest - epAfter));
      var cls = isBest ? 'best' : tier(loss);
      if (opts.isBook && opts.isBook(i) && loss < 0.1) cls = 'book';
      else if (loss <= 0.02) {
        var brilliant = opts.isSacrifice && opts.isSacrifice(i) && epBest < 0.92 && epAfter > 0.45;
        var gap = cur.second ? epBest - ep(cur.second) : 0;
        var multi = opts.legalCount ? opts.legalCount(i) > 1 : true;
        if (brilliant) cls = 'brilliant';
        else if ((isBest || loss <= 0.01) && gap >= 0.15 && epBest < 0.97 && multi) cls = 'great';
      } else if (loss >= 0.10 && lastLoss >= 0.10 && epBest >= 0.75) cls = 'miss';
      rows.push({ ply: i + 1, san: m.san, color: m.color, cls: cls, loss: Math.round(loss * 1000) / 1000, best: cur.best, bestScore: cur.score, afterScore: nxt.score, played: played, epBefore: epBest, epAfter: epAfter });
      counts[m.color][cls]++;
      acc[m.color].push(moveAccuracy(epBest, epAfter));
      lastLoss = loss;
    }
    var summary = {};
    ['w', 'b'].forEach(function (c) {
      var a = acc[c], avg = a.length ? a.reduce(function (x, y) { return x + y; }, 0) / a.length : 0;
      summary[c] = { accuracy: Math.round(avg * 10) / 10, rating: a.length ? ratingFromAccuracy(avg) : null, counts: counts[c], moves: a.length };
    });
    var graph = positions.map(function (p, i) {
      if (!p || !p.score) return 50;
      var turn = i < history.length ? history[i].color : (opts.finalTurn || (history.length ? (history[history.length - 1].color === 'w' ? 'b' : 'w') : 'w'));
      var e = ep(p.score);
      return Math.round((turn === 'w' ? e : 1 - e) * 1000) / 10;
    });
    return { rows: rows, summary: summary, graph: graph };
  }

  /** Compact table for the AI model: one line per move. bestSan(i) returns SAN of the engine's best move at position i. */
  function table(history, result, bestSan, openingName) {
    var lines = result.rows.map(function (r, i) {
      var num = history[i].before.split(' ')[5];
      var head = (r.color === 'w' ? num + '. ' : num + '... ') + r.san + ' (' + (r.color === 'w' ? 'White' : 'Black') + ')';
      if (!r.cls) return head + ' — not analysed';
      var tail = LABELS[r.cls] + (r.cls === 'best' || r.cls === 'book' || r.cls === 'brilliant' || r.cls === 'great' ? '' : ', lost ' + r.loss.toFixed(2) + ' expected points, best was ' + (bestSan(i) || '?'));
      return head + ' — ' + tail;
    });
    var s = result.summary;
    if (openingName) lines.unshift('Opening: ' + openingName);
    lines.push('Summary: White accuracy ' + s.w.accuracy + '% (estimated performance ' + (s.w.rating || '?') + '), Black accuracy ' + s.b.accuracy + '% (estimated performance ' + (s.b.rating || '?') + ').');
    return lines.join('\n');
  }
  return { ORDER: ORDER, LABELS: LABELS, SYMBOLS: SYMBOLS, COLORS: COLORS, ep: ep, tier: tier, classify: tier, moveAccuracy: moveAccuracy, ratingFromAccuracy: ratingFromAccuracy, compute: compute, table: table };
});
