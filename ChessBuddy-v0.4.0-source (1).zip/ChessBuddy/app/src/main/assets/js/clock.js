/* ChessBuddy game clock (pure logic). The clock starts after both sides have moved once; increments apply from each side's second move. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBClock = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  var TCS = [
    { id: 'none', label: 'No timer', base: 0, inc: 0 }, { id: '1+0', label: '1 min', base: 60, inc: 0 }, { id: '3+0', label: '3 min', base: 180, inc: 0 },
    { id: '3+2', label: '3 | 2', base: 180, inc: 2 }, { id: '5+0', label: '5 min', base: 300, inc: 0 }, { id: '10+0', label: '10 min', base: 600, inc: 0 },
    { id: '15+10', label: '15 | 10', base: 900, inc: 10 }, { id: '30+0', label: '30 min', base: 1800, inc: 0 }
  ];
  var byId = function (id) { for (var i = 0; i < TCS.length; i++) if (TCS[i].id === id) return TCS[i]; return TCS[0]; };

  function Clock(tc, st) {
    this.id = tc.id; this.inc = tc.inc * 1000;
    this.t = st ? { w: st.w, b: st.b } : { w: tc.base * 1000, b: tc.base * 1000 };
    this.moves = st ? st.moves : 0; this.running = null; this.last = 0;
  }
  /** Subtracts elapsed time from the running side; returns the side that ran out of time, else null. */
  Clock.prototype.tick = function (now) {
    if (!this.running) { this.last = now; return null; }
    var d = now - this.last; this.last = now;
    this.t[this.running] -= d;
    if (this.t[this.running] <= 0) { var s = this.running; this.t[s] = 0; this.running = null; return s; }
    return null;
  };
  /** Time passes without counting (paused / not visible). */
  Clock.prototype.hold = function (now) { this.last = now; };
  Clock.prototype.onMove = function (mover, now) {
    this.tick(now);
    this.moves++;
    if (this.moves > 2) this.t[mover] += this.inc;
    this.running = this.moves >= 2 ? (mover === 'w' ? 'b' : 'w') : null;
    this.last = now;
  };
  Clock.prototype.serialize = function () { return { id: this.id, w: this.t.w, b: this.t.b, moves: this.moves }; };
  Clock.restore = function (s) { var c = new Clock(byId(s.id), s); if (c.moves >= 2) c.running = c.moves % 2 === 0 ? 'w' : 'b'; return c; };

  function fmt(ms) {
    ms = Math.max(0, ms);
    if (ms < 10000) return '0:' + (ms / 1000 < 10 ? '0' : '') + (Math.floor(ms / 100) / 10).toFixed(1);
    var s = Math.ceil(ms / 1000), m = Math.floor(s / 60);
    return m + ':' + (s % 60 < 10 ? '0' : '') + (s % 60);
  }
  return { TCS: TCS, byId: byId, Clock: Clock, restore: Clock.restore, fmt: fmt };
});
