# ChessBuddy v0.4.0 — project status (2026-11-03)

## Current requirements
- Fresh Android chess app powered by real Stockfish, not a simulated opponent.
- Play, Coach, Archive and Settings tabs with a polished Chess.com-inspired mobile board and pieces.
- Human-vs-AI, AI-vs-AI and pass-and-play.
- Strict legal-move validation, reliable tap selection, drag-and-drop, promotion, undo, flip and hint.
- OpenAI-compatible/GPT and Claude model settings with provider API keys stored natively in Android Keystore.
- Every release must ship the APK with the exact matching source ZIP, build verification report, Stockfish provenance and SHA-256 checksums.

## Changes in v0.4.0
- Fixed the capture-square CSS collision: capture destinations now use `.capture-target`; the captured-material display styling is scoped to `.pcard .cap`. This prevents the global `.cap` flex layout from distorting board squares and piece placement.
- Capture rings now sit behind the piece artwork, with legal-move dots and board overlays separated into predictable layers.
- Improved evaluation bar width and score-label layout so the score is legible on narrow phone screens.
- Added touch/mouse drag-and-drop with a floating piece ghost, drop validation through the existing legal-move list, and a short destination-piece arrival animation.
- Expanded the Stockfish opponent roster with seven historical/current-player-inspired profiles: Capablanca, Tal, Polgár, Fischer, Nakamura, Kasparov and Carlsen. These are Stockfish difficulty presets inspired by playing styles, not actual reproductions of those players' games or official Chess.com bot profiles. Their Elo values are approximate presets.
- Removed the committed sideload keystore. GitHub Actions now uses a repository-provided private key when configured, otherwise generates an ephemeral personal-build key. Ephemeral-key builds will not be update-compatible with each other.
- Set Android versionName to 0.4.0.
- Reduced the default CI perft regression suite to depths 1–2 across five standard positions. The previous depth-3/4 test runner exceeded the available 300-second test timeout; deeper perft is not claimed as passed.

## Tests actually run on 2026-11-03
- `node tests/run-all.js`: PASS, 55 logic tests across six suites, including perft depth 1–2 on five positions.
- `node --check` for `app.js`, `ui-board.js`, `strength.js`: PASS.
- `node tests/logic/strength-models.test.js`: PASS, 11/11.
- `bash tests/java/run.sh`: PASS, Java policy test; compiler emitted only a deprecation note.
- Source ZIP integrity: pending final packaging check.
- UI interaction tests: NOT RUN; Playwright is not installed in this environment.
- Android Gradle build, Stockfish NDK build, APK verification, live provider API calls and real-device tests: NOT RUN.

## Blockers / limitations
- This environment does not have a usable Android SDK/NDK or Gradle installation; no APK was built here.
- Playwright/Chromium is unavailable here, so drag-and-drop and visual layout changes have not been browser-tested.
- No live GPT/OpenAI or Claude request was made; existing provider logic remains covered by mock/unit tests only.
- Chess.com proprietary bot roster, portrait art and exact interface assets are not copied. The app uses its own board/artwork and original monogram portraits for player-inspired Stockfish profiles.
- If CI generates an ephemeral signing key, preserve that key if you need future APKs to install as updates over that specific APK. Configure repository signing secrets for stable releases.

## Exact next steps
1. Upload this source to `Mahirabsar2/chessbuddy` and run **Actions → Build ChessBuddy APK**.
2. Confirm the workflow reaches Stockfish NDK compilation, release APK assembly and `scripts/verify_apk.sh`.
3. Download the APK and exact same-run source ZIP; compare the source commit in `BUILD_INFO.txt` with the workflow commit and verify both SHA-256 entries.
4. Install on the Android phone and test tap selection, dragging, captures, legal/illegal drops, promotion, undo, flip, evaluation label, both game modes and bot profiles.
5. Test GPT/OpenAI-compatible and Claude requests using the user's own keys; never include keys in logs or source ZIPs.
6. Record actual results and only then mark v0.4.0 as a verified release.
