/* ChessBuddy strength control for Stockfish bots.
 *  - Elo >= engine minimum (1320): Stockfish's own calibrated limiter (UCI_LimitStrength + UCI_Elo).
 *  - Elo below that (or an engine without UCI_Elo): "handicap" mode. Stockfish still does the search
 *    (real engine, honest top lines) but with a small node budget, and the move is then chosen among its
 *    MultiPV lines with Elo-dependent randomness (softmax over centipawn loss + occasional slips).
 *  - Elo null: full strength. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBStrength = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  var clamp = function (x, a, b) { return Math.max(a, Math.min(b, x)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };

  function cpOf(score) {
    if (!score) return 0;
    if (score.type === 'cp') return score.value;
    return score.value > 0 ? 10000 - score.value : -10000 - score.value;
  }

  /** o: { movetime, uciMin, uciMax, hasLimit } -> { mode, options, go, multipv, params } */
  function plan(elo, o) {
    o = o || {};
    var movetime = o.movetime || 1000, uciMin = o.uciMin || 1320, uciMax = o.uciMax || 3190;
    var hasLimit = o.hasLimit !== false;
    if (elo == null) return { mode: 'full', elo: null, options: { UCI_LimitStrength: false, 'Skill Level': 20, MultiPV: 1 }, go: { movetime: movetime }, multipv: 1 };
    if (hasLimit && elo >= uciMin) {
      return { mode: 'uci', elo: Math.min(elo, uciMax), options: { UCI_LimitStrength: true, UCI_Elo: Math.min(elo, uciMax), 'Skill Level': 20, MultiPV: 1 }, go: { movetime: movetime }, multipv: 1 };
    }
    var t = clamp((elo - 200) / 1800, 0, 1);
    var nodes = Math.round(Math.exp(lerp(Math.log(30), Math.log(1800), t)));
    var strong = elo >= uciMin;                       // engine without UCI_Elo support
    var low = clamp((elo - 200) / (uciMin - 200), 0, 1), high = clamp((elo - uciMin) / (uciMax - uciMin), 0, 1);
    var params = strong
      ? { temperature: lerp(60, 10, high), blunder: lerp(0.04, 0, high), maxLoss: lerp(250, 60, high) }
      : { temperature: lerp(240, 60, low), blunder: lerp(0.3, 0.04, low), maxLoss: lerp(900, 250, low) };
    return {
      mode: 'handicap', elo: elo,
      options: { UCI_LimitStrength: false, 'Skill Level': 20, MultiPV: 6 },
      go: { nodes: strong ? Math.max(nodes, 2500) : nodes },
      multipv: 6,
      params: params
    };
  }

  /** lines: engine info lines (best first); returns the chosen line's first move (UCI). */
  function pickMove(lines, p, rng) {
    rng = rng || Math.random;
    var usable = (lines || []).filter(function (l) { return l && l.pv && l.pv.length && l.score; });
    if (!usable.length) return null;
    if (usable.length === 1 || !p || p.mode !== 'handicap') return usable[0].pv[0];
    var best = cpOf(usable[0].score);
    var cand = usable.map(function (l, i) { return { move: l.pv[0], loss: clamp(best - cpOf(l.score), 0, 5000), i: i }; })
      .filter(function (c) { return c.i === 0 || c.loss <= p.params.maxLoss; });
    if (cand.length > 1 && rng() < p.params.blunder) {
      var others = cand.slice(1);
      return others[Math.floor(rng() * others.length)].move;
    }
    var w = cand.map(function (c) { return Math.exp(-c.loss / p.params.temperature); });
    var sum = w.reduce(function (a, b) { return a + b; }, 0), r = rng() * sum;
    for (var i = 0; i < cand.length; i++) { r -= w[i]; if (r <= 0) return cand[i].move; }
    return cand[0].move;
  }

  function category(elo) {
    if (elo == null) return 'Master';
    return elo < 1000 ? 'Beginner' : elo < 1700 ? 'Intermediate' : elo < 2400 ? 'Advanced' : 'Master';
  }

  /** Original (fictional) bot roster, chess.com-style categories. */
  var BOTS = [
    { id: 'pip', name: 'Pip', elo: 400, piece: 'p', hue: 95, blurb: 'Just learned the rules. Loves pushing pawns, forgets about defence.' },
    { id: 'maple', name: 'Maple', elo: 700, piece: 'p', hue: 130, blurb: 'Friendly and careless. Great for your first wins.' },
    { id: 'sunny', name: 'Sunny', elo: 1000, piece: 'n', hue: 48, blurb: 'Knows the basics, still hangs pieces now and then.' },
    { id: 'quill', name: 'Quill', elo: 1250, piece: 'n', hue: 28, blurb: 'Plays sensible chess with the odd blunder.' },
    { id: 'marlow', name: 'Marlow', elo: 1500, piece: 'b', hue: 200, blurb: 'A steady club player. Punishes loose pieces.' },
    { id: 'juno', name: 'Juno', elo: 1750, piece: 'b', hue: 265, blurb: 'Solid tactics and decent endgames.' },
    { id: 'atlas', name: 'Atlas', elo: 2000, piece: 'r', hue: 12, blurb: 'Strong positional play. Rarely drops material.' },
    { id: 'vega', name: 'Vega', elo: 2300, piece: 'r', hue: 330, blurb: 'Expert level. Calculates deeply and converts advantages.' },
    { id: 'orion', name: 'Orion', elo: 2600, piece: 'q', hue: 190, blurb: 'Master strength. Mistakes are very rare.' },
    { id: 'capablanca', name: 'José Raúl Capablanca', elo: 2700, piece: 'b', hue: 38, badge: 'JC', blurb: 'Inspired by Capablanca: clean technique and simple positions.' },
    { id: 'tal', name: 'Mikhail Tal', elo: 2700, piece: 'n', hue: 285, badge: 'MT', blurb: 'Inspired by Tal: sharp complications and imaginative attacks.' },
    { id: 'polgar', name: 'Judit Polgár', elo: 2700, piece: 'r', hue: 330, badge: 'JP', blurb: 'Inspired by Polgár: fearless, tactical attacking chess.' },
    { id: 'fischer', name: 'Bobby Fischer', elo: 2785, piece: 'k', hue: 18, badge: 'BF', blurb: 'Inspired by Fischer: direct opening play and precise tactics.' },
    { id: 'nakamura', name: 'Hikaru Nakamura', elo: 2800, piece: 'n', hue: 155, badge: 'HN', blurb: 'Inspired by Nakamura: fast, resourceful practical chess.' },
    { id: 'kasparov', name: 'Garry Kasparov', elo: 2850, piece: 'q', hue: 8, badge: 'GK', blurb: 'Inspired by Kasparov: dynamic initiative and attacking pressure.' },
    { id: 'carlsen', name: 'Magnus Carlsen', elo: 2880, piece: 'k', hue: 205, badge: 'MC', blurb: 'Inspired by Carlsen: relentless endgame pressure.' },
    { id: 'titan', name: 'Titan', elo: 2900, piece: 'q', hue: 275, blurb: 'Grandmaster-level pressure from move one.' },
    { id: 'stockfish', name: 'Stockfish', elo: null, piece: 'k', hue: 140, blurb: 'Full strength. No mercy.' }
  ];
  var botById = function (id) { for (var i = 0; i < BOTS.length; i++) if (BOTS[i].id === id) return BOTS[i]; return null; };

  return { plan: plan, pickMove: pickMove, category: category, cpOf: cpOf, BOTS: BOTS, botById: botById };
});
