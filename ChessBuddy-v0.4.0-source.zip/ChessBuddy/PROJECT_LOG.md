# ChessBuddy project log

## 2026-10-28
- Reset project to a fresh Android project named ChessBuddy.
- Current UI includes Play, Coach, History, and Settings tabs.
- Bundled chess.js legal-move rules; basic opponent is not Stockfish.
- Added GitHub Actions workflow to build a debug APK in a hosted Android/Gradle environment and upload APK + exact matching source ZIP + checksums.
- Local APK build is still unavailable because this execution environment has no Android SDK/Gradle installation.
- Next: push this source ZIP to a GitHub repository and run the workflow; then integrate a verified Stockfish build and test on-device.

## 2026-10-31 — v0.3.0 (Claude)
- Rebuilt on the supplied scaffold: replaced the random-move prototype with a real Stockfish integration (NDK build in CI, UCI client, process bridge).
- chess.com-style UI (lobby, bot picker, game screen, Coach, Archive, Settings). AI models shown by real model names.
- AI-model opponents and coach with full position reports, move explanations and board screenshots; strict legal-move validation (fixes the "illegal move at game start" class of bug).
- Strength: Stockfish limiter >= 1320 Elo, handicap mode below.
- Verified in the sandbox: 55 logic tests, 26 UI tests (mock bridge), Java compile against stubs, URL-policy JVM test. NOT verified: Gradle/NDK build, APK, on-device behaviour (sandbox has no network/SDK).

## 2026-11-03 — v0.4.0 (development update)
- Fixed board capture marker styling collision: `.capture-target` is now separate from `.pcard .cap` material tray styles; capture ring sits behind the SVG piece.
- Improved narrow evaluation-bar score layout.
- Added mouse/touch drag-and-drop with floating piece ghost, legal-destination validation and destination arrival animation. Tap-to-select remains supported.
- Added seven player-inspired Stockfish profiles (Capablanca, Tal, Polgár, Fischer, Nakamura, Kasparov, Carlsen) with original monogram icons and approximate Elo presets. These are not official Chess.com bots or likenesses.
- Removed the committed signing keystore and updated CI to use a repository key or generate an ephemeral personal-build key. No signing secret is included in source archives.
- Bumped Android versionName to 0.4.0.
- Reduced CI perft coverage to depth 1–2 across five standard positions after the prior deeper suite exceeded 300 seconds.
- Verified: `node tests/run-all.js` passed 55 logic tests; three modified JavaScript files passed `node --check`; strength/model suite 11/11 passed; Java policy test passed.
- Not run: Playwright UI tests, Gradle/NDK build, APK verification, device testing, live provider API calls. No APK produced in this environment.
- Next: upload source, run GitHub Actions, verify APK + same-commit source ZIP + checksums, then install and test on Android.
