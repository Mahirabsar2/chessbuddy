const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const { Chess } = require('../helpers/load-chessjs')();
console.log('chess.js move generation (perft)');
function perft(g, d) { if (!d) return 1; let n = 0; for (const m of g.moves({ verbose: true })) { g.move(m); n += perft(g, d - 1); g.undo(); } return n; }
[['startpos', 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', [20, 400]],
 ['kiwipete', 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1', [48, 2039]],
 ['position 3', '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1', [14, 191]],
 ['position 4', 'r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1', [6, 264]],
 ['position 5', 'rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8', [44, 1486]]]
  .forEach(([n, fen, exp]) => test('perft ' + n, () => { const g = new Chess(fen); assert.strictEqual(JSON.stringify(exp.map((_, i) => perft(g, i + 1))), JSON.stringify(exp)); }));
done('perft');
