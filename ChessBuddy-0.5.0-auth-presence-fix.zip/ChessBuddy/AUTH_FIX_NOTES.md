# ChessBuddy 0.5.0 auth callback fix

This temporary source patch adds the Android `chessbuddy://auth-callback` deep link, Supabase email-confirmation session handling, and secure native refresh-token persistence.

## Supabase dashboard requirement

In **Authentication → URL Configuration → Redirect URLs**, add this exact redirect URL:

`chessbuddy://auth-callback`

The app uses this redirect when creating an account. Without the allow-list entry, Supabase may reject the redirect or send the confirmation flow somewhere else.

## Security

- The app still uses only the Supabase publishable key.
- Refresh tokens remain in Android encrypted storage.
- Callback access tokens are validated against `/auth/v1/user` before the refresh token is saved.
- `cb_set_presence` grants and RLS policies are unchanged. No `anon` permissions were added.
- Expired-session retry is limited to HTTP 401. Permission/configuration errors such as 403 are surfaced instead of retried.

## Validation

Run `node tests/run-all.js` and `bash tests/java/run.sh` from this directory.
