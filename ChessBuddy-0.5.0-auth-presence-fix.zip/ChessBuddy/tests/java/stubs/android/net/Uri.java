package android.net; public class Uri { private final String value; public Uri(){this("");} public Uri(String v){value=v;} public String toString(){return value;} }
