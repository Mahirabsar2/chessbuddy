#!/usr/bin/env bash
# Build a CPU-only ARM64 Lc0 UCI executable for Android and create a checksum manifest for Maia-1 models.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
NDK_VERSION="${NDK_VERSION:-27.2.12479018}"
if [ -z "$SDK" ]; then echo "Android SDK is not configured" >&2; exit 1; fi
NDK="${ANDROID_NDK_HOME:-$SDK/ndk/$NDK_VERSION}"
if [ ! -d "$NDK" ]; then echo "Android NDK not found: $NDK" >&2; exit 1; fi
HOST_TAG="linux-x86_64"
TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin"
API="24"
CC="$TOOLCHAIN/aarch64-linux-android${API}-clang"
CXX="$TOOLCHAIN/aarch64-linux-android${API}-clang++"
AR="$TOOLCHAIN/llvm-ar"
RANLIB="$TOOLCHAIN/llvm-ranlib"
STRIP="$TOOLCHAIN/llvm-strip"
for tool in "$CC" "$CXX" "$AR" "$RANLIB" "$STRIP"; do test -x "$tool" || { echo "Missing NDK tool: $tool" >&2; exit 1; }; done

JOBS="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)"
TMP="${RUNNER_TEMP:-/tmp}/chessbuddy-lc0-build"
rm -rf "$TMP"
mkdir -p "$TMP"

python3 -m pip install --user --disable-pip-version-check meson ninja
export PATH="$HOME/.local/bin:$PATH"

# OpenBLAS is built as a static ARMv8 library; no shared BLAS dependency is shipped.
git clone --depth 1 --branch v0.3.29 https://github.com/OpenMathLib/OpenBLAS.git "$TMP/openblas"
make -C "$TMP/openblas" -j"$JOBS" TARGET=ARMV8 CC="$CC" AR="$AR" RANLIB="$RANLIB" HOSTCC=gcc \
  NOFORTRAN=1 NO_LAPACK=1 NO_SHARED=1 CFLAGS="-O3 -fPIC"
OPENBLAS_PREFIX="$TMP/openblas-install"
make -C "$TMP/openblas" PREFIX="$OPENBLAS_PREFIX" TARGET=ARMV8 CC="$CC" AR="$AR" RANLIB="$RANLIB" HOSTCC=gcc \
  NOFORTRAN=1 NO_LAPACK=1 NO_SHARED=1 install

# Pin Lc0 0.32.1 and its exact submodule state.
LC0_COMMIT="fd71a2d921b689c5f479d3227c3806c8e272d9c5"
git clone --filter=blob:none --no-checkout https://github.com/LeelaChessZero/lc0.git "$TMP/lc0"
git -C "$TMP/lc0" checkout --detach "$LC0_COMMIT"
git -C "$TMP/lc0" submodule update --init --recursive --depth 1

cat > "$TMP/android-aarch64.ini" <<CROSS
[binaries]
c = '$CC'
cpp = '$CXX'
ar = '$AR'
strip = '$STRIP'

[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'armv8'
endian = 'little'

[properties]
needs_exe_wrapper = true
CROSS

export PKG_CONFIG_PATH="$OPENBLAS_PREFIX/lib/pkgconfig"
meson setup "$TMP/lc0/build-android" "$TMP/lc0" \
  --cross-file "$TMP/android-aarch64.ini" --buildtype=release \
  -Dlc0=true -Dbuild_backends=true -Dblas=true -Dopenblas=true -Dopenblas_libdirs="$OPENBLAS_PREFIX/lib" \
  -Dopenblas_include="$OPENBLAS_PREFIX/include" -Donnx=false -Dopencl=false -Dtensorflow=false \
  -Donednn=false -Ddnnl=false -Dmkl=false -Daccelerate=false -Dnative_arch=false \
  -Dplain_cuda=false -Dnative_cuda=false -Dcudnn=false -Dsycl=off -Ddx=false -Dxla=false -Dmetal=disabled \
  -Dneon=true -Dpopcnt=false -Df16c=false -Dpext=false -Dispc=false -Dgtest=false \
  -Ddefault_search=policyhead -Ddefault_backend=blas
meson compile -C "$TMP/lc0/build-android" -j "$JOBS"

LC0_BIN="$(find "$TMP/lc0/build-android" -type f -name lc0 -perm -u+x -print -quit)"
if [ -z "$LC0_BIN" ]; then echo "Lc0 executable was not produced" >&2; find "$TMP/lc0/build-android" -maxdepth 4 -type f | head -100; exit 1; fi
OUT="$ROOT/app/src/main/jniLibs/arm64-v8a"
mkdir -p "$OUT" "$ROOT/app/src/main/assets/licenses" "$ROOT/app/src/main/assets/models" "$ROOT/build-info" "$ROOT/third_party/sources"
cp "$LC0_BIN" "$OUT/liblc0.so"
"$STRIP" --strip-unneeded "$OUT/liblc0.so"
if "$TOOLCHAIN/llvm-readelf" -d "$OUT/liblc0.so" | grep -q 'libopenblas\.so'; then
  echo "Lc0 unexpectedly depends on shared OpenBLAS; the engine build must be self-contained" >&2
  exit 1
fi
# Android's shared C++ runtime must sit beside the executable if the toolchain linked it dynamically.
LIBCXX="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so"
if [ -f "$LIBCXX" ]; then cp "$LIBCXX" "$OUT/libc++_shared.so"; fi
cp "$TMP/lc0/COPYING" "$ROOT/app/src/main/assets/licenses/Lc0-GPL-3.0.txt"
cp "$TMP/openblas/LICENSE" "$ROOT/app/src/main/assets/licenses/OpenBLAS-LICENSE.txt"
cp "$TMP/lc0/COPYING" "$ROOT/app/src/main/assets/licenses/Maia-GPL-3.0.txt"

# Keep corresponding third-party source archives with the release source package.
tar -czf "$ROOT/third_party/sources/lc0-$LC0_COMMIT.tar.gz" -C "$TMP/lc0" --exclude=.git --exclude=build-android .
tar -czf "$ROOT/third_party/sources/openblas-v0.3.29.tar.gz" -C "$TMP/openblas" --exclude=.git .

# Hash the official Maia-1 release weights at build time; only the small manifest ships in the APK.
MODEL_DIR="$TMP/maia-models"
mkdir -p "$MODEL_DIR"
for rating in 1100 1500 1900; do
  url="https://github.com/CSSLab/maia-chess/releases/download/v1.0/maia-$rating.pb.gz"
  curl --fail --location --retry 3 --retry-delay 2 "$url" -o "$MODEL_DIR/maia-$rating.pb.gz"
done
{
  echo '{"source":"CSSLab/maia-chess v1.0","license":"GPL-3.0","models":['
  first=1
  for rating in 1100 1500 1900; do
    file="$MODEL_DIR/maia-$rating.pb.gz"
    sha="$(sha256sum "$file" | cut -d' ' -f1)"
    bytes="$(wc -c < "$file" | tr -d ' ')"
    [ "$first" -eq 1 ] || echo ','
    printf '{"id":"maia-%s","rating":%s,"file":"maia-%s.pb.gz","url":"https://github.com/CSSLab/maia-chess/releases/download/v1.0/maia-%s.pb.gz","sha256":"%s","bytes":%s}' "$rating" "$rating" "$rating" "$rating" "$sha" "$bytes"
    first=0
  done
  echo ']}'
} > "$ROOT/app/src/main/assets/models/maia-models.json"

file "$OUT/liblc0.so" > "$ROOT/build-info/lc0.txt"
echo "Lc0 commit: $LC0_COMMIT" >> "$ROOT/build-info/lc0.txt"
echo "OpenBLAS: v0.3.29, ARMv8 static, no shared BLAS runtime" >> "$ROOT/build-info/lc0.txt"
sha256sum "$OUT/liblc0.so" >> "$ROOT/build-info/lc0.txt"
cat "$ROOT/build-info/lc0.txt"
