#!/usr/bin/env bash
# Checks the built APK for real and records exactly what was verified.  Usage: verify_apk.sh app.apk [report.txt]
set -euo pipefail
APK="${1:?usage: verify_apk.sh path/to/app.apk [report.txt]}"
REPORT="${2:-build-info/VERIFIED_CHECKS.txt}"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
BT="$(ls -d "$SDK"/build-tools/* 2>/dev/null | sort -V | tail -1 || true)"
mkdir -p "$(dirname "$REPORT")"; : > "$REPORT"
T="$(mktemp -d)"
pass() { echo "PASS  $1" | tee -a "$REPORT"; }
warn() { echo "WARN  $1" | tee -a "$REPORT"; }
fail() { echo "FAIL  $1" | tee -a "$REPORT"; echo "::error::APK check failed: $1"; exit 1; }

[ -s "$APK" ] || fail "APK is missing or empty: $APK"
pass "APK exists and is non-empty ($(stat -c %s "$APK") bytes)"
unzip -tq "$APK" >/dev/null || fail "APK zip is corrupt"; pass "APK zip integrity"
LIST="$(unzip -l "$APK")"
echo "$LIST" | grep -q 'assets/index.html' || fail "web UI missing from APK"
echo "$LIST" | grep -q 'assets/js/app.js' || fail "app.js missing from APK"
echo "$LIST" | grep -q 'assets/js/chess.js' || fail "chess.js missing from APK"
pass "web UI assets are packaged (index.html, app.js, chess.js)"
echo "$LIST" | grep -q 'lib/arm64-v8a/libstockfish.so' || fail "libstockfish.so is not in the APK (no engine!)"
unzip -q -o "$APK" lib/arm64-v8a/libstockfish.so -d "$T"
file "$T/lib/arm64-v8a/libstockfish.so" | grep -q 'ARM aarch64' || fail "packaged engine is not an ARM aarch64 ELF"
SZ="$(stat -c %s "$T/lib/arm64-v8a/libstockfish.so")"
[ "$SZ" -ge $((8*1024*1024)) ] || fail "packaged engine is too small ($SZ bytes): NNUE network missing"
pass "Stockfish binary packaged: ARM aarch64 ELF, $SZ bytes (network embedded)"
echo "$LIST" | grep -q 'lib/arm64-v8a/liblc0.so' || fail "liblc0.so is not in the APK (Maia engine unavailable)"
unzip -q -o "$APK" lib/arm64-v8a/liblc0.so -d "$T"
file "$T/lib/arm64-v8a/liblc0.so" | grep -q 'ARM aarch64' || fail "packaged Lc0 engine is not an ARM aarch64 ELF"
LC0_SZ="$(stat -c %s "$T/lib/arm64-v8a/liblc0.so")"
[ "$LC0_SZ" -ge $((512*1024)) ] || fail "packaged Lc0 binary is unexpectedly small ($LC0_SZ bytes)"
pass "Lc0 binary packaged: ARM aarch64 ELF, $LC0_SZ bytes"
echo "$LIST" | grep -q 'lib/arm64-v8a/libchessbuddy_core.so' || fail "libchessbuddy_core.so is not in the APK (Rust rules cross-check unavailable)"
unzip -q -o "$APK" lib/arm64-v8a/libchessbuddy_core.so -d "$T"
file "$T/lib/arm64-v8a/libchessbuddy_core.so" | grep -q 'ARM aarch64' || fail "Rust core is not an ARM aarch64 ELF"
if command -v readelf >/dev/null 2>&1; then
  readelf -Ws "$T/lib/arm64-v8a/libchessbuddy_core.so" | grep -q 'Java_com_chessbuddy_RustChess_nativeIsLegalMove' || fail "Rust JNI move-validation entry point is missing"
fi
pass "Rust move-validation library packaged: ARM aarch64 JNI shared library"
echo "$LIST" | grep -q 'lib/arm64-v8a/libc++_shared.so' || fail "libc++_shared.so is missing (required by Lc0 build)"
echo "$LIST" | grep -q 'assets/models/maia-models.json' || fail "Maia model manifest missing from APK"
echo "$LIST" | grep -q 'assets/licenses/Maia-GPL-3.0.txt' || fail "Maia licence text missing from APK"
echo "$LIST" | grep -q 'assets/licenses/Lc0-GPL-3.0.txt' || fail "Lc0 licence text missing from APK"
echo "$LIST" | grep -q 'assets/licenses/OpenBLAS-LICENSE.txt' || fail "OpenBLAS licence text missing from APK"
unzip -p "$APK" assets/models/maia-models.json | grep -Eq '"sha256":"[0-9a-f]{64}"' || fail "Maia model SHA-256 manifest is not populated"
unzip -p "$APK" assets/models/maia-models.json | grep -Eq '"bytes":[1-9][0-9]+' || fail "Maia model size manifest is not populated"
pass "Maia model manifest and all engine licence notices are packaged"
[ -n "$BT" ] || fail "Android build-tools not found"
"$BT/aapt2" dump badging "$APK" > "$T/badging.txt"
grep -q "package: name='com.chessbuddy'" "$T/badging.txt" || fail "unexpected package name"
pass "$(grep -m1 '^package:' "$T/badging.txt" | cut -c1-110)"
grep -q "uses-permission: name='android.permission.INTERNET'" "$T/badging.txt" || fail "INTERNET permission missing"
pass "INTERNET permission declared (needed for AI models)"
grep -q "native-code: 'arm64-v8a'" "$T/badging.txt" || fail "native-code arm64-v8a missing"
pass "native code ABI: arm64-v8a"
pass "$(grep -m1 '^sdkVersion' "$T/badging.txt") / $(grep -m1 '^targetSdkVersion' "$T/badging.txt")"
"$BT/aapt2" dump xmltree --file AndroidManifest.xml "$APK" > "$T/manifest.txt" 2>/dev/null || true
if grep -q 'extractNativeLibs.*=true\|extractNativeLibs.*=(type 0x12)0xffffffff' "$T/manifest.txt"; then pass "extractNativeLibs=true (Stockfish and Lc0 can be executed from the native lib dir)"
elif grep -q 'extractNativeLibs.*=false\|extractNativeLibs.*=(type 0x12)0x0' "$T/manifest.txt"; then fail "extractNativeLibs=false: the engine could not run"
else warn "could not read extractNativeLibs from the manifest (packaging.jniLibs.useLegacyPackaging is set in app/build.gradle)"; fi
"$BT/apksigner" verify --verbose "$APK" > "$T/sign.txt" 2>&1 || { cat "$T/sign.txt"; fail "APK signature does not verify"; }
pass "APK signature verifies ($(grep -m1 -o 'v[0-9]* scheme[^:]*: true' "$T/sign.txt" | head -3 | tr '\n' ' '))"
echo "Verified by scripts/verify_apk.sh at $(date -u +%FT%TZ)" | tee -a "$REPORT"
