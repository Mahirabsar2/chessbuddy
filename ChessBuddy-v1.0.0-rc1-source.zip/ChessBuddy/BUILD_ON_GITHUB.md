# Build the ChessBuddy 1.0.0 release candidate

This folder is the **source project**, not an APK. The GitHub Actions workflow builds the Android ARM64 APK and a matching source archive.

## Run the build

1. Upload the contents of this `ChessBuddy` folder to your `Mahirabsar2/chessbuddy` repository on branch `chessbuddy-5.0-final-dev` (or `main`). Include the hidden `.github` directory and overwrite only the temporary development branch, not the separate Claude 4.0 project/branch.
2. Commit the upload. A push to the configured branch starts `ChessBuddy 1.0.0 — release candidate build`. You can also run it manually from the repository's **Actions** tab.
3. Open the Actions run and download the artifact named `ChessBuddy-1.0.0-build-N`. It contains the APK, source ZIP, build information, engine provenance, verification report and SHA-256 sums.
4. Install the `*-arm64.apk` on a 64-bit ARM Android device. The local source ZIP itself is not installable.

## Release signing

Before installing an APK you expect to update later, configure a persistent keystore in **Repository → Settings → Secrets and variables → Actions**:

- `CB_KEYSTORE_BASE64`
- `CB_KEYSTORE_PASSWORD`
- `CB_KEY_ALIAS`
- `CB_KEY_PASSWORD`

Keep the private keystore and passwords outside the repository. The workflow creates an ephemeral key only as a fallback; APKs signed with different ephemeral keys cannot update-install over one another. Never commit a keystore.

## What the CI workflow checks

JavaScript logic, Java bridge policy/compile, Playwright UI, Deno online-validator, and Rust move-validation tests; Stockfish, Lc0 and Rust ARM64 native builds; packaged JNI libraries, model manifest/licence notices, app package/ABI/permissions and APK signature.

## Before production use

Google OAuth credentials and custom SMTP must be configured in Supabase. The owner must review and deploy the pending online-move SQL hardening and Edge Function together. Test sign-in, email delivery, session restoration, native engines and two-device friend play on real hardware. See `docs/RELEASE_CHECKLIST.md`.

The Supabase app redirect `chessbuddy://auth-callback` is already in the project's allowlist; do not add a duplicate.
