# Third-party source archives

The Android CI build creates `third_party/sources/` with the exact pinned Lc0 source (including its submodule) and OpenBLAS source used to produce the bundled ARM64 engine. These archives are included in the release source ZIP for corresponding-source and licence compliance.

Maia-1 model weights are downloaded on demand from the upstream CSSLab release and are not bundled in the APK. Their source and licence notice are in `app/src/main/assets/licenses/`.
