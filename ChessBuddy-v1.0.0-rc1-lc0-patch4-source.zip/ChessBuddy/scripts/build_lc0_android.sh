#!/usr/bin/env bash
# Reproducibly cross-compile Leela Chess Zero for Android arm64-v8a.
# Output: app/src/main/jniLibs/arm64-v8a/liblc0.so (an Android PIE executable,
# deliberately stored in jniLibs so PackageManager extracts it into nativeLibraryDir).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
NDK_VERSION="${NDK_VERSION:-27.2.12479018}"
LC0_COMMIT="${LC0_COMMIT:-fd71a2d921b689c5f479d3227c3806c8e272d9c5}"
OPENBLAS_TAG="${OPENBLAS_TAG:-v0.3.29}"
ANDROID_API="${ANDROID_API:-24}"
HOST_TAG="linux-x86_64"

[ -n "$SDK" ] || { echo "ANDROID_HOME or ANDROID_SDK_ROOT must be set" >&2; exit 1; }
NDK="${ANDROID_NDK_HOME:-$SDK/ndk/$NDK_VERSION}"
[ -d "$NDK/toolchains/llvm/prebuilt/$HOST_TAG" ] || { echo "Android NDK $NDK_VERSION not found at $NDK" >&2; exit 1; }
TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin"
SYSROOT="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/sysroot"
CC="$TOOLCHAIN/aarch64-linux-android${ANDROID_API}-clang"
CXX="$TOOLCHAIN/aarch64-linux-android${ANDROID_API}-clang++"
AR="$TOOLCHAIN/llvm-ar"
RANLIB="$TOOLCHAIN/llvm-ranlib"
STRIP="$TOOLCHAIN/llvm-strip"
READELF="$TOOLCHAIN/llvm-readelf"
for tool in "$CC" "$CXX" "$AR" "$RANLIB" "$STRIP" "$READELF"; do
  [ -x "$tool" ] || { echo "Required NDK tool missing: $tool" >&2; exit 1; }
done

JOBS="${BUILD_JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)}"
TMP="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/chessbuddy-lc0-${LC0_COMMIT:0:12}"
rm -rf "$TMP"
mkdir -p "$TMP"

# Isolated, pinned Python build tools: avoids PEP-668/user-site differences on hosted runners.
python3 -m venv "$TMP/venv"
"$TMP/venv/bin/python" -m pip install --disable-pip-version-check --no-input \
  'meson==1.4.2' 'ninja==1.11.1.1'
export PATH="$TMP/venv/bin:$PATH"

# Build a static OpenBLAS for the Android target. No host BLAS library can leak into the APK.
git clone --quiet --depth 1 --branch "$OPENBLAS_TAG" https://github.com/OpenMathLib/OpenBLAS.git "$TMP/openblas"
make -C "$TMP/openblas" -j"$JOBS" \
  TARGET=ARMV8 ONLY_CBLAS=1 CC="$CC" AR="$AR" RANLIB="$RANLIB" HOSTCC=gcc \
  NOFORTRAN=1 NO_LAPACK=1 NO_SHARED=1 CFLAGS='-O3 -fPIC'
OPENBLAS_PREFIX="$TMP/openblas-install"
make -C "$TMP/openblas" PREFIX="$OPENBLAS_PREFIX" \
  TARGET=ARMV8 ONLY_CBLAS=1 CC="$CC" AR="$AR" RANLIB="$RANLIB" HOSTCC=gcc \
  NOFORTRAN=1 NO_LAPACK=1 NO_SHARED=1 install
OPENBLAS_A="$OPENBLAS_PREFIX/lib/libopenblas.a"
[ -s "$OPENBLAS_A" ] || { echo "Static Android OpenBLAS archive was not produced" >&2; exit 1; }
[ -s "$OPENBLAS_PREFIX/include/openblas_config.h" ] || { echo "OpenBLAS headers were not installed" >&2; exit 1; }

# Pin the Lc0 source commit and all recursive submodule revisions.
git clone --quiet --filter=blob:none --no-checkout https://github.com/LeelaChessZero/lc0.git "$TMP/lc0"
git -C "$TMP/lc0" checkout --quiet --detach "$LC0_COMMIT"
git -C "$TMP/lc0" submodule update --init --recursive --depth 1
if git -C "$TMP/lc0" submodule status --recursive | grep -Eq '^[+-U]'; then
  echo "Lc0 submodule checkout is not at the pinned gitlink revisions" >&2
  git -C "$TMP/lc0" submodule status --recursive >&2
  exit 1
fi

cat > "$TMP/android-aarch64.ini" <<CROSS
[binaries]
c = '$CC'
cpp = '$CXX'
ar = '$AR'
strip = '$STRIP'

[host_machine]
system = 'android'
cpu_family = 'aarch64'
cpu = 'armv8-a'
endian = 'little'

[properties]
sys_root = '$SYSROOT'
pkg_config_libdir = ['$OPENBLAS_PREFIX/lib/pkgconfig', '$SYSROOT/usr/lib/aarch64-linux-android/pkgconfig', '$SYSROOT/usr/share/pkgconfig']
needs_exe_wrapper = true

[built-in options]
c_args = ['-fPIC']
cpp_args = ['-fPIC']
c_link_args = ['-Wl,-z,max-page-size=16384']
cpp_link_args = ['-Wl,-z,max-page-size=16384']
CROSS

# Static default libraries prevent a missing libz.so/OpenBLAS dependency on user devices.
export PKG_CONFIG_PATH="$OPENBLAS_PREFIX/lib/pkgconfig"
meson setup "$TMP/lc0/build-android" "$TMP/lc0" \
  --cross-file "$TMP/android-aarch64.ini" --buildtype=release \
  -Ddefault_library=static -Db_lto=false -Dlc0=true -Drescorer=false \
  -Dbuild_backends=true -Dblas=true -Dopenblas=true \
  -Dopenblas_libdirs="$OPENBLAS_PREFIX/lib" -Dopenblas_include="$OPENBLAS_PREFIX/include" \
  -Ddefault_search=policyhead -Ddefault_backend=blas \
  -Dnative_arch=false -Dneon=true -Dpopcnt=false -Df16c=false -Dpext=false -Dispc=false \
  -Dgtest=false -Dopencl=false -Dplain_cuda=false -Dcudnn=false -Donnx=false \
  -Dtensorflow=false -Donednn=false -Ddnnl=false -Dmkl=false -Daccelerate=false \
  -Dxla=false -Dsycl=off -Dmetal=disabled

# Fail early if the configured source is not actually compiling the requested CPU BLAS backend.
grep -Rqs -- '-DUSE_OPENBLAS' "$TMP/lc0/build-android/build.ninja" || {
  echo "Meson did not enable Lc0's OpenBLAS backend" >&2; exit 1;
}
meson compile -C "$TMP/lc0/build-android" -j "$JOBS"
LC0_BIN="$TMP/lc0/build-android/lc0"
[ -s "$LC0_BIN" ] || { echo "Lc0 executable was not produced at $LC0_BIN" >&2; exit 1; }

OUT="$ROOT/app/src/main/jniLibs/arm64-v8a"
mkdir -p "$OUT" "$ROOT/app/src/main/assets/licenses" "$ROOT/app/src/main/assets/models" "$ROOT/build-info" "$ROOT/third_party/sources"
install -m 0755 "$LC0_BIN" "$OUT/liblc0.so"
"$STRIP" --strip-unneeded "$OUT/liblc0.so"
file "$OUT/liblc0.so" | tee "$TMP/lc0-file.txt"
grep -q 'ARM aarch64' "$TMP/lc0-file.txt" || { echo "Lc0 output is not an ARM64 ELF" >&2; exit 1; }

# Audit every DT_NEEDED entry. Bundle libc++ only when required; all other non-system
# shared dependencies are a hard failure rather than silently producing a broken APK.
NEEDED="$TMP/lc0-needed.txt"
"$READELF" -d "$OUT/liblc0.so" | sed -n 's/.*Shared library: \[\([^]]*\)\].*/\1/p' > "$NEEDED"
if grep -Eq '^lib(openblas|blas|protobuf|eigen|gomp|omp).*\.so' "$NEEDED"; then
  echo "Lc0 has an unexpected non-self-contained backend/dependency:" >&2
  cat "$NEEDED" >&2
  exit 1
fi
if grep -qx 'libc++_shared.so' "$NEEDED"; then
  LIBCXX="$SYSROOT/usr/lib/aarch64-linux-android/libc++_shared.so"
  [ -s "$LIBCXX" ] || { echo "Lc0 needs libc++_shared.so but NDK runtime is missing" >&2; exit 1; }
  install -m 0644 "$LIBCXX" "$OUT/libc++_shared.so"
else
  rm -f "$OUT/libc++_shared.so"
fi
while IFS= read -r soname; do
  [ -n "$soname" ] || continue
  case "$soname" in
    libc.so|libm.so|libdl.so|liblog.so|libandroid.so|libz.so|libc++_shared.so) ;;
    *) echo "Unbundled Lc0 shared dependency: $soname" >&2; exit 1 ;;
  esac
done < "$NEEDED"

cp "$TMP/lc0/COPYING" "$ROOT/app/src/main/assets/licenses/Lc0-GPL-3.0.txt"
cp "$TMP/openblas/LICENSE" "$ROOT/app/src/main/assets/licenses/OpenBLAS-LICENSE.txt"
cp "$TMP/lc0/COPYING" "$ROOT/app/src/main/assets/licenses/Maia-GPL-3.0.txt"

tar -czf "$ROOT/third_party/sources/lc0-$LC0_COMMIT.tar.gz" -C "$TMP/lc0" --exclude=.git --exclude=build-android .
tar -czf "$ROOT/third_party/sources/openblas-$OPENBLAS_TAG.tar.gz" -C "$TMP/openblas" --exclude=.git .

# The models remain opt-in downloads. CI records the exact official file size and SHA-256
# that NativeBridge checks before allowing a model to be used.
MODEL_DIR="$TMP/maia-models"
mkdir -p "$MODEL_DIR"
for rating in 1100 1500 1900; do
  url="https://github.com/CSSLab/maia-chess/releases/download/v1.0/maia-$rating.pb.gz"
  curl --fail --location --retry 4 --retry-delay 2 "$url" -o "$MODEL_DIR/maia-$rating.pb.gz"
  gzip -t "$MODEL_DIR/maia-$rating.pb.gz"
  [ "$(stat -c %s "$MODEL_DIR/maia-$rating.pb.gz")" -gt 1024 ] || { echo "Maia $rating model download is unexpectedly small" >&2; exit 1; }
done
{
  printf '{"source":"CSSLab/maia-chess v1.0","license":"GPL-3.0","models":['
  first=1
  for rating in 1100 1500 1900; do
    file="$MODEL_DIR/maia-$rating.pb.gz"
    sha="$(sha256sum "$file" | cut -d' ' -f1)"
    bytes="$(stat -c %s "$file")"
    [ "$first" -eq 1 ] || printf ','
    printf '{"id":"maia-%s","rating":%s,"file":"maia-%s.pb.gz","url":"https://github.com/CSSLab/maia-chess/releases/download/v1.0/maia-%s.pb.gz","sha256":"%s","bytes":%s}' \
      "$rating" "$rating" "$rating" "$rating" "$sha" "$bytes"
    first=0
  done
  printf ']}\n'
} > "$ROOT/app/src/main/assets/models/maia-models.json"

python3 - "$ROOT/app/src/main/assets/models/maia-models.json" <<'PYJSON'
import json,sys
p=sys.argv[1]
d=json.load(open(p,encoding='utf-8'))
assert d['source']=='CSSLab/maia-chess v1.0'
assert {m['id'] for m in d['models']} == {'maia-1100','maia-1500','maia-1900'}
for m in d['models']:
    assert len(m['sha256'])==64 and all(c in '0123456789abcdef' for c in m['sha256'])
    assert m['bytes']>1024 and m['url'].endswith('/'+m['file'])
PYJSON

{
  echo "Lc0 Android ARM64 build provenance"
  echo "  lc0_commit: $LC0_COMMIT"
  echo "  openblas_tag: $OPENBLAS_TAG"
  echo "  android_api: $ANDROID_API"
  echo "  ndk_version: $NDK_VERSION"
  echo "  meson_version: $(meson --version)"
  echo "  backend: OpenBLAS (static), policyhead"
  echo "  binary: app/src/main/jniLibs/arm64-v8a/liblc0.so ($(stat -c %s "$OUT/liblc0.so") bytes)"
  echo "  sha256: $(sha256sum "$OUT/liblc0.so" | cut -d' ' -f1)"
  echo "  DT_NEEDED: $(tr '\n' ' ' < "$NEEDED")"
  echo "  source_archive: third_party/sources/lc0-$LC0_COMMIT.tar.gz"
  echo "  openblas_archive: third_party/sources/openblas-$OPENBLAS_TAG.tar.gz"
  echo "  models_manifest: app/src/main/assets/models/maia-models.json (weights downloaded on device)"
} | tee "$ROOT/build-info/lc0.txt"
