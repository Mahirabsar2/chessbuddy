#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

: "${ANDROID_NDK_HOME:=${ANDROID_NDK_ROOT:-${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}/ndk/27.2.12479018}}"
export ANDROID_NDK_HOME
if [[ ! -d "$ANDROID_NDK_HOME" ]]; then
  echo "Android NDK not found at: $ANDROID_NDK_HOME" >&2
  exit 2
fi

if ! command -v cargo >/dev/null 2>&1; then
  echo "Rust cargo is required to build the ChessBuddy native core." >&2
  exit 2
fi

rustup target add aarch64-linux-android
if ! cargo ndk --version >/dev/null 2>&1; then
  cargo install cargo-ndk --locked
fi
mkdir -p app/src/main/jniLibs
cargo ndk -t arm64-v8a -o app/src/main/jniLibs build --release --manifest-path rust/chessbuddy-core/Cargo.toml

test -s app/src/main/jniLibs/arm64-v8a/libchessbuddy_core.so
file app/src/main/jniLibs/arm64-v8a/libchessbuddy_core.so
