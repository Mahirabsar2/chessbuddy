# ChessBuddy 5.0 — implementation spec

Updated: 2026-11-16
Target branch: `chessbuddy-5.0-final-dev`
Baseline: patched source used for build 19, reconstructed from the exact GitHub Actions artifact; its source archive matches the supplied v0.5.0 ZIP before overlays.

## Goal
Deliver a robust Android-only ChessBuddy 5.0 release preserving the existing working app while completing online friend play, playable Maia/Lc0 where device resources allow, richer bot/coach interactions, polished original iconography/avatars, and a safe release pipeline.

## Confirmed product requirements
- Android app; keep Claude's `chessbuddy-4.0-claude` branch untouched.
- Preserve Stockfish, clocks, bot roster, Game Review, coaches, AI model opponents, AI-vs-AI, pass-and-play, Lichess references, archive, backup/restore, and settings migrations.
- Engine search must receive actual remaining clocks/increments. White's clock starts on White's first move. No fake clock awareness via delay-only behavior.
- Add Maia-style human-move bots and Lc0 as a distinct engine provider only after actual Android process/model integration and device verification.
- Online play is direct challenge only: visible online roster, challenge selected user, accept/decline/cancel, presence, game sync, resign/timeout. No random matchmaking and no separate opponent-add flow.
- Add original portraits, reactions, voice/coach interactions, and smooth transitions. Use original assets/icons; do not copy third-party protected assets unless the actual license scope is supplied and checked.
- Use recognizable SVG icons for review classes and controls; no emoji or letter placeholders.
- Deduplicate before adding replacements. Preserve user data across updates.
- No promise that software will never need maintenance; aim for extensible and well-tested release quality.

## Hard constraints
- Do not change Claude's 4.0 branch.
- No secrets in source control. Never read or print `.env`, API tokens, or signing-key bytes.
- Do not deploy production schema changes without reviewing the exact SQL and obtaining user approval.
- Do not claim online play, Maia/Lc0, or device compatibility verified without real integration/device tests.
- Pin dependencies and document licences/notices.

## Architecture
- Android WebView shell (`MainActivity`, `NativeBridge`) hosts bundled HTML/CSS/JS.
- `chess.js` is the sole chess rules layer; `engine.js` is the UCI client; native `EngineProcess` launches Stockfish.
- `strength.js`, `avatars.js`, `clock.js`, `review.js`, `coaches.js`, `coach.js`, `prompts.js` provide bot, avatar, timing, review, coach, and model logic.
- `native.js` bridges HTTP, encrypted secret storage, engine, clipboard, and share.
- `lichess.js` contains opening explorer/tablebase references.
- `online.js` handles Supabase Auth, profile, presence, roster, direct challenges, and game polling.
- `supabase/functions/apply-online-move` plus `_shared/online-validation.mjs` validate a legal single move. `supabase/operations/validated_online_moves.sql` is a draft for service-only DB clock/race enforcement and disabling the old RPC; not deployed.

## Success gate
Node logic tests, Java policy tests, Deno function tests, Playwright UI tests, APK verification, stable signing, and two-device online match tests must pass. Maia/Lc0 has a separate acceptance gate for Android engine startup, model loading, clock behavior, memory, and legal moves.
