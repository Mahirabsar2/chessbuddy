# ChessBuddy 5.0 audit and implementation report

Date: 2026-11-16

## Attachment and branch audit
- Read the Claude master setup prompt and inspected both supplied source ZIPs.
- The two supplied v0.5.0 ZIP copies are byte-identical; v0.4.0 is a distinct earlier source snapshot.
- Recovered the exact patched source used for build 19 from GitHub Actions artifact `14165989715`; the attached v0.5.0 base ZIP matched the remote branch's source blob.
- Created `chessbuddy-5.0-final-dev` from `chessbuddy-0.5.0-dev`. Claude's 4.0 branch was not changed.

## Verified tests
- Node logic suite: 88/88 assertions passed, including UCI clocks, online client, optimized perft, SVG review icons, and the shared legal-move/clock validator.
- Java compile and URL/native transport policy tests passed.
- Playwright UI suite not run locally; workflow is being made portable and will install Playwright/Chromium.
- Deno Edge Function tests not run locally; Deno is not installed here, and CI will run them.
- Android Gradle/NDK build not run locally; toolchain absent, and GitHub Actions will build and verify the APK.

## Supabase read-only audit
- Five migrations are applied; four `chessbuddy_*` tables have RLS enabled.
- `cb_apply_move` is SECURITY DEFINER and currently executable by `authenticated`, `service_role`, and database admin roles. It accepts client-supplied FEN/PGN without replaying legal moves.
- No production DB changes were made.
- New Edge Function and service-only SQL hardening are prepared in source, but not deployed. Production moves remain unvalidated until both are deployed together.

## Security changes in working copy
- SecretStore no longer writes plaintext fallback values. Legacy plaintext is encrypted when possible or removed.
- The public Supabase publishable key is no longer persisted in the secret store; native transport supplies it only for the configured project API paths.
- Throwaway keystore file from supplied source removed from working copy; no key bytes were read or printed.
- Stable signing is not configured; user-controlled key is needed for update installs across releases.

## Remaining blockers
- Deploy and test `apply-online-move` plus `validated_online_moves.sql` only after explicit approval.
- Maia/Lc0 Android integration and Maia model licence/redistribution terms remain unresolved.
- Real two-device online tests and physical-device engine/memory tests remain.
