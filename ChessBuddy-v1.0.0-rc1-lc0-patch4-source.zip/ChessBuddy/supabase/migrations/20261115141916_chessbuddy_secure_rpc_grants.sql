-- Tighten the existing friend-play security-definer functions: no PUBLIC/anon execution.
revoke all privileges on table
  public.chessbuddy_profiles, public.chessbuddy_presence,
  public.chessbuddy_challenges, public.chessbuddy_games
from public, anon, authenticated;

grant select on table
  public.chessbuddy_profiles, public.chessbuddy_presence,
  public.chessbuddy_challenges, public.chessbuddy_games
to authenticated;

revoke all privileges on function public.cb_register_profile(text,text) from public, anon;
revoke all privileges on function public.cb_set_presence(text) from public, anon;
revoke all privileges on function public.cb_send_challenge(uuid,text,text) from public, anon;
revoke all privileges on function public.cb_respond_challenge(uuid,boolean) from public, anon;
revoke all privileges on function public.cb_cancel_challenge(uuid) from public, anon;
revoke all privileges on function public.cb_apply_move(uuid,text,text,bigint,bigint,boolean,text,uuid) from public, anon;

grant execute on function public.cb_register_profile(text,text) to authenticated;
grant execute on function public.cb_set_presence(text) to authenticated;
grant execute on function public.cb_send_challenge(uuid,text,text) to authenticated;
grant execute on function public.cb_respond_challenge(uuid,boolean) to authenticated;
grant execute on function public.cb_cancel_challenge(uuid) to authenticated;
grant execute on function public.cb_apply_move(uuid,text,text,bigint,bigint,boolean,text,uuid) to authenticated;
