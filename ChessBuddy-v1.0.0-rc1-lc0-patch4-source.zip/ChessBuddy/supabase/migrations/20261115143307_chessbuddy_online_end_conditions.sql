-- Add server-authorized resignation and timeout claims for direct friend games.
create or replace function public.cb_claim_timeout(p_game_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.chessbuddy_games; v_remaining_ms bigint; v_winner uuid;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into g from public.chessbuddy_games where id=p_game_id for update;
  if not found or g.status<>'active' then raise exception 'Game unavailable'; end if;
  if auth.uid() not in (g.white_user_id,g.black_user_id) then raise exception 'Not a participant'; end if;
  if g.time_control='none' or coalesce(g.pgn,'')='' then raise exception 'The clock has not started'; end if;
  v_remaining_ms := case when g.turn_color='w' then g.white_ms else g.black_ms end;
  if v_remaining_ms>0 and now() < g.updated_at + make_interval(secs => v_remaining_ms::double precision / 1000.0) then
    raise exception 'The active clock has not expired';
  end if;
  v_winner := case when g.turn_user_id=g.white_user_id then g.black_user_id else g.white_user_id end;
  update public.chessbuddy_games set status='finished',
    result=case when v_winner=g.white_user_id then '1-0' else '0-1' end,
    winner_user_id=v_winner,updated_at=now() where id=p_game_id;
end; $$;

create or replace function public.cb_resign_game(p_game_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.chessbuddy_games; v_winner uuid;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into g from public.chessbuddy_games where id=p_game_id for update;
  if not found or g.status<>'active' then raise exception 'Game unavailable'; end if;
  if auth.uid() not in (g.white_user_id,g.black_user_id) then raise exception 'Not a participant'; end if;
  v_winner := case when auth.uid()=g.white_user_id then g.black_user_id else g.white_user_id end;
  update public.chessbuddy_games set status='finished',
    result=case when v_winner=g.white_user_id then '1-0' else '0-1' end,
    winner_user_id=v_winner,updated_at=now() where id=p_game_id;
end; $$;

revoke all privileges on function public.cb_claim_timeout(uuid) from public, anon;
revoke all privileges on function public.cb_resign_game(uuid) from public, anon;
grant execute on function public.cb_claim_timeout(uuid) to authenticated;
grant execute on function public.cb_resign_game(uuid) to authenticated;
