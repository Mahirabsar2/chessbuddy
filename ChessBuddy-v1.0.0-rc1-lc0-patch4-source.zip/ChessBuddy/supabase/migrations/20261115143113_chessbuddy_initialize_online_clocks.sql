-- Start each timed friend match with the selected initial clock values.
create or replace function public.cb_respond_challenge(p_challenge_id uuid,p_accept boolean)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  c public.chessbuddy_challenges; v_game uuid; v_white uuid; v_black uuid; v_base_ms bigint;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into c from public.chessbuddy_challenges where id=p_challenge_id for update;
  if not found or c.to_user_id<>auth.uid() or c.status<>'pending' then raise exception 'Challenge unavailable'; end if;
  if c.expires_at<now() then update public.chessbuddy_challenges set status='expired' where id=c.id; return null; end if;
  if not p_accept then update public.chessbuddy_challenges set status='declined' where id=c.id; return null; end if;
  if c.from_color='w' then v_white:=c.from_user_id; v_black:=c.to_user_id;
  elsif c.from_color='b' then v_white:=c.to_user_id; v_black:=c.from_user_id;
  elsif random()<0.5 then v_white:=c.from_user_id; v_black:=c.to_user_id;
  else v_white:=c.to_user_id; v_black:=c.from_user_id; end if;
  v_base_ms := case c.time_control
    when '1+0' then 60000 when '3+0' then 180000 when '3+2' then 180000
    when '5+0' then 300000 when '10+0' then 600000 when '15+10' then 900000
    when '30+0' then 1800000 else 0 end;
  insert into public.chessbuddy_games(white_user_id,black_user_id,time_control,turn_user_id,turn_color,white_ms,black_ms)
    values(v_white,v_black,c.time_control,v_white,'w',v_base_ms,v_base_ms) returning id into v_game;
  update public.chessbuddy_challenges set status='accepted',game_id=v_game where id=c.id;
  return v_game;
end; $$;

revoke all privileges on function public.cb_respond_challenge(uuid,boolean) from public, anon;
grant execute on function public.cb_respond_challenge(uuid,boolean) to authenticated;
