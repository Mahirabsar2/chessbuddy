create extension if not exists pgcrypto;

create table if not exists public.chessbuddy_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint cb_username_format check (username ~ '^[a-z0-9_]{3,20}$'),
  constraint cb_display_name_len check (char_length(display_name) between 1 and 32)
);
create unique index if not exists chessbuddy_profiles_username_lower on public.chessbuddy_profiles (lower(username));

create table if not exists public.chessbuddy_presence (
  user_id uuid primary key references public.chessbuddy_profiles(user_id) on delete cascade,
  status text not null default 'online' check (status in ('online','away')),
  last_seen timestamptz not null default now()
);

create table if not exists public.chessbuddy_games (
  id uuid primary key default gen_random_uuid(),
  white_user_id uuid not null references public.chessbuddy_profiles(user_id),
  black_user_id uuid not null references public.chessbuddy_profiles(user_id),
  time_control text not null check (time_control in ('none','1+0','3+0','3+2','5+0','10+0','15+10','30+0')),
  initial_fen text not null default 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  current_fen text not null default 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  pgn text not null default '',
  turn_user_id uuid not null references public.chessbuddy_profiles(user_id),
  turn_color text not null default 'w' check (turn_color in ('w','b')),
  white_ms bigint not null default 0 check (white_ms >= 0),
  black_ms bigint not null default 0 check (black_ms >= 0),
  status text not null default 'active' check (status in ('active','finished','abandoned')),
  result text check (result is null or result in ('1-0','0-1','1/2-1/2')),
  winner_user_id uuid references public.chessbuddy_profiles(user_id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint cb_game_distinct_players check (white_user_id <> black_user_id),
  constraint cb_game_turn_is_player check (turn_user_id in (white_user_id, black_user_id)),
  constraint cb_game_winner_is_player check (winner_user_id is null or winner_user_id in (white_user_id, black_user_id))
);

create table if not exists public.chessbuddy_challenges (
  id uuid primary key default gen_random_uuid(),
  from_user_id uuid not null references public.chessbuddy_profiles(user_id) on delete cascade,
  to_user_id uuid not null references public.chessbuddy_profiles(user_id) on delete cascade,
  time_control text not null check (time_control in ('none','1+0','3+0','3+2','5+0','10+0','15+10','30+0')),
  from_color text not null default 'r' check (from_color in ('w','b','r')),
  status text not null default 'pending' check (status in ('pending','accepted','declined','cancelled','expired')),
  game_id uuid references public.chessbuddy_games(id),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '5 minutes',
  constraint cb_challenge_distinct_players check (from_user_id <> to_user_id)
);
create index if not exists chessbuddy_challenges_to_pending on public.chessbuddy_challenges (to_user_id, created_at desc) where status = 'pending';
create index if not exists chessbuddy_challenges_from_pending on public.chessbuddy_challenges (from_user_id, created_at desc) where status = 'pending';

alter table public.chessbuddy_profiles enable row level security;
alter table public.chessbuddy_presence enable row level security;
alter table public.chessbuddy_games enable row level security;
alter table public.chessbuddy_challenges enable row level security;

create policy cb_profiles_select_authenticated on public.chessbuddy_profiles for select to authenticated using (true);
create policy cb_presence_select_authenticated on public.chessbuddy_presence for select to authenticated using (true);
create policy cb_challenges_select_participants on public.chessbuddy_challenges for select to authenticated using ((select auth.uid()) in (from_user_id, to_user_id));
create policy cb_games_select_players on public.chessbuddy_games for select to authenticated using ((select auth.uid()) in (white_user_id, black_user_id));

grant select on public.chessbuddy_profiles, public.chessbuddy_presence, public.chessbuddy_challenges, public.chessbuddy_games to authenticated;
revoke insert, update, delete on public.chessbuddy_profiles, public.chessbuddy_presence, public.chessbuddy_challenges, public.chessbuddy_games from authenticated;

create or replace function public.cb_register_profile(p_username text, p_display_name text)
returns public.chessbuddy_profiles language plpgsql security definer set search_path = '' as $$
declare v public.chessbuddy_profiles;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if p_username is null or p_username !~ '^[a-z0-9_]{3,20}$' then raise exception 'Username must be 3–20 characters: lowercase letters, numbers, or underscores'; end if;
  if p_display_name is null or char_length(trim(p_display_name)) not between 1 and 32 then raise exception 'Display name must be 1–32 characters'; end if;
  insert into public.chessbuddy_profiles(user_id,username,display_name) values(auth.uid(),p_username,trim(p_display_name))
  on conflict (user_id) do update set username=excluded.username,display_name=excluded.display_name,updated_at=now() returning * into v;
  return v;
end; $$;

create or replace function public.cb_set_presence(p_status text default 'online')
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if p_status not in ('online','away') then raise exception 'Invalid presence status'; end if;
  insert into public.chessbuddy_presence(user_id,status,last_seen) values(auth.uid(),p_status,now())
  on conflict (user_id) do update set status=excluded.status,last_seen=excluded.last_seen;
end; $$;

create or replace function public.cb_send_challenge(p_to_user uuid,p_time_control text,p_color text default 'r')
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if p_to_user is null or p_to_user=auth.uid() then raise exception 'Choose another player'; end if;
  if p_time_control not in ('none','1+0','3+0','3+2','5+0','10+0','15+10','30+0') then raise exception 'Invalid time control'; end if;
  if p_color not in ('w','b','r') then raise exception 'Invalid colour preference'; end if;
  if not exists(select 1 from public.chessbuddy_profiles where user_id=p_to_user) then raise exception 'Player not found'; end if;
  insert into public.chessbuddy_challenges(from_user_id,to_user_id,time_control,from_color) values(auth.uid(),p_to_user,p_time_control,p_color) returning id into v_id;
  return v_id;
end; $$;

create or replace function public.cb_respond_challenge(p_challenge_id uuid,p_accept boolean)
returns uuid language plpgsql security definer set search_path = '' as $$
declare c public.chessbuddy_challenges; v_game uuid; v_white uuid; v_black uuid;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into c from public.chessbuddy_challenges where id=p_challenge_id for update;
  if not found or c.to_user_id<>auth.uid() or c.status<>'pending' then raise exception 'Challenge unavailable'; end if;
  if c.expires_at<now() then update public.chessbuddy_challenges set status='expired' where id=c.id; return null; end if;
  if not p_accept then update public.chessbuddy_challenges set status='declined' where id=c.id; return null; end if;
  if c.from_color='w' then v_white:=c.from_user_id; v_black:=c.to_user_id;
  elsif c.from_color='b' then v_white:=c.to_user_id; v_black:=c.from_user_id;
  elsif random()<0.5 then v_white:=c.from_user_id; v_black:=c.to_user_id;
  else v_white:=c.to_user_id; v_black:=c.from_user_id; end if;
  insert into public.chessbuddy_games(white_user_id,black_user_id,time_control,turn_user_id,turn_color) values(v_white,v_black,c.time_control,v_white,'w') returning id into v_game;
  update public.chessbuddy_challenges set status='accepted',game_id=v_game where id=c.id;
  return v_game;
end; $$;

create or replace function public.cb_cancel_challenge(p_challenge_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  update public.chessbuddy_challenges set status='cancelled' where id=p_challenge_id and from_user_id=auth.uid() and status='pending';
  if not found then raise exception 'Challenge unavailable'; end if;
end; $$;

create or replace function public.cb_apply_move(p_game_id uuid,p_next_fen text,p_pgn text,p_white_ms bigint,p_black_ms bigint,p_finished boolean default false,p_result text default null,p_winner uuid default null)
returns void language plpgsql security definer set search_path = '' as $$
declare g public.chessbuddy_games;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into g from public.chessbuddy_games where id=p_game_id for update;
  if not found or g.status<>'active' or g.turn_user_id<>auth.uid() then raise exception 'It is not your turn'; end if;
  if p_next_fen is null or char_length(p_next_fen)>256 or p_pgn is null or char_length(p_pgn)>12000 then raise exception 'Invalid game state'; end if;
  if p_white_ms<0 or p_black_ms<0 then raise exception 'Invalid clock'; end if;
  if p_finished and p_result not in ('1-0','0-1','1/2-1/2') then raise exception 'Invalid result'; end if;
  if p_winner is not null and p_winner not in (g.white_user_id,g.black_user_id) then raise exception 'Invalid winner'; end if;
  update public.chessbuddy_games set current_fen=p_next_fen,pgn=p_pgn,white_ms=p_white_ms,black_ms=p_black_ms,
    turn_user_id=case when g.turn_user_id=g.white_user_id then g.black_user_id else g.white_user_id end,
    turn_color=case when g.turn_color='w' then 'b' else 'w' end,
    status=case when p_finished then 'finished' else 'active' end,
    result=case when p_finished then p_result else null end,
    winner_user_id=case when p_finished then p_winner else null end,updated_at=now() where id=p_game_id;
end; $$;

revoke all on function public.cb_register_profile(text,text) from public;
revoke all on function public.cb_set_presence(text) from public;
revoke all on function public.cb_send_challenge(uuid,text,text) from public;
revoke all on function public.cb_respond_challenge(uuid,boolean) from public;
revoke all on function public.cb_cancel_challenge(uuid) from public;
revoke all on function public.cb_apply_move(uuid,text,text,bigint,bigint,boolean,text,uuid) from public;
grant execute on function public.cb_register_profile(text,text) to authenticated;
grant execute on function public.cb_set_presence(text) to authenticated;
grant execute on function public.cb_send_challenge(uuid,text,text) to authenticated;
grant execute on function public.cb_respond_challenge(uuid,boolean) to authenticated;
grant execute on function public.cb_cancel_challenge(uuid) to authenticated;
grant execute on function public.cb_apply_move(uuid,text,text,bigint,bigint,boolean,text,uuid) to authenticated;
