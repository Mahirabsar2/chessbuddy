-- DRAFT ONLY — do not apply until the apply-online-move Edge Function is deployed and tested.
-- The app must stop calling cb_apply_move directly before this is enabled.

create or replace function public.cb_apply_validated_move(
  p_game_id uuid,
  p_actor uuid,
  p_expected_updated_at timestamptz,
  p_next_fen text,
  p_pgn text,
  p_white_ms bigint,
  p_black_ms bigint,
  p_next_turn_color text,
  p_next_turn_user uuid,
  p_result text default null,
  p_winner uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  g public.chessbuddy_games;
  v_now timestamptz := clock_timestamp();
  v_increment_ms bigint := 0;
  v_elapsed_ms bigint := 0;
  v_expected_ms bigint := 0;
  v_submitted_ms bigint := 0;
  v_other_ms bigint := 0;
  v_accepted_ms bigint := 0;
  v_white_ms bigint := 0;
  v_black_ms bigint := 0;
begin
  select * into g from public.chessbuddy_games where id = p_game_id for update;
  if not found or g.status <> 'active' then raise exception 'game_unavailable'; end if;
  if g.updated_at is distinct from p_expected_updated_at then raise exception 'stale_game'; end if;
  if g.turn_user_id <> p_actor or p_actor not in (g.white_user_id, g.black_user_id) then raise exception 'not_your_turn'; end if;
  if p_next_fen is null or char_length(p_next_fen) > 256 or p_pgn is null or char_length(p_pgn) > 12000 then raise exception 'invalid_state'; end if;
  if p_white_ms < 0 or p_black_ms < 0 then raise exception 'invalid_clock'; end if;
  if p_next_turn_color is distinct from case when g.turn_color = 'w' then 'b' else 'w' end then raise exception 'invalid_turn'; end if;
  if p_next_turn_user is distinct from case when g.turn_color = 'w' then g.black_user_id else g.white_user_id end then raise exception 'invalid_turn'; end if;
  if p_result is not null and p_result not in ('1-0', '0-1', '1/2-1/2') then raise exception 'invalid_result'; end if;
  if (p_result = '1-0' and p_winner is distinct from g.white_user_id)
     or (p_result = '0-1' and p_winner is distinct from g.black_user_id)
     or (p_result = '1/2-1/2' and p_winner is not null)
     or (p_result is null and p_winner is not null) then raise exception 'invalid_winner'; end if;

  if g.time_control = 'none' then
    v_white_ms := 0;
    v_black_ms := 0;
  else
    v_increment_ms := split_part(g.time_control, '+', 2)::bigint * 1000;
    v_elapsed_ms := greatest(0, floor(extract(epoch from (v_now - g.updated_at)) * 1000)::bigint);
    v_expected_ms := greatest(0, (case when g.turn_color = 'w' then g.white_ms else g.black_ms end) - v_elapsed_ms);
    if v_expected_ms <= 0 then raise exception 'clock_expired'; end if;
    v_submitted_ms := case when g.turn_color = 'w' then p_white_ms else p_black_ms end;
    v_other_ms := case when g.turn_color = 'w' then p_black_ms else p_white_ms end;
    if v_submitted_ms > v_expected_ms + v_increment_ms + 2500 then raise exception 'clock_inflation'; end if;
    if abs(v_other_ms - (case when g.turn_color = 'w' then g.black_ms else g.white_ms end)) > 2500 then raise exception 'opponent_clock_changed'; end if;
    v_accepted_ms := least(v_submitted_ms, v_expected_ms + v_increment_ms);
    v_white_ms := case when g.turn_color = 'w' then v_accepted_ms else g.white_ms end;
    v_black_ms := case when g.turn_color = 'b' then v_accepted_ms else g.black_ms end;
  end if;

  update public.chessbuddy_games
  set current_fen = p_next_fen,
      pgn = p_pgn,
      white_ms = v_white_ms,
      black_ms = v_black_ms,
      turn_user_id = p_next_turn_user,
      turn_color = p_next_turn_color,
      status = case when p_result is null then 'active' else 'finished' end,
      result = p_result,
      winner_user_id = p_winner,
      updated_at = v_now
  where id = p_game_id
  returning * into g;

  return to_jsonb(g);
end;
$$;

revoke all on function public.cb_apply_validated_move(uuid,uuid,timestamptz,text,text,bigint,bigint,text,uuid,text,uuid) from public, anon, authenticated;
grant execute on function public.cb_apply_validated_move(uuid,uuid,timestamptz,text,text,bigint,bigint,text,uuid,text,uuid) to service_role;

-- Disable the old RPC because it accepts arbitrary client-supplied FEN/PGN without legal-move validation.
revoke all on function public.cb_apply_move(uuid,text,text,bigint,bigint,boolean,text,uuid) from public, anon, authenticated, service_role;
