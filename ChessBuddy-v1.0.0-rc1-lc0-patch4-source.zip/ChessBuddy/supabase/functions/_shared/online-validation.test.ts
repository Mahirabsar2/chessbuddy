import { Chess } from "chess.js";
import { validateOnlineMove } from "./online-validation.mjs";

const now = Date.now();
function game() {
  return {
    id: "00000000-0000-4000-8000-000000000001",
    white_user_id: "white-user",
    black_user_id: "black-user",
    time_control: "3+2",
    initial_fen: new Chess().fen(),
    current_fen: new Chess().fen(),
    pgn: "",
    turn_user_id: "white-user",
    turn_color: "w",
    white_ms: 180000,
    black_ms: 180000,
    status: "active",
    updated_at: new Date(now).toISOString(),
  };
}
function payloadFor(san: string) {
  const c = new Chess(); c.move(san);
  return { game_id: game().id, p_next_fen: c.fen(), p_pgn: c.pgn(), p_white_ms: 182000, p_black_ms: 180000 };
}

Deno.test("accepts exactly one legal move and derives next turn", () => {
  const g = game();
  const result = validateOnlineMove(Chess, g, payloadFor("e4"), "white-user", now);
  if (!result.ok) throw new Error(result.error);
  if (result.update.turn_color !== "b" || result.update.turn_user_id !== "black-user") throw new Error("turn did not advance");
  if (result.update.white_ms !== 182000 || result.update.black_ms !== 180000) throw new Error("clock increment was not handled");
});

Deno.test("rejects wrong player and moves that do not extend the saved PGN", () => {
  const g = game();
  const wrong = validateOnlineMove(Chess, g, payloadFor("e4"), "black-user", now);
  if (wrong.ok || wrong.status !== 409) throw new Error("wrong player was accepted");
  const payload = payloadFor("d4"); payload.p_pgn = "1. e4";
  const mismatch = validateOnlineMove(Chess, g, payload, "white-user", now);
  if (mismatch.ok) throw new Error("mismatched PGN/FEN was accepted");
});

Deno.test("rejects altered FEN and clock inflation", () => {
  const g = game();
  const badFen = payloadFor("e4"); badFen.p_next_fen = new Chess().fen();
  if (validateOnlineMove(Chess, g, badFen, "white-user", now).ok) throw new Error("altered FEN was accepted");
  const badClock = payloadFor("e4"); badClock.p_white_ms = 300000;
  if (validateOnlineMove(Chess, g, badClock, "white-user", now).ok) throw new Error("clock inflation was accepted");
});

Deno.test("rejects stale state and expired clocks", () => {
  const g = game(); g.updated_at = new Date(now - 181000).toISOString();
  const expired = validateOnlineMove(Chess, g, payloadFor("e4"), "white-user", now);
  if (expired.ok || expired.status !== 409) throw new Error("expired clock was accepted");
  g.updated_at = new Date(now).toISOString(); g.current_fen = "invalid";
  const stale = validateOnlineMove(Chess, g, payloadFor("e4"), "white-user", now);
  if (stale.ok || stale.status !== 409) throw new Error("stale state was accepted");
});
