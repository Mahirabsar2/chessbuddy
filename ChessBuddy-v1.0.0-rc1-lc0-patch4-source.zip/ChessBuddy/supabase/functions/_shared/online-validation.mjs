/**
 * Validate one legal online move. Chess is injected so this exact function can be tested in Node and used in Deno.
 * @param {any} Chess
 * @param {any} game
 * @param {any} payload
 * @param {string} userId
 * @param {number} [nowMs]
 * @returns {{ok: true, update: Record<string, any>} | {ok: false, status: number, error: string}}
 */
export function validateOnlineMove(Chess, game, payload, userId, nowMs = Date.now()) {
  const fail = (status, error) => ({ ok: false, status, error });
  if (!game || game.status !== "active") return fail(409, "Game is no longer active.");
  if (userId !== game.white_user_id && userId !== game.black_user_id) return fail(403, "You are not a player in this game.");
  if (game.turn_user_id !== userId) return fail(409, "It is not your turn.");
  const expectedMover = game.turn_color === "w" ? game.white_user_id : game.black_user_id;
  if (expectedMover !== userId) return fail(409, "The saved player-to-move is inconsistent.");
  if (payload.game_id !== game.id) return fail(400, "Game ID does not match.");
  if (typeof payload.p_next_fen !== "string" || payload.p_next_fen.length > 256) return fail(400, "Invalid FEN.");
  if (typeof payload.p_pgn !== "string" || payload.p_pgn.length > 12000) return fail(400, "Invalid PGN.");
  if (!Number.isSafeInteger(payload.p_white_ms) || !Number.isSafeInteger(payload.p_black_ms)
      || payload.p_white_ms < 0 || payload.p_black_ms < 0) return fail(400, "Invalid clock values.");

  let current, proposed;
  try {
    current = new Chess(game.initial_fen);
    if (game.pgn) current.loadPgn(game.pgn);
    proposed = new Chess(game.initial_fen);
    proposed.loadPgn(payload.p_pgn);
  } catch (_) {
    return fail(400, "The submitted game history is not valid chess.");
  }

  if (current.fen() !== game.current_fen) return fail(409, "The saved game position is inconsistent. Reload the game.");
  if (current.turn() !== game.turn_color) return fail(409, "The saved turn is inconsistent. Reload the game.");
  if (current.isGameOver()) return fail(409, "The game has already ended.");

  const before = current.history();
  const after = proposed.history();
  if (after.length !== before.length + 1 || !before.every((san, i) => after[i] === san)) {
    return fail(400, "A move must extend the current game by exactly one legal move.");
  }
  if (proposed.fen() !== payload.p_next_fen) return fail(400, "The submitted FEN does not match the legal PGN.");

  const mover = game.turn_color;
  let incrementMs = 0;
  if (game.time_control !== "none") {
    const match = /^(\d{1,3})\+(\d{1,3})$/.exec(game.time_control || "");
    if (!match) return fail(409, "Unsupported time control.");
    incrementMs = Number(match[2]) * 1000;
  }

  let whiteMs = 0;
  let blackMs = 0;
  if (game.time_control !== "none") {
    const updatedAt = Date.parse(game.updated_at);
    if (!Number.isFinite(updatedAt)) return fail(409, "The server clock is unavailable.");
    const elapsed = Math.max(0, nowMs - updatedAt);
    const storedMoverMs = mover === "w" ? Number(game.white_ms) : Number(game.black_ms);
    const storedOtherMs = mover === "w" ? Number(game.black_ms) : Number(game.white_ms);
    const submittedMoverMs = mover === "w" ? payload.p_white_ms : payload.p_black_ms;
    const submittedOtherMs = mover === "w" ? payload.p_black_ms : payload.p_white_ms;
    const expectedBeforeIncrement = Math.max(0, storedMoverMs - elapsed);
    const networkAllowanceMs = 2500;
    if (expectedBeforeIncrement <= 0) return fail(409, "Your clock has expired. Claim the timeout instead.");
    if (submittedMoverMs > expectedBeforeIncrement + incrementMs + networkAllowanceMs) {
      return fail(400, "The submitted clock adds time that was not earned.");
    }
    if (Math.abs(submittedOtherMs - storedOtherMs) > networkAllowanceMs) {
      return fail(400, "The opponent's clock cannot be changed on your move.");
    }
    const acceptedMoverMs = Math.min(submittedMoverMs, expectedBeforeIncrement + incrementMs);
    whiteMs = mover === "w" ? acceptedMoverMs : storedOtherMs;
    blackMs = mover === "b" ? acceptedMoverMs : storedOtherMs;
  }

  const finished = proposed.isGameOver();
  let result = null;
  let winner = null;
  if (finished) {
    if (proposed.isCheckmate()) result = proposed.turn() === "w" ? "0-1" : "1-0";
    else if (proposed.isDraw()) result = "1/2-1/2";
    else return fail(409, "The server could not classify the game ending.");
    winner = result === "1-0" ? game.white_user_id : result === "0-1" ? game.black_user_id : null;
  }

  return {
    ok: true,
    update: {
      current_fen: proposed.fen(),
      pgn: payload.p_pgn,
      white_ms: whiteMs,
      black_ms: blackMs,
      turn_user_id: proposed.turn() === "w" ? game.white_user_id : game.black_user_id,
      turn_color: proposed.turn(),
      status: finished ? "finished" : "active",
      result,
      winner_user_id: winner,
      updated_at: new Date(nowMs).toISOString(),
    },
  };
}
