import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { Chess } from "chess.js";
import { validateOnlineMove } from "../_shared/online-validation.mjs";

const projectUrl = (Deno.env.get("SUPABASE_URL") || "").replace(/\/$/, "");

function envMap(name: string): Record<string, string> {
  try { return JSON.parse(Deno.env.get(name) || "{}"); } catch { return {}; }
}
function keyFromMap(map: Record<string, string>): string {
  const envName = map.default || Object.values(map)[0] || "";
  return envName ? (Deno.env.get(envName) || "") : "";
}
const publishableKey = keyFromMap(envMap("SUPABASE_PUBLISHABLE_KEYS")) || Deno.env.get("SUPABASE_ANON_KEY") || "";
const serviceKey = keyFromMap(envMap("SUPABASE_SECRET_KEYS")) || Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return json({ error: "Method not allowed." }, 405);
  if (!projectUrl || !publishableKey || !serviceKey) return json({ error: "Online move service is not configured." }, 503);

  const authorization = req.headers.get("Authorization") || "";
  if (!authorization.startsWith("Bearer ")) return json({ error: "Sign in first." }, 401);

  let payload: { game_id: string; p_next_fen: string; p_pgn: string; p_white_ms: number; p_black_ms: number };
  try {
    const raw = await req.text();
    if (raw.length > 20000) return json({ error: "Move request is too large." }, 413);
    payload = JSON.parse(raw);
  } catch {
    return json({ error: "Invalid request body." }, 400);
  }
  if (!payload || typeof payload.game_id !== "string" || !/^[0-9a-f-]{36}$/i.test(payload.game_id)) {
    return json({ error: "Invalid game ID." }, 400);
  }

  try {
    const authResponse = await fetch(projectUrl + "/auth/v1/user", {
      headers: { apikey: publishableKey, Authorization: authorization },
    });
    if (!authResponse.ok) return json({ error: "Your sign-in has expired. Sign in again." }, 401);
    const user = await authResponse.json();
    if (!user || typeof user.id !== "string") return json({ error: "Sign in first." }, 401);

    const selectUrl = new URL(projectUrl + "/rest/v1/chessbuddy_games");
    selectUrl.searchParams.set("select", "id,white_user_id,black_user_id,time_control,initial_fen,current_fen,pgn,turn_user_id,turn_color,white_ms,black_ms,status,updated_at");
    selectUrl.searchParams.set("id", "eq." + payload.game_id);
    selectUrl.searchParams.set("limit", "1");
    const readResponse = await fetch(selectUrl, { headers: { apikey: serviceKey, Authorization: "Bearer " + serviceKey } });
    if (!readResponse.ok) return json({ error: "Could not load the game." }, 503);
    const rows = await readResponse.json();
    const game = Array.isArray(rows) ? rows[0] : undefined;
    if (!game) return json({ error: "Game not found." }, 404);

    const validation = validateOnlineMove(Chess, game, payload, user.id);
    if (!validation.ok) return json({ error: validation.error }, validation.status);

    const rpcResponse = await fetch(projectUrl + "/rest/v1/rpc/cb_apply_validated_move", {
      method: "POST",
      headers: {
        apikey: serviceKey,
        Authorization: "Bearer " + serviceKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        p_game_id: game.id,
        p_actor: user.id,
        p_expected_updated_at: game.updated_at,
        p_next_fen: validation.update.current_fen,
        p_pgn: payload.p_pgn,
        p_white_ms: payload.p_white_ms,
        p_black_ms: payload.p_black_ms,
        p_next_turn_color: validation.update.turn_color,
        p_next_turn_user: validation.update.turn_user_id,
        p_result: validation.update.result,
        p_winner: validation.update.winner_user_id,
      }),
    });
    if (!rpcResponse.ok) return json({ error: "The move could not be saved. Reload the game and try again." }, 409);
    const updated = await rpcResponse.json();
    if (!updated || typeof updated !== "object" || updated.id !== game.id) return json({ error: "The server did not confirm the move." }, 409);
    return json({ game: updated });
  } catch (error) {
    console.error("apply-online-move failed", error instanceof Error ? error.message : "unknown error");
    return json({ error: "Online move validation failed. Try again." }, 500);
  }
});
