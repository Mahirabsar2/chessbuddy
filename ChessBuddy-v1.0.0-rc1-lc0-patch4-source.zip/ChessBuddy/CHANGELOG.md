# Changelog

## 1.0.0 release candidate 1 — 2026-11-17

- Consolidated the 5.0 development game baseline with selected 0.5.0 authentication and diagnostics work.
- Added an animated startup splash followed by account onboarding, Google sign-in, email/password sign-in and account creation, plus offline continuation.
- Added Supabase Google OAuth PKCE, deep-link return, access-token validation, native encrypted refresh-token storage, email confirmation verification, resend, and password recovery.
- Fixed the native callback session response dropping the validated access token before it reached the JavaScript session.
- Added session refresh-and-retry for HTTP 401 only; permission errors remain explicit.
- Added user-readable diagnostics folder and privacy-filtered operational JSONL logs.
- Added Rust JNI move-legality cross-check and Android ARM64 build script.
- Preserved bot roster, Stockfish/Lc0/Maia integration, clocks, AI-vs-AI, local play, analysis/review, coaches, Lichess references, archive and backup/restore.
- Added auth, onboarding, diagnostics, tech-stack, feature-matrix, setup and release-gate documentation.
- Added regression coverage for Google PKCE, confirmation links, session restoration, recovery, presence gating and 401 refresh behaviour.

This is a release-candidate source snapshot. The Android APK/NDK/Rust build, Playwright UI suite, Deno suite, live provider configuration and real-device/two-device tests remain release gates.
