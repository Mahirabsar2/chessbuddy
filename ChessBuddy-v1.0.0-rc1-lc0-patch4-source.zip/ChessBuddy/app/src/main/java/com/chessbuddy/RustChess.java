package com.chessbuddy;

/** Optional native rules cross-check. chess.js remains the UI rules model; Rust independently verifies human moves. */
final class RustChess {
    private static final boolean LOADED;
    static {
        boolean loaded;
        try { System.loadLibrary("chessbuddy_core"); loaded = true; }
        catch (UnsatisfiedLinkError | SecurityException ignored) { loaded = false; }
        LOADED = loaded;
    }

    private RustChess() {}

    static boolean isLoaded() { return LOADED; }

    static boolean isLegalMove(String fen, String uci) {
        if (!LOADED || fen == null || uci == null) return false;
        try { return nativeIsLegalMove(fen, uci); }
        catch (LinkageError | RuntimeException e) { return false; }
    }

    private static native boolean nativeIsLegalMove(String fen, String uci);
}
