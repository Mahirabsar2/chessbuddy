package com.chessbuddy;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Writes operational diagnostics to Documents/ChessBuddy/Logs without recording credentials or source. */
final class DiagnosticsLog {
    private static final String ROOT = Environment.DIRECTORY_DOCUMENTS + "/ChessBuddy/";
    private static final String LOGS = ROOT + "Logs/";
    private static final long MAX_LOG_BYTES = 2L * 1024L * 1024L;
    private final Context context;
    private final File privateLogs;
    private boolean readmeChecked;
    private volatile boolean publicStorageAvailable;
    private volatile boolean privateStorageAvailable;

    DiagnosticsLog(Context context) {
        this.context = context.getApplicationContext();
        this.privateLogs = new File(new File(this.context.getFilesDir(), "ChessBuddy"), "Logs");
    }

    synchronized void log(String level, String event, String detail) {
        String now = isoNow();
        String safeEvent = clean(event, 80);
        String safeDetail = clean(detail, 500);
        String line = "{\"time\":" + Json.quote(now) + ",\"level\":" + Json.quote(clean(level, 12))
            + ",\"event\":" + Json.quote(safeEvent) + ",\"detail\":" + Json.quote(safeDetail)
            + ",\"appVersion\":" + Json.quote(appVersion()) + ",\"androidSdk\":" + Build.VERSION.SDK_INT + "}\n";
        byte[] bytes;
        try { bytes = line.getBytes("UTF-8"); } catch (Exception e) { return; }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                ensureReadme();
                String date = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
                Uri target = null;
                for (int part = 1; part <= 99 && target == null; part++) {
                    String suffix = part == 1 ? "" : "_part" + part;
                    target = findOrCreate("app_" + date + suffix + ".jsonl", LOGS, "application/x-ndjson", MAX_LOG_BYTES, true);
                }
                if (target != null) {
                    OutputStream out = context.getContentResolver().openOutputStream(target, "wa");
                    if (out != null) {
                        try { out.write(bytes); out.flush(); } finally { out.close(); }
                        publicStorageAvailable = true;
                        return;
                    }
                }
            } catch (Exception ignored) { /* fall back to private diagnostics below */ }
        }
        appendPrivate(bytes);
    }

    synchronized String location() {
        if (Build.VERSION.SDK_INT >= 29 && publicStorageAvailable) return "Documents/ChessBuddy/Logs/";
        if (privateStorageAvailable || Build.VERSION.SDK_INT < 29) return privateLogs.getAbsolutePath() + " (Android app storage)";
        return "Documents/ChessBuddy/Logs/ (not writable yet)";
    }

    private void ensureReadme() {
        if (readmeChecked) return;
        readmeChecked = true;
        try {
            Uri existing = findExisting("README.txt", ROOT);
            if (existing != null) return;
            Uri uri = findOrCreate("README.txt", ROOT, "text/plain", Long.MAX_VALUE, false);
            if (uri == null) return;
            String text = "ChessBuddy app data\n\n"
                + "Logs are stored in Documents/ChessBuddy/Logs as daily JSON Lines files.\n"
                + "They record app events, feature transitions, network result metadata, engine lifecycle events, and errors.\n\n"
                + "For privacy and security, logs never include passwords, email addresses, phone numbers, OTPs, authorization codes, access tokens, refresh tokens, API keys, authorization headers, raw network bodies, source code, or private game/chat contents.\n"
                + "You can share a log file with support when reporting a bug. Review it before sharing.\n";
            OutputStream out = context.getContentResolver().openOutputStream(uri, "w");
            if (out != null) { try { out.write(text.getBytes("UTF-8")); out.flush(); } finally { out.close(); } }
        } catch (Exception ignored) { /* diagnostics must never stop the app */ }
    }

    private Uri findOrCreate(String name, String folder, String mime, long limit, boolean usePart) {
        Uri current = findExisting(name, folder);
        if (current != null) {
            if (!usePart || existingSize(current) < limit) return current;
            return null;
        }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
            values.put(MediaStore.MediaColumns.IS_PENDING, 0);
            return context.getContentResolver().insert(MediaStore.Files.getContentUri("external"), values);
        } catch (Exception e) { return null; }
    }

    private Uri findExisting(String name, String folder) {
        Cursor c = null;
        try {
            Uri collection = MediaStore.Files.getContentUri("external");
            c = context.getContentResolver().query(collection,
                new String[]{MediaStore.MediaColumns._ID},
                MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                new String[]{name, folder}, null);
            if (c != null && c.moveToFirst()) return Uri.withAppendedPath(collection, c.getString(0));
        } catch (Exception ignored) { }
        finally { if (c != null) c.close(); }
        return null;
    }

    private long existingSize(Uri uri) {
        Cursor c = null;
        try {
            c = context.getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getLong(0);
        } catch (Exception ignored) { }
        finally { if (c != null) c.close(); }
        return 0;
    }

    private void appendPrivate(byte[] bytes) {
        try {
            if (!privateLogs.exists() && !privateLogs.mkdirs()) return;
            String date = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
            File file = null;
            for (int part = 1; part <= 99; part++) {
                String suffix = part == 1 ? "" : "_part" + part;
                File candidate = new File(privateLogs, "app_" + date + suffix + ".jsonl");
                if (!candidate.exists() || candidate.length() < MAX_LOG_BYTES) { file = candidate; break; }
            }
            if (file == null) return;
            FileOutputStream out = new FileOutputStream(file, true);
            try { out.write(bytes); out.flush(); } finally { out.close(); }
            privateStorageAvailable = true;
        } catch (Exception ignored) { }
    }

    private String appVersion() {
        try { return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName; }
        catch (Exception e) { return "unknown"; }
    }

    private static String isoNow() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date());
    }

    private static String clean(String value, int max) {
        if (value == null) return "";
        String s = value.replaceAll("[\\r\\n\\t]", " ").trim();
        s = s.replaceAll("(?i)[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", "[email redacted]");
        s = s.replaceAll("(?i)(access_token|refresh_token|password|authorization|api[_-]?key|client_secret|secret|token|code_verifier|auth_code|token_hash|otp|phone|code)(\\s*[:=]\\s*)[^ ,;]+", "$1$2[redacted]");
        s = s.replaceAll("(?<!\\w)\\+?[0-9][0-9 ()-]{7,}[0-9](?!\\w)", "[phone redacted]");
        s = s.replaceAll("[A-Za-z0-9_-]{24,}\\.[A-Za-z0-9_-]{16,}\\.[A-Za-z0-9_-]{16,}", "[jwt redacted]");
        return s.length() > max ? s.substring(0, max) : s;
    }
}
