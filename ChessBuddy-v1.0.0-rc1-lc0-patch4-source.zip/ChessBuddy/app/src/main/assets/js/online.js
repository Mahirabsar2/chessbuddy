/* ChessBuddy private friend-play client. Native HTTP only; no service-role key or browser token storage. */
(function (root) {
  'use strict';
  var URL = 'https://npicptuurxuqxepxzumi.supabase.co';
  var KEY = 'sb_publishable_ZRVaTdi8h8IPoL8srCD6Ww_uCf7smm4';
  var KEY_ID = 'cb_supabase_public';
  var CALLBACK = 'chessbuddy://auth-callback';
  var session = null;

  function parse(s) { if (s && typeof s === 'object') return s; try { return JSON.parse(s); } catch (_) { return null; } }
  function unwrap(data) {
    var d = data || {};
    if (d.data && d.data.session) d = d.data.session;
    else if (d.session) d = d.session;
    else if (d.result && d.result.session) d = d.result.session;
    else if (d.data && (d.data.access_token || d.data.user)) d = d.data;
    return d || {};
  }
  function message(body, fallback) {
    var x = parse(body);
    return x && (x.msg || x.message || x.error_description || x.error || x.hint) || fallback || 'The server rejected the request.';
  }
  function log(event, detail) {
    try { if (root.CBNative && root.CBNative.logEvent) root.CBNative.logEvent(event, detail || ''); } catch (_) {}
  }
  function acceptSession(data) {
    var d = unwrap(data), access = d && (d.access_token || d.accessToken), user = d && d.user;
    if (!access || typeof access !== 'string' || access.length < 20) return false;
    session = { accessToken: access, user: user || (session && session.user) || null };
    return true;
  }
  function auth(operation, payload) {
    log('auth.request', 'operation=' + operation);
    return root.CBNative.supabaseAuth(operation, payload).promise.then(function (r) {
      if (r.kind) throw new Error(r.message || 'Authentication network error (' + r.kind + ').');
      var data = parse(r.body);
      if (r.status < 200 || r.status >= 300) {
        log('auth.rejected', 'operation=' + operation + ' status=' + r.status + ' kind=' + (r.kind || 'http'));
        throw new Error(message(r.body, 'Authentication failed (HTTP ' + r.status + ').'));
      }
      if (data && (data.access_token || data.data || data.session || data.result)) acceptSession(data);
      if (operation === 'session' && !signedIn()) {
        throw new Error('Supabase validated the callback but did not return a usable session. Sign in again.');
      }
      if (operation === 'logout') session = null;
      if ((operation === 'signin' || operation === 'refresh' || operation === 'exchange' || operation === 'verify') && !signedIn()) {
        throw new Error('Authentication returned success but no usable session token and user. Check the Supabase Auth response.');
      }
      log('auth.success', 'operation=' + operation + ' hasSession=' + signedIn());
      return data || {};
    }).catch(function (e) {
      log('auth.error', 'operation=' + operation + ' type=' + (e && e.name || 'Error'));
      throw e;
    });
  }
  function headers() {
    if (!signedIn()) throw new Error('Sign in to use online play.');
    return 'apikey: ' + KEY + '\nAuthorization: Bearer ' + session.accessToken;
  }
  function send(method, path, body, retried) {
    var url = URL + '/rest/v1/' + path, h, started = Date.now(), safePath = String(path || '').split('?')[0];
    try { h = headers(); } catch (e) { return Promise.reject(e); }
    log('online.request', method + ' ' + safePath);
    var handle = method === 'GET' ? root.CBNative.httpGet(url, h) : root.CBNative.http({ keyId: KEY_ID, authScheme: 'none', url: url, extraHeaders: h, body: JSON.stringify(body || {}) });
    return handle.promise.then(function (r) {
      if (r.kind) { log('online.request_failed', method + ' ' + safePath + ' kind=' + r.kind + ' durationMs=' + (Date.now() - started)); throw new Error(r.message || 'Online request failed (' + r.kind + ').'); }
      if (r.status === 401 && !retried) {
        log('auth.expired', 'Refreshing session after HTTP 401');
        return auth('refresh', {}).then(function () { return send(method, path, body, true); });
      }
      if (r.status < 200 || r.status >= 300) { log('online.request_failed', method + ' ' + safePath + ' status=' + r.status + ' durationMs=' + (Date.now() - started)); throw new Error(message(r.body, 'Online request failed (HTTP ' + r.status + ').')); }
      log('online.request_succeeded', method + ' ' + safePath + ' status=' + r.status + ' durationMs=' + (Date.now() - started));
      var value = parse(r.body);
      return value == null ? r.body : value;
    });
  }
  function rpc(name, args) { return send('POST', 'rpc/' + name, args, false); }
  function invoke(name, body, retried) {
    var h, started = Date.now();
    try { h = headers(); } catch (e) { return Promise.reject(e); }
    log('online.edge_request', 'function=' + name);
    var handle = root.CBNative.http({ keyId: KEY_ID, authScheme: 'none', url: URL + '/functions/v1/' + name,
      extraHeaders: h, body: JSON.stringify(body || {}) });
    return handle.promise.then(function (r) {
      if (r.kind) { log('online.edge_failed', 'function=' + name + ' kind=' + r.kind + ' durationMs=' + (Date.now() - started)); throw new Error(r.message || 'Online request failed (' + r.kind + ').'); }
      if (r.status === 401 && !retried) return auth('refresh', {}).then(function () { return invoke(name, body, true); });
      if (r.status < 200 || r.status >= 300) { log('online.edge_failed', 'function=' + name + ' status=' + r.status + ' durationMs=' + (Date.now() - started)); throw new Error(message(r.body, 'Online request failed (HTTP ' + r.status + ').')); }
      log('online.edge_succeeded', 'function=' + name + ' status=' + r.status + ' durationMs=' + (Date.now() - started));
      var value = parse(r.body);
      return value == null ? r.body : value;
    });
  }
  function query(table, params) { return send('GET', table + '?' + params, null, false); }
  function signedIn() { return !!(session && session.accessToken && session.user && session.user.id); }

  function signInWithGoogle() {
    if (!root.CBNative || !root.CBNative.createAuthChallenge || !root.CBNative.openAuthUrl) {
      return Promise.reject(new Error('Google sign-in requires the updated ChessBuddy Android app.'));
    }
    var challenge = parse(root.CBNative.createAuthChallenge());
    if (!challenge || !challenge.challenge) return Promise.reject(new Error('ChessBuddy could not securely prepare Google sign-in. Check Android secure storage.'));
    var url = URL + '/auth/v1/authorize?provider=google&redirect_to=' + encodeURIComponent(CALLBACK) +
      '&code_challenge=' + encodeURIComponent(challenge.challenge) + '&code_challenge_method=s256';
    if (!root.CBNative.openAuthUrl(url)) return Promise.reject(new Error('ChessBuddy could not open the secure Google sign-in page.'));
    log('auth.google_started', 'Google OAuth browser flow opened');
    return Promise.resolve({ opened: true });
  }

  function callbackParams(raw) {
    var u = new URLSearchParams();
    var source = String(raw || '');
    var q = source.indexOf('?'), hash = source.indexOf('#');
    if (q >= 0) {
      var end = hash >= 0 && hash > q ? hash : source.length;
      new URLSearchParams(source.slice(q + 1, end)).forEach(function (v, k) { u.set(k, v); });
    }
    if (hash >= 0) new URLSearchParams(source.slice(hash + 1)).forEach(function (v, k) { u.set(k, v); });
    return u;
  }
  function handleAuthCallback(raw) {
    var params = callbackParams(raw);
    var problem = params.get('error_description') || params.get('error');
    if (problem) return Promise.reject(new Error(problem.replace(/\+/g, ' ')));
    var code = params.get('code'), tokenHash = params.get('token_hash') || params.get('token'), access = params.get('access_token'), refresh = params.get('refresh_token');
    var callbackType = params.get('type') || '';
    function tag(result) { result = result || {}; result.__chessbuddy_callback_type = callbackType; return result; }
    if (code) return auth('exchange', { auth_code: code }).then(tag);
    if (tokenHash) return auth('verify', { token: tokenHash, type: callbackType || 'signup' }).then(tag);
    if (access) return auth('session', { access_token: access, refresh_token: refresh || '' }).then(tag);
    return Promise.reject(new Error('Google or email verification returned without an authorization code or session. Start sign-in again.'));
  }
  root.cbAuthCallback = function (raw) {
    log('auth.callback_dispatched', 'Deep-link callback handed to online auth');
    handleAuthCallback(raw).then(function (result) {
      if (root.dispatchEvent && typeof root.CustomEvent === 'function') root.dispatchEvent(new root.CustomEvent('chessbuddy-auth-callback', { detail: { signedIn: signedIn(), recovery: result && result.__chessbuddy_callback_type === 'recovery' } }));
    }).catch(function (e) {
      log('auth.callback_failed', 'Callback processing failed: ' + (e && e.name || 'Error'));
      if (root.dispatchEvent && typeof root.CustomEvent === 'function') root.dispatchEvent(new root.CustomEvent('chessbuddy-auth-callback-error', { detail: { message: e.message || 'Sign-in callback failed.' } }));
    });
  };

  var api = {
    available: !!(root.CBNative && root.CBNative.available),
    signedIn: signedIn,
    user: function () { return session && session.user || null; },
    signUp: function (email, password) { return auth('signup', { email: email, password: password }); },
    signIn: function (email, password) { return auth('signin', { email: email, password: password }); },
    signInWithGoogle: signInWithGoogle,
    resetPassword: function (email) { return auth('recover', { email: email }); },
    resendConfirmation: function (email) { return auth('resend', { type: 'signup', email: email }); },
    updatePassword: function (password) {
      if (!signedIn()) return Promise.reject(new Error('Your recovery session has expired. Request another password reset email.'));
      return auth('updatePassword', { access_token: session.accessToken, password: password });
    },
    handleAuthCallback: handleAuthCallback,
    restore: function () { return auth('refresh', {}).catch(function (e) { session = null; throw e; }); },
    signOut: function () { var token = session && session.accessToken; return auth('logout', { access_token: token || '' }); },
    profile: function () {
      if (!signedIn()) return Promise.reject(new Error('Sign in to load your player profile.'));
      var id = api.user().id;
      return query('chessbuddy_profiles', 'select=user_id,username,display_name&user_id=eq.' + encodeURIComponent(id) + '&limit=1').then(function (rows) { return rows && rows[0] || null; });
    },
    registerProfile: function (username, displayName) { return rpc('cb_register_profile', { p_username: username, p_display_name: displayName }); },
    setPresence: function (status) {
      if (!signedIn()) return Promise.reject(new Error('Your account session is missing. Sign in again before changing online status.'));
      return rpc('cb_set_presence', { p_status: status || 'online' });
    },
    roster: function () {
      return Promise.all([
        query('chessbuddy_profiles', 'select=user_id,username,display_name&order=username.asc&limit=200'),
        query('chessbuddy_presence', 'select=user_id,status,last_seen&limit=200')
      ]).then(function (both) {
        var presence = {}, cutoff = Date.now() - 120000;
        (both[1] || []).forEach(function (p) { presence[p.user_id] = p; });
        return (both[0] || []).filter(function (p) { return p.user_id !== api.user().id; }).map(function (p) {
          var s = presence[p.user_id], live = !!(s && new Date(s.last_seen).getTime() > cutoff);
          return { user_id: p.user_id, username: p.username, display_name: p.display_name, online: live && s.status === 'online', last_seen: s && s.last_seen || null };
        }).sort(function (a, b) { return Number(b.online) - Number(a.online) || a.display_name.localeCompare(b.display_name); });
      });
    },
    challenges: function () {
      var id = api.user().id, or = encodeURIComponent('(from_user_id.eq.' + id + ',to_user_id.eq.' + id + ')');
      return query('chessbuddy_challenges', 'select=id,from_user_id,to_user_id,time_control,from_color,status,game_id,created_at,expires_at&or=' + or + '&status=eq.pending&expires_at=gte.' + encodeURIComponent(new Date().toISOString()) + '&order=created_at.desc&limit=40');
    },
    sendChallenge: function (userId, timeControl, color) { return rpc('cb_send_challenge', { p_to_user: userId, p_time_control: timeControl, p_color: color || 'r' }); },
    respondChallenge: function (challengeId, accept) { return rpc('cb_respond_challenge', { p_challenge_id: challengeId, p_accept: !!accept }); },
    cancelChallenge: function (challengeId) { return rpc('cb_cancel_challenge', { p_challenge_id: challengeId }); },
    game: function (gameId) {
      return query('chessbuddy_games', 'select=id,white_user_id,black_user_id,time_control,initial_fen,current_fen,pgn,turn_user_id,turn_color,white_ms,black_ms,status,result,winner_user_id,updated_at&id=eq.' + encodeURIComponent(gameId) + '&limit=1').then(function (rows) { return rows && rows[0] || null; });
    },
    activeGames: function () {
      var id = api.user().id, or = encodeURIComponent('(white_user_id.eq.' + id + ',black_user_id.eq.' + id + ')');
      return query('chessbuddy_games', 'select=id,white_user_id,black_user_id,time_control,current_fen,pgn,turn_user_id,turn_color,white_ms,black_ms,status,result,winner_user_id,updated_at&or=' + or + '&status=eq.active&order=updated_at.desc&limit=20');
    },
    resignGame: function (gameId) { return rpc('cb_resign_game', { p_game_id: gameId }); },
    claimTimeout: function (gameId) { return rpc('cb_claim_timeout', { p_game_id: gameId }); },
    applyMove: function (g) {
      return invoke('apply-online-move', {
        game_id: g.id, p_next_fen: g.fen, p_pgn: g.pgn,
        p_white_ms: Math.max(0, Math.floor(g.whiteMs)), p_black_ms: Math.max(0, Math.floor(g.blackMs))
      }, false);
    },
    clearMemorySession: function () { session = null; }
  };
  root.CBOnline = api;
})(typeof window !== 'undefined' ? window : globalThis);
