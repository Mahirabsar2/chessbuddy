/* Public Lichess reference tools: opening explorer and endgame tablebase. No account token is used. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory;
  else root.CBLichess = factory(root.CBNative);
})(typeof window !== 'undefined' ? window : globalThis, function (Native) {
  'use strict';
  function create(api) {
    var cache = new Map(), lastRequest = 0, pending = null, blockedUntil = 0;
    function request(url, key) {
      if (cache.has(key)) return Promise.resolve(cache.get(key));
      if (!api || typeof api.httpGet !== 'function') return Promise.reject(new Error('This tool needs the ChessBuddy Android app.'));
      if (pending) return Promise.reject(new Error('Lichess is already answering another request. Try again in a moment.'));
      if (Date.now() < blockedUntil) return Promise.reject(new Error('Lichess asked us to pause requests after a rate limit. Try again in about a minute.'));
      var wait = Math.max(0, 1300 - (Date.now() - lastRequest));
      pending = new Promise(function (resolve) { setTimeout(resolve, wait); }).then(function () {
        lastRequest = Date.now();
        return api.httpGet(url).promise;
      }).then(function (r) {
        if (!r || r.status < 200 || r.status >= 300) {
          if (r && r.status === 429) blockedUntil = Date.now() + 60000;
          var msg = r && r.status === 429 ? 'Lichess rate limit reached. Requests are paused for one minute.' : (r && r.message) || ('Lichess returned HTTP ' + (r ? r.status : 0));
          throw new Error(msg);
        }
        var data;
        try { data = JSON.parse(r.body); } catch (e) { throw new Error('Lichess returned an unreadable response.'); }
        cache.set(key, data);
        var expiry = setTimeout(function () { cache.delete(key); }, 120000);
        if (expiry && typeof expiry.unref === 'function') expiry.unref();
        return data;
      }).finally(function () { pending = null; });
      return pending;
    }
    function explorer(fen, source) {
      source = source === 'masters' ? 'masters' : 'lichess';
      var url = 'https://explorer.lichess.ovh/' + source + '?fen=' + encodeURIComponent(fen) + '&moves=12&topGames=0&recentGames=0';
      return request(url, 'explorer:' + source + ':' + fen);
    }
    function tablebase(fen) {
      return request('https://tablebase.lichess.org/standard?fen=' + encodeURIComponent(fen), 'tablebase:' + fen);
    }
    return { explorer: explorer, tablebase: tablebase, clearCache: function () { cache.clear(); } };
  }
  return create(Native);
});
