const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
console.log('online.js (Supabase client)');

function setup() {
  const calls = [];
  global.CBNative = {
    available: true,
    supabaseAuth: (op, payload) => {
      calls.push({ type: 'auth', op, payload });
      const result = op === 'signin' || op === 'refresh'
        ? { status: 200, body: JSON.stringify({ access_token: 'access-token-for-tests-123456', user: { id: 'me-uuid' }, refresh_token: '[stored natively]' }) }
        : { status: 200, body: '{}' };
      return { promise: Promise.resolve(result) };
    },
    httpGet: (url, headers) => {
      calls.push({ type: 'get', url, headers });
      let body = '[]';
      if (url.includes('/chessbuddy_profiles?')) body = JSON.stringify([
        { user_id: 'other', username: 'friend_1', display_name: 'Friend' },
        { user_id: 'me-uuid', username: 'my_name', display_name: 'Me' }
      ]);
      if (url.includes('/chessbuddy_presence?')) body = JSON.stringify([{ user_id: 'other', status: 'online', last_seen: new Date().toISOString() }]);
      if (url.includes('/chessbuddy_games?')) body = JSON.stringify([{ id: 'game-uuid' }]);
      return { promise: Promise.resolve({ status: 200, body }) };
    },
    http: req => {
      calls.push({ type: 'post', req });
      return { promise: Promise.resolve({ status: 200, body: '"challenge-id"' }) };
    }
  };
  delete require.cache[require.resolve('../../app/src/main/assets/js/online.js')];
  require('../../app/src/main/assets/js/online.js');
  return { api: global.CBOnline, calls };
}

test('keeps access tokens in memory and never persists the public key in the secret store', async () => {
  const { api, calls } = setup();
  assert.strictEqual(calls.some(c => c.type === 'setKey'), false);
  await api.signIn('player@example.com', 'a-password');
  assert.strictEqual(api.signedIn(), true);
  assert.strictEqual(api.user().id, 'me-uuid');
  const auth = calls.find(c => c.type === 'auth');
  assert.strictEqual(auth.op, 'signin');
  assert.deepStrictEqual(auth.payload, { email: 'player@example.com', password: 'a-password' });
});

test('roster combines profiles and a fresh presence heartbeat', async () => {
  const { api } = setup();
  await api.signIn('player@example.com', 'a-password');
  const roster = await api.roster();
  assert.strictEqual(roster.length, 1);
  assert.strictEqual(roster[0].username, 'friend_1');
  assert.strictEqual(roster[0].online, true);
});

test('direct challenge uses the expected authenticated RPC and never matchmaking', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  const id = await api.sendChallenge('opponent-uuid', '3+2', 'w');
  assert.strictEqual(id, 'challenge-id');
  const post = calls.find(c => c.type === 'post').req;
  assert.ok(post.url.endsWith('/rpc/cb_send_challenge'));
  assert.strictEqual(post.authScheme, 'none');
  assert.ok(post.extraHeaders.includes('Authorization: Bearer access-token-for-tests-123456'));
  assert.deepStrictEqual(JSON.parse(post.body), { p_to_user: 'opponent-uuid', p_time_control: '3+2', p_color: 'w' });
});

test('game lookup uses a valid PostgREST id filter', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  const game = await api.game('game-uuid');
  assert.strictEqual(game.id, 'game-uuid');
  const get = calls.find(c => c.type === 'get' && c.url.includes('/chessbuddy_games?'));
  assert.ok(get.url.includes('&id=eq.game-uuid'));
  assert.ok(!get.url.includes('& id='));
});

test('move submission uses the server validator instead of the legacy client-trusting RPC', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  await api.applyMove({ id: 'game-uuid', fen: 'fen-after', pgn: '1. e4', whiteMs: 120000, blackMs: 180000 });
  const post = calls.find(c => c.type === 'post').req;
  assert.ok(post.url.endsWith('/functions/v1/apply-online-move'));
  assert.strictEqual(post.authScheme, 'none');
  assert.ok(post.extraHeaders.includes('Authorization: Bearer access-token-for-tests-123456'));
  assert.deepStrictEqual(JSON.parse(post.body), { game_id: 'game-uuid', p_next_fen: 'fen-after', p_pgn: '1. e4', p_white_ms: 120000, p_black_ms: 180000 });
});

test('timeout and resignation use authenticated participant RPCs', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  await api.claimTimeout('game-uuid');
  await api.resignGame('game-uuid');
  const posts = calls.filter(c => c.type === 'post').map(c => c.req);
  assert.ok(posts.some(p => p.url.endsWith('/rpc/cb_claim_timeout')));
  assert.ok(posts.some(p => p.url.endsWith('/rpc/cb_resign_game')));
});

test('sign out clears the in-memory session', async () => {
  const { api } = setup();
  await api.signIn('player@example.com', 'a-password');
  await api.signOut();
  assert.strictEqual(api.signedIn(), false);
  assert.strictEqual(api.user(), null);
});

done('online.js');
