const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
console.log('online authentication (email, Google PKCE, recovery, session refresh)');

function setup() {
  const calls = [], getResults = [], events = [];
  let signinToken = 'access-token-old-123456789012345';
  global.dispatchEvent = event => { events.push(event); return true; };
  if (typeof global.CustomEvent !== 'function') global.CustomEvent = function (name, options) { this.type = name; this.detail = options && options.detail || {}; };
  global.CBNative = {
    available: true,
    createAuthChallenge: () => JSON.stringify({ challenge: 'test-s256-challenge' }),
    openAuthUrl: url => { calls.push({ type: 'open', url }); return true; },
    logEvent: (event, detail) => calls.push({ type: 'log', event, detail }),
    supabaseAuth: (op, payload) => {
      calls.push({ type: 'auth', op, payload });
      let body;
      if (op === 'signin') body = { access_token: signinToken, user: { id: 'user-1' }, refresh_token: '[stored natively]' };
      else if (op === 'refresh') { signinToken = 'access-token-refreshed-987654321098'; body = { access_token: signinToken, user: { id: 'user-1' }, refresh_token: '[stored natively]' }; }
      else if (op === 'exchange' || op === 'verify') body = { access_token: 'access-token-oauth-123456789012', user: { id: 'oauth-user' }, refresh_token: '[stored natively]' };
      else if (op === 'session') body = { access_token: payload.access_token, user: { id: 'implicit-user' } };
      else body = {};
      return { promise: Promise.resolve({ status: 200, body: JSON.stringify(body) }) };
    },
    httpGet: (url, headers) => {
      calls.push({ type: 'get', url, headers });
      const item = getResults.length ? getResults.shift() : { status: 200, body: '[]' };
      return { promise: Promise.resolve(item) };
    },
    http: req => { calls.push({ type: 'post', req }); return { promise: Promise.resolve({ status: 200, body: '{}' }) }; }
  };
  delete require.cache[require.resolve('../../app/src/main/assets/js/online.js')];
  require('../../app/src/main/assets/js/online.js');
  return { api: global.CBOnline, calls, getResults, events };
}

test('Google button uses only Google and a PKCE challenge with the exact app callback', async () => {
  const { api, calls } = setup();
  const result = await api.signInWithGoogle();
  assert.strictEqual(result.opened, true);
  const opened = calls.find(c => c.type === 'open');
  const url = new URL(opened.url);
  assert.strictEqual(url.searchParams.get('provider'), 'google');
  assert.strictEqual(url.searchParams.get('redirect_to'), 'chessbuddy://auth-callback');
  assert.strictEqual(url.searchParams.get('code_challenge'), 'test-s256-challenge');
  assert.strictEqual(url.searchParams.get('code_challenge_method'), 's256');
});

test('PKCE callback exchanges the authorization code and creates a usable session', async () => {
  const { api, calls } = setup();
  await api.handleAuthCallback('chessbuddy://auth-callback?code=authorization-code-123456&type=signup');
  assert.strictEqual(api.signedIn(), true);
  assert.strictEqual(api.user().id, 'oauth-user');
  const exchange = calls.find(c => c.type === 'auth' && c.op === 'exchange');
  assert.strictEqual(exchange.payload.auth_code, 'authorization-code-123456');
});

test('email confirmation token links and implicit callbacks restore the session', async () => {
  let x = setup();
  await x.api.handleAuthCallback('chessbuddy://auth-callback?token=hashed-email-token-123456&type=signup');
  const verify = x.calls.find(c => c.type === 'auth' && c.op === 'verify');
  assert.strictEqual(verify.payload.token, 'hashed-email-token-123456');
  assert.strictEqual(x.api.signedIn(), true);

  x = setup();
  await x.api.handleAuthCallback('chessbuddy://auth-callback#access_token=implicit-access-token-123456789&refresh_token=implicit-refresh-token-123456789&type=signup');
  const session = x.calls.find(c => c.type === 'auth' && c.op === 'session');
  assert.strictEqual(session.payload.access_token, 'implicit-access-token-123456789');
  assert.strictEqual(x.api.user().id, 'implicit-user');
});

test('callback dispatch preserves recovery state without throwing away the session', async () => {
  const { api, events } = setup();
  global.cbAuthCallback('chessbuddy://auth-callback?code=authorization-code-123456&type=recovery');
  await new Promise(resolve => setImmediate(resolve));
  assert.strictEqual(api.signedIn(), true);
  const event = events.find(item => item.type === 'chessbuddy-auth-callback');
  assert.ok(event);
  assert.strictEqual(event.detail.signedIn, true);
  assert.strictEqual(event.detail.recovery, true);
});

test('email recovery and confirmation resend call distinct safe Auth endpoints', async () => {
  const { api, calls } = setup();
  await api.resetPassword('player@example.com');
  await api.resendConfirmation('player@example.com');
  const recover = calls.find(c => c.type === 'auth' && c.op === 'recover');
  const resend = calls.find(c => c.type === 'auth' && c.op === 'resend');
  assert.strictEqual(recover.payload.email, 'player@example.com');
  assert.deepStrictEqual(resend.payload, { type: 'signup', email: 'player@example.com' });
});

test('presence is blocked until a verified authenticated user session exists', async () => {
  const { api, calls } = setup();
  await assert.rejects(api.setPresence('online'), /session is missing/i);
  assert.strictEqual(calls.some(c => c.type === 'post'), false);
});

test('a 401 refreshes once and retries with the new access token; permission errors are not retried', async () => {
  const { api, calls, getResults } = setup();
  await api.signIn('player@example.com', 'a-password');
  getResults.push({ status: 401, body: '{"message":"JWT expired"}' }, { status: 200, body: '[]' });
  await api.profile();
  const gets = calls.filter(c => c.type === 'get');
  assert.strictEqual(gets.length, 2);
  assert.ok(gets[0].headers.includes('access-token-old-'));
  assert.ok(gets[1].headers.includes('access-token-refreshed-'));
  assert.strictEqual(calls.filter(c => c.type === 'auth' && c.op === 'refresh').length, 1);

  getResults.push({ status: 403, body: '{"message":"permission denied"}' });
  await assert.rejects(api.profile(), /permission denied/i);
  assert.strictEqual(calls.filter(c => c.type === 'auth' && c.op === 'refresh').length, 1);
});

done('online authentication');
