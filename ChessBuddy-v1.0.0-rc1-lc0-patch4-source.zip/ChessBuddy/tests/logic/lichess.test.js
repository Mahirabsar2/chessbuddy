const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const create = require('../../app/src/main/assets/js/lichess.js');
console.log('lichess.js');
test('opening explorer uses the exact FEN, selected source, and caches results', async () => {
  const calls = [];
  const api = { httpGet: url => { calls.push(url); return { promise: Promise.resolve({ status: 200, body: JSON.stringify({ moves: [] }) }) }; } };
  const l = create(api), fen = 'startpos fen';
  await l.explorer(fen, 'masters'); await l.explorer(fen, 'masters');
  assert.strictEqual(calls.length, 1); assert.ok(calls[0].startsWith('https://explorer.lichess.ovh/masters?fen='));
  assert.ok(calls[0].includes(encodeURIComponent(fen)));
});
test('tablebase uses the standard endpoint and reports server errors', async () => {
  let seen = '';
  const api = { httpGet: url => { seen = url; return { promise: Promise.resolve({ status: 404, body: '', message: 'not found' }) }; } };
  const l = create(api);
  await assert.rejects(() => l.tablebase('fen'), /not found/);
  assert.ok(seen.startsWith('https://tablebase.lichess.org/standard?fen='));
});
done('lichess.js');
