const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const { Chess } = require('../helpers/load-chessjs')();
const validation = import('../../supabase/functions/_shared/online-validation.mjs');
console.log('online move validation (shared with Supabase Edge Function)');
const now = Date.now();
function game() {
  const start = new Chess().fen();
  return { id: '00000000-0000-4000-8000-000000000001', white_user_id: 'white-user', black_user_id: 'black-user',
    time_control: '3+2', initial_fen: start, current_fen: start, pgn: '', turn_user_id: 'white-user', turn_color: 'w',
    white_ms: 180000, black_ms: 180000, status: 'active', updated_at: new Date(now).toISOString() };
}
function payload(san) {
  const c = new Chess(); c.move(san);
  return { game_id: game().id, p_next_fen: c.fen(), p_pgn: c.pgn(), p_white_ms: 182000, p_black_ms: 180000 };
}

test('accepts one legal move and derives the next player and increment', async () => {
  const { validateOnlineMove } = await validation;
  const r = validateOnlineMove(Chess, game(), payload('e4'), 'white-user', now);
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.update.turn_color, 'b');
  assert.strictEqual(r.update.turn_user_id, 'black-user');
  assert.strictEqual(r.update.white_ms, 182000);
  assert.strictEqual(r.update.black_ms, 180000);
});

test('rejects wrong player, mismatched PGN and fake FEN', async () => {
  const { validateOnlineMove } = await validation;
  assert.strictEqual(validateOnlineMove(Chess, game(), payload('e4'), 'black-user', now).status, 409);
  const mismatch = payload('d4'); mismatch.p_pgn = '1. e4';
  assert.strictEqual(validateOnlineMove(Chess, game(), mismatch, 'white-user', now).ok, false);
  const fakeFen = payload('e4'); fakeFen.p_next_fen = new Chess().fen();
  assert.strictEqual(validateOnlineMove(Chess, game(), fakeFen, 'white-user', now).ok, false);
});

test('rejects clock inflation, opponent clock changes and expired clocks', async () => {
  const { validateOnlineMove } = await validation;
  const inflated = payload('e4'); inflated.p_white_ms = 300000;
  assert.strictEqual(validateOnlineMove(Chess, game(), inflated, 'white-user', now).ok, false);
  const alteredOpponent = payload('e4'); alteredOpponent.p_black_ms = 190000;
  assert.strictEqual(validateOnlineMove(Chess, game(), alteredOpponent, 'white-user', now).ok, false);
  const expired = game(); expired.updated_at = new Date(now - 181000).toISOString();
  assert.strictEqual(validateOnlineMove(Chess, expired, payload('e4'), 'white-user', now).status, 409);
});

test('rejects stale game state and non-participant users', async () => {
  const { validateOnlineMove } = await validation;
  const stale = game(); stale.current_fen = 'invalid';
  assert.strictEqual(validateOnlineMove(Chess, stale, payload('e4'), 'white-user', now).status, 409);
  assert.strictEqual(validateOnlineMove(Chess, game(), payload('e4'), 'stranger', now).status, 403);
});

done('online move validation');
