package com.chessbuddy;
/** Plain-JVM checks for HostPolicy and Json (run by tests/java/run.sh). */
public class PolicyTest {
    static int fails = 0;
    static void eq(String name, Object got, Object want) { if (!String.valueOf(got).equals(String.valueOf(want))) { fails++; System.out.println("FAIL " + name + ": got " + got + " want " + want); } }
    static boolean ok(String url) { return HostPolicy.check(url) == null; }
    public static void main(String[] a) throws Exception {
        eq("https any host", ok("https://api.anthropic.com/v1/messages"), true);
        eq("http internet blocked", ok("http://api.openai.com/v1"), false);
        eq("http localhost", ok("http://localhost:11434/v1"), true);
        eq("http 192.168", ok("http://192.168.1.20:1234/v1"), true);
        eq("http 10.x", ok("http://10.0.2.2:11434/v1"), true);
        eq("http 172.16", ok("http://172.16.5.4/v1"), true);
        eq("http 172.32 blocked", ok("http://172.32.5.4/v1"), false);
        eq("http public ip blocked", ok("http://8.8.8.8/v1"), false);
        eq("http single label", ok("http://ollama:11434/v1"), true);
        eq("http .local", ok("http://mac.local:11434/v1"), true);
        eq("http ipv6 loopback", ok("http://[::1]:8080/v1"), true);
        eq("lookalike host blocked", ok("http://localhost.evil.com/v1"), false);
        eq("Supabase public REST POST uses the fixed project path", HostPolicy.isSupabasePublicPost("https://npicptuurxuqxepxzumi.supabase.co/rest/v1/rpc/cb_send_challenge", "cb_supabase_public", "https://npicptuurxuqxepxzumi.supabase.co"), true);
        eq("Supabase public key cannot be used on another host", HostPolicy.isSupabasePublicPost("https://attacker.example/rest/v1/rpc/cb_send_challenge", "cb_supabase_public", "https://npicptuurxuqxepxzumi.supabase.co"), false);
        eq("Supabase public key cannot be used for auth paths", HostPolicy.isSupabasePublicPost("https://npicptuurxuqxepxzumi.supabase.co/auth/v1/token", "cb_supabase_public", "https://npicptuurxuqxepxzumi.supabase.co"), false);
        eq("only the move validator function is allowed", HostPolicy.isSupabasePublicPost("https://npicptuurxuqxepxzumi.supabase.co/functions/v1/apply-online-move", "cb_supabase_public", "https://npicptuurxuqxepxzumi.supabase.co"), true);
        eq("other edge functions are not allowed", HostPolicy.isSupabasePublicPost("https://npicptuurxuqxepxzumi.supabase.co/functions/v1/admin", "cb_supabase_public", "https://npicptuurxuqxepxzumi.supabase.co"), false);
        eq("Supabase public key id is required", HostPolicy.isSupabasePublicPost("https://npicptuurxuqxepxzumi.supabase.co/rest/v1/rpc/cb_send_challenge", "other_key", "https://npicptuurxuqxepxzumi.supabase.co"), false);
        eq("creds in url blocked", ok("https://user:pw@api.example.com/v1"), false);
        eq("ftp blocked", ok("ftp://example.com/x"), false);
        eq("garbage blocked", ok("not a url"), false);
        eq("null blocked", ok(null), false);
        java.lang.reflect.Method redact = NativeBridge.class.getDeclaredMethod("redactRefreshToken", String.class);
        redact.setAccessible(true);
        String authJson = "{\"access_token\":\"access-visible-test-token-123456789\",\"refresh_token\":\"refresh-secret-test-token-123456789\",\"user\":{\"id\":\"user-1\"}}";
        String safeAuthJson = (String) redact.invoke(null, authJson);
        eq("validated access token survives the native-to-JS response", safeAuthJson.contains("access-visible-test-token-123456789"), true);
        eq("refresh token is not exposed to JavaScript", safeAuthJson.contains("refresh-secret-test-token-123456789"), false);
        eq("refresh token replacement marker is present", safeAuthJson.contains("[stored securely on device]"), true);
        eq("quote basic", Json.quote("a\"b\\c\n\u2028"), "\"a\\\"b\\\\c\\n\\u2028\"");
        eq("quote control", Json.quote("\u0001"), "\"\\u0001\"");
        System.out.println(fails == 0 ? "OK PolicyTest" : "FAILED PolicyTest: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
