package org.json; public class JSONObject { public JSONObject(String s) throws Exception { if(s==null)throw new Exception(); } public String optString(String name,String fallback){return fallback;} }
