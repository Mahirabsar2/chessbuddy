package android.content;
import android.net.Uri; import android.database.Cursor; import java.io.OutputStream;
public class ContentResolver { public OutputStream openOutputStream(Uri u,String mode){return null;} public Uri insert(Uri u,ContentValues v){return null;} public Cursor query(Uri u,String[] p,String s,String[] a,String o){return null;} }