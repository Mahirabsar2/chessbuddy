# ChessBuddy 1.0.0 — release-candidate source

ChessBuddy is an Android-first chess app with an original interface, local chess play, engine and model opponents, analysis, coach voice output, and private direct-friend challenges. The 1.0.0 source candidate consolidates the earlier 0.5.0 account/diagnostics work with the 5.0 development game features.

> **Release status:** this is a 1.0.0 release-candidate source tree, not a verified production APK. The JavaScript and Java test suites pass locally. The Android/NDK/Rust build, browser UI suite, Deno suite, Supabase provider setup, and two-device online tests still require CI or a real Android device. See `PROJECT_STATUS.md` and `docs/RELEASE_CHECKLIST.md`.

## Startup and accounts

On launch, the app displays an animated ChessBuddy loading screen, then opens account onboarding. Sign in with Google or email/password, create an account, resend verification, or request a password reset. **Continue offline** opens the local chess lobby without an account. The app does not require sign-in for local games.

Google uses the Supabase OAuth PKCE browser flow and the `chessbuddy://auth-callback` Android deep link. Email confirmation and password recovery use the same callback. Access tokens are held in memory for authenticated requests; refresh tokens and PKCE verifiers stay in encrypted Android Keystore storage. The app never invents a token or places a service-role key in the client.

## Chess and training features

- Human vs engine, pass-and-play, and AI vs AI.
- More than 150 original bot profiles across skill bands, adaptive play, Stockfish levels, Maia profiles, legends, creators, athletes, musicians, and character-inspired categories. Portraits and UI are ChessBuddy originals, not copied Chess.com assets.
- Stockfish UCI engine, optional Lc0 + Maia model support, and AI opponents through configured Claude or OpenAI-compatible endpoints.
- Time controls with increment, live clocks passed to engines, and White's clock starting when the game begins (so White's first move is charged).
- Board tap selection and drag/drop, legal move hints, promotion, castling, en passant, undo, board flip, piece/capture presentation, move animations and sound.
- Game archive, import/export and backup/restore, analysis, evaluation, move classifications, review replay, opening explorer and tablebase references.
- 12 original coaches. Optional spoken coach responses and optional bot-move narration use the Android/WebView system speech voices; custom recorded voices are not bundled.
- Optional Rust legality cross-check for human moves. The primary app host is still Java and the UI is still HTML/CSS/JavaScript; Rust is a native helper library, not a rewrite of the whole app.

## Online friend play

- Google or email/password account, username/display-name profile, presence, player list, and direct challenges to a selected player.
- Accept, decline, or cancel challenges; list active games; resign and claim timeout.
- No random matchmaking, rating ladder, global chat, or push notifications. Current presence/challenge/game updates use authenticated HTTP polling.
- Online move sync requires deploying the Edge Function and SQL hardening together. They are included as source but are not yet deployed to the connected Supabase project. See `docs/ONLINE_PLAY_STATUS.md`.

## Diagnostics and privacy

The app writes operational logs to `Documents/ChessBuddy/Logs/` when Android public Documents storage is available. Older or restricted devices fall back to app-private storage. Logs cover lifecycle, screen/tab navigation, static control interactions, input changes (values omitted), board activity (coordinates/moves omitted), authentication outcomes, network metadata, engine lifecycle, and runtime errors. They intentionally exclude passwords, email/phone details, authorization codes, access/refresh tokens, API keys, raw response bodies, source code, private game moves/PGNs, and chat content. This is diagnostic telemetry, not a recording of every private action.

## Build

See `BUILD_ON_GITHUB.md`. The CI workflow runs JS and Java tests, browser UI tests, Deno validation tests, Rust tests, cross-compiles Stockfish/Lc0/Rust for Android ARM64, creates an APK, and verifies its contents and signature. It has not yet been run for this candidate.

## Important configuration

- Google OAuth must be enabled and configured in the Supabase dashboard with a Google **Web application** OAuth client ID and secret. Google Cloud must allow the Supabase callback URI. The app redirect `chessbuddy://auth-callback` is already configured in the Supabase redirect allowlist by the project owner.
- Supabase's built-in test email sender is restricted to pre-authorized team addresses. To send confirmations and password reset emails to regular users, configure custom SMTP and verify the sender domain. See `docs/AUTH_GOOGLE_EMAIL_SETUP.md`.
- Online move validation is not production-active until its SQL operation and Edge Function are deployed and tested together.
- A stable private signing key is required for future in-place APK updates. Never commit the keystore or its passwords.

## Repository map

- `app/src/main/assets/` — HTML/CSS/JavaScript UI and game logic.
- `app/src/main/java/com/chessbuddy/` — Android host, secure auth bridge, engine process, HTTP transport, diagnostics, and Rust JNI loader.
- `rust/chessbuddy-core/` — native move-legality cross-check.
- `supabase/` — schema migrations, Edge Function validation, and deployment SQL operation.
- `tests/` — JS logic, Java policy/compile tests, and Playwright UI tests.
- `scripts/` — Android native builds and APK verification.
