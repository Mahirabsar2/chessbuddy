# ChessBuddy 1.0.0 codebase map

## Main modules

- `app/src/main/assets/index.html`, `css/app.css`: startup splash, onboarding, application screens and animations.
- `app/src/main/assets/js/app.js`: application controller, game lifecycle, first-launch onboarding, online account UI, settings, persistence and diagnostics events.
- `js/chess.js`: chess rules and move generation.
- `js/engine.js` → `js/native.js` → `NativeBridge.java` → `EngineProcess.java`: UCI transport and native Stockfish/Lc0 process bridge.
- `js/strength.js`, `js/avatars.js`, `js/clock.js`, `js/review.js`, `js/coaches.js`, `js/coach.js`, `js/prompts.js`: bot roster, original avatars, clock, game review, coaches and AI prompts.
- `js/online.js`: Supabase Auth, Google PKCE, session handling, profiles, presence, direct challenges and game polling/validation calls.
- `java/com/chessbuddy`: Android lifecycle, deep links, secure auth bridge, HTTP transport, diagnostics and JNI loader.
- `rust/chessbuddy-core`: optional native move-legality cross-check.
- `supabase/`: schema migrations, online-move Edge Function and companion SQL deployment operation.
- `tests/`: JavaScript logic, Java security-policy/compile, Playwright UI and Deno validator tests.
- `scripts/`: Stockfish, Lc0, Rust Android builds and APK verification.

## Security boundaries

- `NativeBridge.java` and `SecretStore.java` own authentication transport and encrypted refresh-token/PKCE storage.
- The Android client contains only the Supabase publishable key. Never add the service-role key, Google client secret, SMTP password, or private signing key.
- `DiagnosticsLog.java` redacts credentials and excludes raw network bodies, source code and private game/chat content.
- The public redirect `chessbuddy://auth-callback` is captured only for the exact scheme/host and handed to the JS auth callback after the bundled page is ready.
- The online-move validator and SQL hardening are in source but not yet deployed. Do not treat current online games as anti-cheat verified.

## Test and release status

- `node tests/run-all.js`: local JS logic suites.
- `bash tests/java/run.sh`: compiles Java sources against minimal Android stubs and runs policy checks; this is not the Android SDK build.
- `node tests/ui/ui.test.js`: Playwright/Chromium UI tests, run in CI.
- `deno test supabase/functions/_shared/online-validation.test.ts`: Edge Function validation tests.
- `cargo test --manifest-path rust/chessbuddy-core/Cargo.toml`: native Rust tests.
- `.github/workflows/android-build.yml`: full arm64 CI build and APK verification.

See `PROJECT_STATUS.md`, `docs/FEATURE_MATRIX_1.0.0.md` and `docs/RELEASE_CHECKLIST.md` for exact limits and release gates.
