# ChessBuddy 1.0.0 — engineering status

Updated: 2026-11-17  
Source baseline: saved `ChessBuddy-v5.0.0-dev-source.zip` plus selected 0.5.0 auth/diagnostics work  
Candidate version: `1.0.0` (release candidate; not a verified release)

## Implemented in this candidate

### App and chess
- Preserves the 5.0 game UI, board input, chess.js rules, Stockfish integration, 150+ original bot profiles, clocks, review/archive, AI-vs-AI, pass-and-play, coach tooling, and Lichess references.
- Adds the animated cold-start splash followed by account onboarding; Continue offline routes directly to the local lobby.
- Adds optional bot move narration and coach speech using system speech voices.
- Adds a Rust `cdylib` legality cross-check loaded through JNI. It supplements chess.js and is not a replacement for the UI, host, or chess engine.

### Authentication
- Adds exact Android deep-link capture for `chessbuddy://auth-callback` in `MainActivity` and `AndroidManifest.xml`.
- Adds Google OAuth using Supabase's browser PKCE flow, native encrypted verifier storage, code exchange, and callback validation.
- Adds email/password signup and login, verification resend, password reset, and password update.
- Fixes the session-token handoff: native session validation previously returned the validated user but discarded the access token; it now returns the verified access token to the UI while keeping the refresh token encrypted natively.
- Handles PKCE `code`, email `token`/`token_hash`, and implicit access/refresh callback formats.
- Retries an authenticated online request once after HTTP 401 if a native refresh succeeds. HTTP 403/permission errors are not retried.
- The social provider UI is Google only. Email/password remains available.

### Diagnostics and privacy
- Creates `Documents/ChessBuddy/README.txt` and daily JSONL logs under `Documents/ChessBuddy/Logs/` where supported, with an app-private fallback.
- Captures lifecycle, screen/tab navigation, static control interactions, board activity without coordinates, auth outcomes, HTTP/edge request metadata, engine/model move events without move text, and runtime errors.
- Redaction excludes passwords, email/phone details, OTPs, authorization codes, tokens, API keys, raw request/response bodies, source code, PGN/moves, and private chat content.

## Test results from the current working tree

- `node tests/run-all.js`: PASS — 11 logic suites / 97 assertions (must rerun after final documentation/test edits).
- `bash tests/java/run.sh`: PASS — all Java app sources compile against the repository's minimal Android stubs; `PolicyTest` passes. This is not an Android SDK build.
- HTML ID audit: 173 unique IDs, no duplicates before the latest small guest button addition; rerun.
- Shell syntax checks: pending final rerun.
- Playwright/Chromium UI tests: not run locally; Playwright is not installed.
- Deno Edge Function tests: not run locally; Deno is not installed.
- Rust tests/cross-compile: not run locally; Cargo/Rust are not installed.
- Android Gradle/NDK/APK build and signing: not run locally; Android SDK/NDK/Gradle are not installed.
- Physical-device testing and two-account/two-device online testing: not done.

## External configuration and deployment blockers

1. Google OAuth client ID/secret and provider enablement must be configured in Supabase and Google Cloud. The app redirect allowlist already contains `chessbuddy://auth-callback` per the project owner.
2. Custom SMTP must be configured for verification/reset email delivery to arbitrary user addresses. Code cannot supply an email transport account or deliver mail by itself.
3. `supabase/functions/apply-online-move` and `supabase/operations/validated_online_moves.sql` are included as source but are not deployed to the live project. Do not describe online moves as server-validated/anti-cheat until both are deployed and tested together.
4. A stable owner-controlled signing key must be configured in GitHub Actions secrets to make subsequent APKs update-installable. An ephemeral CI key is suitable only for a one-off test build.
5. Maia/Lc0 model loading, Rust JNI loading, the app's native libraries, and actual Google/email sign-in must be checked on physical arm64 Android hardware.

## Not claimed

- No claim of zero bugs or full Chess.com feature parity.
- No claim that the full Chess.com internal technology stack is public or reproduced.
- No global rated matchmaking, official Chess.com ratings/bots/assets, global clubs/tournaments, lesson library, puzzle ecosystem, broadcast/news system, or integrated player chat.
- No production-grade anti-cheat or certified multiplayer integrity until pending server deployment and device tests pass.

## Release gate

This tree can be submitted to the repository's Actions workflow as a 1.0.0 release candidate. It must not be labeled a verified production release until CI succeeds, APK verification succeeds, sign-in and email delivery are tested with configured providers, and the two-device online checks pass.
