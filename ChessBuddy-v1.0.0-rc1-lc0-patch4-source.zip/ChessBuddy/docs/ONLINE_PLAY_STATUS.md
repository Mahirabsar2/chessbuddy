# ChessBuddy 1.0.0 — online friend-play status

## Client implementation

- Supabase email/password account creation and login.
- Google browser OAuth with PKCE and `chessbuddy://auth-callback` deep-link return.
- Refresh tokens and PKCE verifier stored through Android `SecretStore` (AES-GCM backed by Android Keystore; no plaintext fallback for new values).
- Username/display-name profile setup.
- Online/away heartbeat and player roster from recent presence.
- Direct selected-player challenges with time control and colour; accept, decline, cancel, and rematch.
- Active-game list, move polling, clocks, resignation and timeout handling.
- No random matchmaking, push notification service, or direct-message system.

## Session and transport safeguards

- Supabase access tokens are checked by `/auth/v1/user` before a callback session is accepted.
- The Android bridge returns the validated access token to the JS session layer but keeps the refresh token encrypted natively.
- REST and Edge Function requests require an authenticated access token.
- Only HTTP 401 triggers one refresh-and-retry; HTTP 403 permission failures remain visible and are not retried.
- Do not grant `cb_set_presence` to `anon`, and do not disable RLS to bypass permission failures.

## Online move validation: pending deployment

The app submits moves to `apply-online-move`. The shared validator replays the PGN, verifies that exactly one legal move was added, checks FEN/turn/player ownership, rejects clock inflation and opponent-clock changes, and derives end conditions.

`supabase/operations/validated_online_moves.sql` is the companion database hardening operation. It creates a service-role-only transactional update path, locks the game row, enforces elapsed time using the database clock, guards stale writes, and removes client access to the old client-trusting `cb_apply_move` function.

**Both are source only and have not been deployed to the live Supabase project.** Online moves are not yet production-ready or anti-cheat-certified. Deploy/review the SQL and Edge Function together, then perform two-account/two-device tests before enabling public multiplayer use.

## Existing live schema noted by earlier inspection

Tables: `chessbuddy_profiles`, `chessbuddy_presence`, `chessbuddy_challenges`, `chessbuddy_games`.

RPCs: `cb_register_profile`, `cb_set_presence`, `cb_send_challenge`, `cb_respond_challenge`, `cb_cancel_challenge`, `cb_apply_move`, `cb_claim_timeout`, `cb_resign_game`.

The exact live schema/privileges should be re-inspected before deployment; this document is not a fresh live database query. Never put a service-role key in the app. The Android client uses only the project's public publishable key and each signed-in player's access token.
