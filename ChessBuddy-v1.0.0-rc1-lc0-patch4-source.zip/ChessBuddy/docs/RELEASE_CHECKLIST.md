# ChessBuddy 1.0.0 release checklist

## Candidate source checks

- [ ] `node tests/run-all.js`
- [ ] `bash tests/java/run.sh`
- [ ] `node tests/ui/ui.test.js` with Chromium installed
- [ ] `deno test supabase/functions/_shared/online-validation.test.ts`
- [ ] `cargo test --manifest-path rust/chessbuddy-core/Cargo.toml`
- [ ] Android Gradle release build with the configured SDK/NDK
- [ ] APK verification with `scripts/verify_apk.sh`
- [ ] Verify APK signature and save the matching source archive and SHA-256 sums

## Provider setup and device tests

- [ ] Google OAuth provider configured in Supabase and Google Cloud
- [ ] Custom SMTP configured; verify signup, resend, and password recovery emails
- [ ] Email sign-in returns access token and native encrypted refresh token
- [ ] Google PKCE callback returns to the app and restores the session after relaunch
- [ ] Rust library loads on an arm64 Android device and agrees with chess.js for legal/illegal moves
- [ ] Stockfish starts and plays; verify clocks and low-time handling
- [ ] Lc0 loads a downloaded Maia model; test model checksum and memory use
- [ ] Test direct friend challenges with two separate accounts and two physical devices
- [ ] Deploy the online-move SQL operation and Edge Function together only after reviewing them; then test stale updates, clock integrity, move replay and game result handling
- [ ] Check `Documents/ChessBuddy/Logs/` is created, logs events, rotates at the limit, and contains no sensitive values or private game content

## Signing and versioning

- [ ] Use an owner-controlled persistent release keystore stored only in GitHub Actions secrets
- [ ] Do not use a fresh ephemeral key for a release that must update-install over an existing app
- [ ] Preserve the keystore safely; losing it prevents future in-place updates under Android's signing model
- [ ] Verify package ID `com.chessbuddy`, `versionName 1.0.0`, ARM64 libraries, permissions, and APK signature

**Do not mark the app as production-ready until every applicable item is checked.**
