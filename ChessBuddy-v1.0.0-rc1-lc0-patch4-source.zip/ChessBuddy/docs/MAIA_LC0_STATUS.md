# Maia / Leela Chess Zero integration

## Android build contract

- Supported Android ABI: **arm64-v8a only** (Android API 24+ for the Lc0 executable; the app itself has a lower minSdk for non-Lc0 features).
- `scripts/build_lc0_android.sh` cross-compiles the pinned Lc0 source commit and its pinned submodules with the Android NDK, plus a static ARMv8 OpenBLAS backend. It uses a pinned Meson/Ninja tool environment and writes the executable to `app/src/main/jniLibs/arm64-v8a/liblc0.so`.
- `liblc0.so` is an Android PIE command-line executable, not a JNI library. Android Gradle packaging extracts it to `ApplicationInfo.nativeLibraryDir`; `EngineProcess` starts it with `ProcessBuilder` and exchanges UCI over stdin/stdout.
- The build script audits ELF architecture, Android interpreter and dynamic dependencies. It includes `libc++_shared.so` only if the executable actually needs it; BLAS itself is static.
- The Maia model manifest is generated during CI from the real downloaded files; the source ZIP intentionally does not contain empty checksum placeholders. The Maia weights are not embedded in the APK. CI downloads the official Maia-1 1100/1500/1900 release files, checks gzip integrity, and creates a manifest with exact byte sizes and SHA-256 hashes. `NativeBridge` downloads the selected official file to app-private storage and verifies both values before making it available to Lc0.

## Runtime path

1. `strength.js` identifies Maia opponents as the `lc0` provider and associates each with `maia-1100`, `maia-1500`, or `maia-1900`.
2. `app.js` ensures the chosen model is downloaded and verified, starts the native Lc0 executable through `NativeBridge.engineStart`, then selects the network through UCI `WeightsFile`.
3. `NativeBridge` supplies `--backend=blas`, `--threads=1`, and `--search-algorithm=policyhead`. The Maia policy-head search is distinct from Stockfish; post-game analysis continues to use Stockfish.
4. `EngineProcess` handles the same UCI stdin/stdout contract for Stockfish and Lc0. Stockfish's own binary and build remain separate and unchanged.

## CI verification

The outer Patch 4 workflow must call both `scripts/build_stockfish_android.sh` and `scripts/build_lc0_android.sh` before Gradle assembles the APK. It must also build the Rust JNI library because the APK verifier checks it. See `PATCH4_BRANCH_WORKFLOW.yml` in the source ZIP for the matching workflow used by the Patch 4 branch.

`scripts/verify_apk.sh` checks the actual APK entries, ELF class/architecture, PIE type, Android arm64 linker, Lc0 dependency closure, optional C++ runtime, all three Maia manifest records and hashes, licence assets, and the app's Lc0/WeightsFile/policyhead wiring. It does not waive the missing-engine check.

## Device validation still required

A successful cross-compile and APK verification do not replace a physical-device runtime test. Install the APK on a 64-bit ARM Android device, choose Maia 1100, accept the one-time model download, start a game, and confirm Lc0 returns a legal UCI move. Repeat with Maia 1500 and 1900 to test switching `WeightsFile`. Also test Stockfish separately to confirm the existing engine remains intact. Install the APK on an authorized arm64 device, choose Maia 1100, accept the model download, start a game, and confirm that Lc0 returns a legal move. Repeat with Maia 1500 and Maia 1900 to exercise `WeightsFile` switching. Until those device tests pass, do not describe Maia as verified on every device.

## Pinned source and licensing

- Lc0: `fd71a2d921b689c5f479d3227c3806c8e272d9c5` (GPL-3.0).
- OpenBLAS: `v0.3.29` (upstream licence notice included).
- Maia-1: `CSSLab/maia-chess` release `v1.0`; the model download URLs and per-file hashes are recorded in `app/src/main/assets/models/maia-models.json` after the CI build.
- Exact Lc0 and OpenBLAS source snapshots used by CI are placed under `third_party/sources/`.
