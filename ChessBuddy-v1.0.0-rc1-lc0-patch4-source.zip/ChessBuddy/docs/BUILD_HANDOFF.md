# ChessBuddy 1.0.0 release-candidate build handoff

## Source contents

This source tree consolidates the saved ChessBuddy 5.0 development baseline with the selected 0.5.0 auth, session, diagnostics and onboarding work. It preserves the earlier bot/clock/review/AI-vs-AI/online-client features and adds the Rust JNI legality helper, Google PKCE auth path, email recovery/resend actions, first-launch account onboarding, and diagnostics.

## Candidate workflow

`.github/workflows/android-build.yml` is configured for pushes to `chessbuddy-5.0-final-dev`, `chessbuddy-1.0.0-rc`, or `main`, plus manual dispatch. It runs JS, Java, Playwright UI, Deno and Rust tests, cross-builds Stockfish/Lc0/Rust for Android ARM64, signs and builds the release APK, verifies the APK and packages a matching source snapshot with checksums.

## Local verification available in this environment

- JavaScript syntax checks and `node tests/run-all.js` pass.
- Java sources compile against the minimal repository Android stubs and `PolicyTest` passes.
- Browser UI tests require Playwright/Chromium and have not run locally.
- Rust tests and Android cross compilation require Rust/Cargo and NDK.
- Deno validator tests require Deno.
- APK packaging requires Android SDK/build-tools/Gradle.

No APK is included in the source ZIP. No local build has been claimed.

## Required integration before calling this a release

1. Configure the Google provider in Supabase using a Google Web OAuth client.
2. Configure custom SMTP so confirmation/reset emails can reach regular users. The Supabase built-in test sender only sends to pre-authorized team addresses.
3. Inspect and deploy the online move validator Edge Function and SQL hardening operation together, then test two-device play.
4. Add a persistent owner-controlled signing keystore to GitHub Actions secrets. Never commit the keystore or credentials.
5. Run the workflow, download its APK artifact, then physically test startup, sign-in, password recovery, session restoration, Rust JNI loading, Stockfish, Lc0/Maia, and online play.

The Supabase app redirect `chessbuddy://auth-callback` has already been added by the project owner; it does not need to be duplicated.
