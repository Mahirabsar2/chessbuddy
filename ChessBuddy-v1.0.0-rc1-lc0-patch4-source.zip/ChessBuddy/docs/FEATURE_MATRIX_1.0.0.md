# ChessBuddy 1.0.0 feature matrix

This is a comparison of user-facing capability areas, not a promise of one-to-one parity with Chess.com.

| Area | ChessBuddy 1.0.0 candidate | Status / limit |
|---|---|---|
| Android app and startup | Animated splash, account onboarding, offline continuation | Implemented in source; UI test still needs CI |
| Account creation | Email/password, confirmation callback, resend, reset | Implemented; delivery needs custom SMTP |
| Social login | Google OAuth PKCE only | Implemented in source; needs Supabase/Google credentials and device test |
| Local chess | Human vs engine, pass-and-play, AI vs AI | Implemented in source |
| Bots | Large original roster, Stockfish levels, adaptive profiles, Maia options | Implemented in source; Maia/Lc0 native build/device validation pending |
| Bot avatars | Original ChessBuddy artwork and SVG avatars | Implemented; not official Chess.com artwork |
| Bot voices | Optional speech of bot moves through system TTS | Implemented as system voices, not custom recorded voices |
| Coaches | 12 original coaches, optional spoken responses | Implemented with system TTS |
| Clock behavior | Time controls, increments, both engine clocks, White clock starts at game start | Implemented and covered by logic tests |
| Board interaction | Tap/drag, legal hints, promotion, undo, flip, animations and sounds | Implemented in source |
| Analysis and review | Engine analysis, evaluation, move categories, replay, archive | Implemented in source |
| Opening/endgame references | Lichess opening explorer and tablebase reference | Implemented in source; remote service rate limits apply |
| User AI providers | Claude and OpenAI-compatible endpoints configured by the user | Implemented; live model calls depend on user's provider/key |
| Friend online play | Profiles, presence, list, direct invite, accept/decline/cancel, active game list | Client implemented; backend deployment/device tests pending |
| Random matchmaking | Not provided | Intentionally not included; user requested direct player selection |
| Global ratings/leaderboards | Not provided | Requires rating backend, abuse controls and a larger online service |
| Puzzles / Puzzle Rush | Not provided | Not implemented in this release candidate |
| Courses / lessons | Not provided | Not implemented in this release candidate |
| Clubs / tournaments / broadcasts | Not provided | Not implemented in this release candidate |
| Player chat / push notifications | Not provided | Not implemented in this release candidate |
| Rust | Native JNI legality cross-check | Implemented in source; actual ARM64 library build still pending |
| Diagnostics | Local JSONL operational logs with sensitive-data exclusions | Implemented in source; verify public Documents write on device |

## Release interpretation

The 1.0.0 version name in Gradle identifies the candidate package version. It does not mean every feature area in Chess.com is present or that the APK is already verified. The final release gate is in `docs/RELEASE_CHECKLIST.md`.
