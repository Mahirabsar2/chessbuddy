# ChessBuddy technology stack

Chess.com is a large, continuously evolving commercial platform. Its complete internal language/framework inventory is not publicly documented in a way that supports a reliable exhaustive list. ChessBuddy therefore uses a maintainable stack suited to this Android app rather than claiming to reproduce Chess.com's private stack.

| Layer | ChessBuddy implementation | Responsibility |
|---|---|---|
| Android application host | Java | Activity lifecycle, WebView, native bridge, secure storage, engine process |
| UI | HTML, CSS, JavaScript | Screens, animations, board interaction, settings, account flow |
| Chess rules | JavaScript (`chess.js`) | Position model, legal moves, PGN/FEN, game state |
| Native rules cross-check | Rust (`cozy-chess`, JNI) | Independent legality check for selected human moves |
| Chess engine | C++ (Stockfish) | Main UCI engine and analysis |
| Optional neural engine | C++ (Lc0) + Maia model weights | Human-like Maia move selection |
| AI coaching/opponents | JavaScript HTTP client to user-configured model endpoints | Explanations, coaching, optional model-vs-model play |
| Backend | Supabase Auth, PostgreSQL, SQL RPCs, Edge Functions (TypeScript/JavaScript on Deno) | Identity, profiles, presence, challenges, online game state |
| Diagnostics | Java + JSON Lines | Local operational event logs with credential/content redaction |
| Build | Gradle, Android SDK/NDK, Rust/Cargo, Node, Deno, GitHub Actions | Tests, native builds, APK packaging and verification |

## Why Rust is not the entire app

The request to use Rust is implemented as an Android native helper library for move legality. Rewriting the complete Android host, WebView interface, native chess engine process, and Supabase integration in Rust would add risk and duplicate already-tested code. The UI and Android activity remain in the languages that fit those layers; Rust is used where it adds value.

## Third-party provenance

The build workflow compiles Stockfish and Lc0 from their respective upstream sources and packages model/licence notices. Maia weights are downloaded on device with user confirmation and size/hash verification. Review `third_party/README.md`, `docs/MAIA_LC0_STATUS.md`, and `app/src/main/assets/licenses/` before redistribution.
