# Build ChessBuddy 1.0.0 on GitHub Actions

This is the Android source project. The CI build generates the Stockfish, Lc0 and Rust arm64 native outputs before packaging the APK. No fake or prebuilt placeholder engine binaries are included.

## Patch 4 branch instructions

The Patch 4 branch stores this project in `ChessBuddy-v1.0.0-rc1-source.zip`. Its outer workflow must extract that ZIP and explicitly run all three native build scripts. Use `PATCH4_BRANCH_WORKFLOW.yml` from this source ZIP as the replacement for the repository-root `.github/workflows/android-build.yml`. This is important: a workflow stored inside the ZIP is nested source and does not run automatically as the repository workflow.

1. Replace `ChessBuddy-v1.0.0-rc1-source.zip` on branch `Mahirabsar2-patch-4` with this corrected ZIP.
2. Replace the repository-root `.github/workflows/android-build.yml` with `PATCH4_BRANCH_WORKFLOW.yml`.
3. Commit both changes. The workflow then extracts the ZIP, builds Stockfish, cross-compiles Lc0 plus its static OpenBLAS backend, builds the Rust JNI core, assembles the APK, and verifies all required files.
4. Download the `ChessBuddy-build-*` artifact. It contains the arm64 APK, the matching source archive, verification report and engine provenance.

## Maia / Lc0

`scripts/build_lc0_android.sh` pins the Lc0 and OpenBLAS sources, uses the Android NDK cross-toolchain, builds the OpenBLAS CPU backend, generates a SHA-256/size manifest from the official Maia-1 1100/1500/1900 files, and writes `liblc0.so` into `app/src/main/jniLibs/arm64-v8a/`. The manifest is generated at build time; no empty hashes are shipped. The APK verifier checks the actual ARM64 PIE executable, Android linker, dependency closure, Maia manifest, licence files and app runtime wiring.

After installing the APK on an arm64 phone, select Maia 1100, accept the verified model download, start a game and confirm the engine returns a move. Repeat with Maia 1500 and 1900 to verify network switching. This physical-device test is separate from the GitHub APK packaging check.

Stockfish remains a separate engine and is still built by `scripts/build_stockfish_android.sh`.
