use cozy_chess::{util::parse_uci_move, Board};
use jni::{objects::{JClass, JString}, sys::jboolean, JNIEnv};
use std::{panic::{catch_unwind, AssertUnwindSafe}, str::FromStr};

/// Returns true only when `uci` is legal in the supplied six-field FEN.
/// This is a second rules check alongside chess.js, not an AI engine.
pub fn is_legal_uci(fen: &str, uci: &str) -> bool {
    if fen.len() > 256 || uci.len() < 4 || uci.len() > 5 {
        return false;
    }
    let board = match Board::from_str(fen) {
        Ok(board) => board,
        Err(_) => return false,
    };
    let mv = match parse_uci_move(&board, uci) {
        Ok(mv) => mv,
        Err(_) => return false,
    };
    board.is_legal(mv)
}

#[no_mangle]
pub extern "system" fn Java_com_chessbuddy_RustChess_nativeIsLegalMove(
    mut env: JNIEnv<'_>,
    _class: JClass<'_>,
    fen: JString<'_>,
    uci: JString<'_>,
) -> jboolean {
    let result = catch_unwind(AssertUnwindSafe(|| {
        let fen: String = match env.get_string(&fen) {
            Ok(value) => value.into(),
            Err(_) => return false,
        };
        let uci: String = match env.get_string(&uci) {
            Ok(value) => value.into(),
            Err(_) => return false,
        };
        is_legal_uci(&fen, &uci)
    })).unwrap_or(false);
    if result { 1 } else { 0 }
}

#[cfg(test)]
mod tests {
    use super::is_legal_uci;

    const START: &str = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

    #[test]
    fn accepts_legal_opening_moves() {
        assert!(is_legal_uci(START, "e2e4"));
        assert!(is_legal_uci(START, "g1f3"));
    }

    #[test]
    fn rejects_illegal_moves_and_bad_fen() {
        assert!(!is_legal_uci(START, "e2e5"));
        assert!(!is_legal_uci("not a fen", "e2e4"));
        assert!(!is_legal_uci(START, "e2e4;rm -rf"));
    }

    #[test]
    fn supports_standard_uci_castling_notation() {
        let position = "r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1";
        assert!(is_legal_uci(position, "e1g1"));
        assert!(is_legal_uci(position, "e1c1"));
    }

    #[test]
    fn validates_promotion() {
        let position = "7k/P7/8/8/8/8/8/7K w - - 0 1";
        assert!(is_legal_uci(position, "a7a8q"));
        assert!(!is_legal_uci(position, "a7a8x"));
    }
}
