# ChessBuddy account sign-in and diagnostics

## Account methods

The online account screen offers phone OTP, Apple, Google, email/password, and Facebook under More options. The phone path uses Supabase SMS OTP. Social providers use an external browser and an OAuth authorization-code + PKCE callback to `chessbuddy://auth-callback`.

Provider sign-in only works after the matching provider is enabled and configured in Supabase Authentication. Phone sign-in additionally requires an SMS provider and phone auth enabled. The redirect URL `chessbuddy://auth-callback` must remain in the Supabase Redirect URLs allow-list.

Email sign-up sends the confirmation link to the same app callback. Refresh tokens and one-time OAuth PKCE verifiers are stored only in encrypted Android Keystore-backed storage. The PKCE verifier is used once to exchange the authorization code and is then cleared. If secure storage cannot save the session, the app shows an error rather than pretending the session was saved.

## Diagnostics folder

On Android 10 and newer, the app creates a folder visible from the device Files app under Documents/ChessBuddy:

- `Documents/ChessBuddy/README.txt`
- `Documents/ChessBuddy/Logs/app_YYYYMMDD.jsonl`

The daily JSONL files contain app lifecycle events, safe UI action IDs, auth outcomes, network endpoint/status/timing metadata, engine lifecycle events, and JavaScript/native error types. Large daily logs are split into a second part.

Logs deliberately exclude email addresses, passwords, access/refresh tokens, API keys, authorization headers, raw HTTP request/response bodies, source files, private game moves/PGNs, and chat content. The app does not copy its source code into the diagnostics folder. If shared Documents access is unavailable, diagnostics fall back to the app's private `files/ChessBuddy/Logs` directory and the Settings screen reports that location.

## Validation

Run `node tests/run-all.js` for the JavaScript logic/UI suite and `bash tests/java/run.sh` for the Java helper tests. The GitHub Actions workflow builds the arm64 APK with Android SDK/NDK; a source ZIP alone is not an APK.
