# ChessBuddy 0.5.0 account and diagnostics update

This temporary source patch adds the Android `chessbuddy://auth-callback` deep link, email confirmation, phone OTP, Apple/Google/Facebook browser sign-in with PKCE, secure native refresh-token persistence, and a Chess.com-style account entry screen. A missing saved session on a fresh install is treated as a normal signed-out state.

## Supabase dashboard requirement

In **Authentication → URL Configuration → Redirect URLs**, add this exact redirect URL:

`chessbuddy://auth-callback`

The app uses this redirect when creating an account. Without the allow-list entry, Supabase may reject the redirect or send the confirmation flow somewhere else.

## Account options

The three quick options are Phone, Apple, and Google. Email/password remains available below; Facebook is under More sign-in options. Phone requires an SMS provider, and each social provider must be enabled and configured in Supabase Authentication.

## Diagnostics

The app creates `Documents/ChessBuddy/README.txt` and `Documents/ChessBuddy/Logs/` on Android 10+. Logs record operational events and sanitized errors, not source code, credentials, phone/email details, private game moves, or chat content.

## Security

- The app still uses only the Supabase publishable key.
- Refresh tokens remain in Android encrypted storage.
- Callback access tokens are validated against `/auth/v1/user` before the refresh token is saved.
- `cb_set_presence` grants and RLS policies are unchanged. No `anon` permissions were added.
- Expired-session retry is limited to HTTP 401. Permission/configuration errors such as 403 are surfaced instead of retried.

## Validation

Run `node tests/run-all.js` and `bash tests/java/run.sh` from this directory.
