/* Privacy-safe application diagnostics. Never records form values, credentials, raw requests, or game content. */
(function (root) {
  'use strict';
  function log(event, detail) {
    try {
      if (root.CBNative && root.CBNative.available && root.CBNative.logEvent) {
        root.CBNative.logEvent(event, detail || '');
      }
    } catch (_) { /* logging must never break gameplay */ }
  }
  root.CBDiagnostics = { log: log };
  if (!root.document) return;
  root.document.addEventListener('click', function (event) {
    var button = event.target && event.target.closest ? event.target.closest('button') : null;
    if (!button || button.disabled) return;
    var id = button.id || button.getAttribute('data-tab') || button.getAttribute('data-v') || 'button';
    log('ui.button_tap', String(id).slice(0, 80));
  }, true);
  root.addEventListener('error', function (event) {
    var error = event && event.error;
    log('js.error', error && error.name ? String(error.name) : 'window error');
  });
  root.addEventListener('unhandledrejection', function (event) {
    var reason = event && event.reason;
    log('js.unhandled_rejection', reason && reason.name ? String(reason.name) : 'promise rejection');
  });
  root.addEventListener('online', function () { log('network.online', 'Network connection restored'); });
  root.addEventListener('offline', function () { log('network.offline', 'Network connection lost'); });
  root.document.addEventListener('visibilitychange', function () {
    log('app.visibility', root.document.hidden ? 'background' : 'foreground');
  });
  log('app.webview_ready', 'Bundled UI initialized');
})(window);
