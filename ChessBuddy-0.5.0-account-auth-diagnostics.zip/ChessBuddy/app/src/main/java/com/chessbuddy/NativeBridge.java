package com.chessbuddy;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;
import java.security.MessageDigest;
import java.security.SecureRandom;
import android.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The only door between the web UI and the device: Stockfish process, HTTP with the stored API key, clipboard, share, toast. */
final class NativeBridge {
    private static final int MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
    // Public client key only. Privileged Supabase keys must never ship in this APK.
    private static final String SUPABASE_URL = "https://npicptuurxuqxepxzumi.supabase.co";
    private static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ZRVaTdi8h8IPoL8srCD6Ww_uCf7smm4";
    private static final String SUPABASE_REFRESH_ID = "supabase_refresh";
    private static final String SUPABASE_PKCE_VERIFIER_ID = "supabase_pkce_verifier";
    private final Activity activity;
    private final WebView web;
    private final SecretStore secrets;
    private final DiagnosticsLog diagnostics;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Map<String, HttpTransport.CancelToken> inflight = new ConcurrentHashMap<String, HttpTransport.CancelToken>();
    private final ArrayList<String> pending = new ArrayList<String>();
    private boolean flushScheduled;
    private EngineProcess engine;
    private volatile boolean destroyed;

    NativeBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
        this.secrets = new SecretStore(activity);
        this.diagnostics = new DiagnosticsLog(activity);
        this.diagnostics.log("INFO", "app.bridge_ready", "Native bridge initialized");
        this.diagnostics.log("INFO", "storage.secure", "Android Keystore available=" + this.secrets.secureStorage());
    }

    private String enginePath() { return activity.getApplicationInfo().nativeLibraryDir + "/libstockfish.so"; }

    private void js(final String code) {
        if (destroyed) return;
        main.post(new Runnable() { @Override public void run() { if (!destroyed) web.evaluateJavascript(code, null); } });
    }

    /* ---------------- Stockfish ---------------- */

    @JavascriptInterface
    public String engineStart() {
        synchronized (this) {
            if (engine == null) {
                engine = new EngineProcess(enginePath(), activity.getFilesDir(), new EngineProcess.Listener() {
                    @Override public void onLine(String line) { queueLine(line); }
                    @Override public void onExit(int code, String message) {
                        diagnostics.log(code == 0 ? "INFO" : "WARN", "engine.exit", "exitCode=" + code);
                        flushNow();
                        js("window.__cbNative&&window.__cbNative.engineExit(" + code + "," + Json.quote(message) + ")");
                    }
                });
            }
            String err = engine.start();
            diagnostics.log(err == null ? "INFO" : "ERROR", "engine.start", err == null ? "Stockfish process started" : "Engine start failed: " + err);
            String abi = Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "unknown";
            return err == null
                ? "{\"ok\":true,\"path\":" + Json.quote(enginePath()) + ",\"abi\":" + Json.quote(abi) + "}"
                : "{\"ok\":false,\"error\":" + Json.quote(err) + "}";
        }
    }

    @JavascriptInterface
    public void engineSend(String line) { EngineProcess e; synchronized (this) { e = engine; } if (e != null) e.send(line); }

    @JavascriptInterface
    public void engineStop() {
        EngineProcess e; synchronized (this) { e = engine; }
        diagnostics.log("INFO", "engine.stop_requested", "Stop requested by app");
        if (e != null) e.stop();
    }

    private void queueLine(String line) {
        synchronized (pending) {
            pending.add(line);
            if (pending.size() > 400) {                       // UI thread stalled: drop old progress lines, never results
                for (int i = 0; i < pending.size() && pending.size() > 200; ) {
                    String s = pending.get(i);
                    if (s.startsWith("info ") && !s.startsWith("info string")) pending.remove(i); else i++;
                }
            }
            if (!flushScheduled) { flushScheduled = true; main.postDelayed(flushTask, 30); }
        }
    }

    private final Runnable flushTask = new Runnable() { @Override public void run() { flushNow(); } };

    private void flushNow() {
        ArrayList<String> batch;
        synchronized (pending) { batch = new ArrayList<String>(pending); pending.clear(); flushScheduled = false; }
        if (batch.isEmpty()) return;
        StringBuilder sb = new StringBuilder("window.__cbNative&&window.__cbNative.engineLines([");
        for (int i = 0; i < batch.size(); i++) { if (i > 0) sb.append(','); sb.append(Json.quote(batch.get(i))); }
        sb.append("])");
        js(sb.toString());
    }

    /* ---------------- HTTP with the stored key ---------------- */

    @JavascriptInterface
    public void httpPost(final String reqId, final String keyId, final String url, final String authScheme, final String extraHeaders, final String body) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result r;
                long started = System.currentTimeMillis();
                try { r = run2(); } catch (RuntimeException e) {
                    diagnostics.log("ERROR", "network.post_unexpected_error", "Unexpected POST error: " + e.getClass().getSimpleName());
                    r = new HttpTransport.Result(0, "", "io", "Unexpected error: " + e.getClass().getSimpleName());
                }
                diagnostics.log(r.status >= 200 && r.status < 300 ? "INFO" : "WARN", "network.post", safeEndpoint(url) + " status=" + r.status + " kind=" + r.kind + " durationMs=" + (System.currentTimeMillis() - started));
                inflight.remove(reqId);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(r.body) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
            private HttpTransport.Result run2() {
                String why = HostPolicy.check(url);
                if (why != null) return new HttpTransport.Result(0, "", "policy", why);
                String authName = null, authValue = null;
                String key = SecretStore.validId(keyId) ? secrets.get(keyId) : null;
                boolean local = url.toLowerCase().startsWith("http://");
                if (key == null && !local) return new HttpTransport.Result(0, "", "nokey", "");
                if (key != null) {
                    if ("x-api-key".equals(authScheme)) { authName = "x-api-key"; authValue = key; }
                    else if ("bearer".equals(authScheme)) { authName = "Authorization"; authValue = "Bearer " + key; }
                }
                return HttpTransport.post(url, authName, authValue, extraHeaders, body, 15000, 120000, MAX_RESPONSE_BYTES, tok);
            }
        });
    }

    /** Supabase Auth calls. Refresh tokens stay inside encrypted native storage and are never returned to JavaScript. */
    @JavascriptInterface
    public void supabaseAuth(final String reqId, final String operation, final String payload) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result r;
                try { r = runAuth(); }
                catch (RuntimeException e) {
                    diagnostics.log("ERROR", "auth.unexpected_error", "Unexpected authentication error: " + e.getClass().getSimpleName());
                    r = new HttpTransport.Result(0, "", "io", "Authentication request failed: " + e.getClass().getSimpleName());
                }
                inflight.remove(reqId);
                String safeBody = redactRefreshToken(r.body);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(safeBody) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
            private HttpTransport.Result runAuth() {
                String op = operation == null ? "" : operation;
                String endpoint, body = payload == null ? "{}" : payload;
                String bearer = null;
                if ("signup".equals(op)) endpoint = "/auth/v1/signup?redirect_to=chessbuddy%3A%2F%2Fauth-callback";
                else if ("signin".equals(op)) endpoint = "/auth/v1/token?grant_type=password";
                else if ("phone".equals(op)) endpoint = "/auth/v1/otp";
                else if ("verify".equals(op)) endpoint = "/auth/v1/verify";
                else if ("exchange".equals(op)) {
                    endpoint = "/auth/v1/token?grant_type=pkce";
                    String code = jsonStringField(body, "auth_code");
                    String verifier = secrets.get(SUPABASE_PKCE_VERIFIER_ID);
                    if (code == null || code.length() < 8 || verifier == null || verifier.length() < 43) {
                        secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                        return new HttpTransport.Result(400, "", "policy", "The sign-in callback could not be verified. Start sign-in again.");
                    }
                    body = "{\"auth_code\":" + Json.quote(code) + ",\"code_verifier\":" + Json.quote(verifier) + "}";
                }
                else if ("session".equals(op)) {
                    String access = jsonStringField(body, "access_token");
                    String refresh = jsonStringField(body, "refresh_token");
                    if (access == null || access.length() < 20 || refresh == null || refresh.length() < 20)
                        return new HttpTransport.Result(400, "", "policy", "The confirmation link did not contain a complete session. Return to ChessBuddy and sign in again.");
                    HttpTransport.Result checked = HttpTransport.get(SUPABASE_URL + "/auth/v1/user", "apikey: " + SUPABASE_PUBLISHABLE_KEY + "\nAuthorization: Bearer " + access,
                        15000, 30000, MAX_RESPONSE_BYTES, tok);
                    if (checked.kind.length() > 0 || checked.status < 200 || checked.status >= 300) return checked;
                    if (!secrets.set(SUPABASE_REFRESH_ID, refresh) || !refresh.equals(secrets.get(SUPABASE_REFRESH_ID))) {
                        diagnostics.log("ERROR", "auth.session_store_failed", "Could not persist a verified refresh session");
                        return new HttpTransport.Result(500, "", "storage", "ChessBuddy verified your sign-in but could not save it securely on this device. Check device security storage, then sign in again.");
                    }
                    secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                    diagnostics.log("INFO", "auth.callback_success", "Email or provider callback validated");
                    return checked;
                }
                else if ("refresh".equals(op)) {
                    endpoint = "/auth/v1/token?grant_type=refresh_token";
                    String refresh = secrets.get(SUPABASE_REFRESH_ID);
                    if (refresh == null) return new HttpTransport.Result(401, "", "noauth", "No saved session on this device. Sign in or create an account.");
                    body = "{\"refresh_token\":" + Json.quote(refresh) + "}";
                } else if ("logout".equals(op)) {
                    endpoint = "/auth/v1/logout";
                    bearer = jsonStringField(body, "access_token");
                    body = "{}";
                    if (bearer == null || bearer.length() < 20) { secrets.clear(SUPABASE_REFRESH_ID); return new HttpTransport.Result(200, "{}", "", ""); }
                } else return new HttpTransport.Result(400, "", "policy", "Unsupported authentication action.");

                String headers = "apikey: " + SUPABASE_PUBLISHABLE_KEY;
                if (bearer != null) headers += "\nAuthorization: Bearer " + bearer;
                HttpTransport.Result result = HttpTransport.post(SUPABASE_URL + endpoint, null, null, headers, body,
                    15000, 30000, MAX_RESPONSE_BYTES, tok);
                if (result.kind.length() > 0 || result.status < 200 || result.status >= 300) {
                    if ("refresh".equals(op) && (result.status == 400 || result.status == 401)) secrets.clear(SUPABASE_REFRESH_ID);
                    if ("exchange".equals(op)) secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                    diagnostics.log("WARN", "auth." + op + ".failed", "status=" + result.status + " kind=" + result.kind);
                    return result;
                }

                if ("logout".equals(op)) {
                    secrets.clear(SUPABASE_REFRESH_ID);
                    diagnostics.log("INFO", "auth.logout", "Session cleared from this device");
                    return result;
                }
                String refresh = jsonStringField(result.body, "refresh_token");
                String access = jsonStringField(result.body, "access_token");
                if (refresh != null && refresh.length() > 20) {
                    if (!secrets.set(SUPABASE_REFRESH_ID, refresh) || !refresh.equals(secrets.get(SUPABASE_REFRESH_ID))) {
                        diagnostics.log("ERROR", "auth.session_store_failed", "Could not persist refresh token after " + op);
                        return new HttpTransport.Result(500, "", "storage", "Sign-in worked, but ChessBuddy could not save the session securely. Check Android security storage and sign in again.");
                    }
                } else if (access != null && access.length() > 20 && ("signin".equals(op) || "verify".equals(op) || "exchange".equals(op) || "refresh".equals(op))) {
                    diagnostics.log("ERROR", "auth.refresh_missing", "Authentication response did not include a refresh token");
                    return new HttpTransport.Result(500, "", "storage", "The sign-in server did not return a session token. Try again.");
                }
                if ("exchange".equals(op)) {
                    secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                }
                diagnostics.log("INFO", "auth." + op + ".success", "status=" + result.status + " savedSession=" + (refresh != null));
                return result;
            }

        });
    }

    private static String safeEndpoint(String raw) {
        try {
            Uri u = Uri.parse(raw);
            String host = u.getHost() == null ? "unknown-host" : u.getHost();
            String path = u.getPath() == null ? "/" : u.getPath();
            return host + path;
        } catch (Exception e) { return "unknown-endpoint"; }
    }

    private static String jsonStringField(String json, String field) {
        if (json == null || field == null) return null;
        Pattern p = Pattern.compile("\"" + Pattern.quote(field) + "\"\\s*:\\s*\"([^\"]*)\"");
        Matcher m = p.matcher(json);
        return m.find() ? m.group(1) : null;
    }

    private static String redactRefreshToken(String json) {
        if (json == null || json.length() == 0) return json == null ? "" : json;
        return json.replaceAll("\"refresh_token\"\\s*:\\s*\"[^\"]*\"", "\"refresh_token\":\"[stored securely on device]\"");
    }

    /** Public GET requests. No API key or Authorization header is attached. */
    @JavascriptInterface
    public void httpGet(final String reqId, final String url, final String extraHeaders) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result r;
                long started = System.currentTimeMillis();
                try {
                    String why = HostPolicy.check(url);
                    r = why == null ? HttpTransport.get(url, extraHeaders, 10000, 15000, 1024 * 1024, tok)
                        : new HttpTransport.Result(0, "", "policy", why);
                } catch (RuntimeException e) {
                    diagnostics.log("ERROR", "network.get_unexpected_error", "Unexpected GET error: " + e.getClass().getSimpleName());
                    r = new HttpTransport.Result(0, "", "io", "Unexpected error: " + e.getClass().getSimpleName());
                }
                diagnostics.log(r.status >= 200 && r.status < 300 ? "INFO" : "WARN", "network.get", safeEndpoint(url) + " status=" + r.status + " kind=" + r.kind + " durationMs=" + (System.currentTimeMillis() - started));
                inflight.remove(reqId);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(r.body) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
        });
    }

    /** Starts a standards-based PKCE flow. The verifier remains encrypted in Android Keystore storage. */
    @JavascriptInterface
    public String createAuthChallenge() {
        try {
            SecureRandom random = new SecureRandom();
            byte[] verifierBytes = new byte[32];
            random.nextBytes(verifierBytes);
            String verifier = Base64.encodeToString(verifierBytes, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes("UTF-8"));
            String challenge = Base64.encodeToString(digest, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            if (!secrets.set(SUPABASE_PKCE_VERIFIER_ID, verifier)) {
                secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                diagnostics.log("ERROR", "auth.pkce_storage_failed", "Could not store PKCE verifier securely");
                return "";
            }
            diagnostics.log("INFO", "auth.pkce_created", "OAuth PKCE challenge created");
            return "{\"challenge\":" + Json.quote(challenge) + "}";
        } catch (Exception e) {
            diagnostics.log("ERROR", "auth.pkce_error", "PKCE challenge creation failed: " + e.getClass().getSimpleName());
            return "";
        }
    }

    /** Opens only this project's Supabase authorization endpoint in the system browser. */
    @JavascriptInterface
    public boolean openAuthUrl(final String url) {
        if (url == null) return false;
        final Uri uri;
        try { uri = Uri.parse(url); } catch (Exception e) { return false; }
        if (!"https".equalsIgnoreCase(uri.getScheme()) || !"npicptuurxuqxepxzumi.supabase.co".equalsIgnoreCase(uri.getHost())
            || !"/auth/v1/authorize".equals(uri.getPath()) || uri.getQueryParameter("provider") == null
            || !"chessbuddy://auth-callback".equals(uri.getQueryParameter("redirect_to"))) return false;
        main.post(new Runnable() { @Override public void run() {
            try {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
                diagnostics.log("INFO", "auth.oauth_browser_opened", "OAuth provider=" + uri.getQueryParameter("provider"));
            } catch (Exception e) {
                diagnostics.log("ERROR", "auth.oauth_browser_failed", "Could not open browser: " + e.getClass().getSimpleName());
                Toast.makeText(activity, "Couldn't open the sign-in page. Check that a browser is installed.", Toast.LENGTH_LONG).show();
            }
        } });
        return true;
    }

    @JavascriptInterface
    public void logEvent(String event, String detail) {
        if (diagnostics != null) diagnostics.log("INFO", event, detail);
    }

    @JavascriptInterface
    public String diagnosticsLocation() { return diagnostics == null ? "" : diagnostics.location(); }

    @JavascriptInterface
    public void httpCancel(String reqId) { HttpTransport.CancelToken t = reqId == null ? null : inflight.get(reqId); if (t != null) t.cancel(); }

    /* ---------------- keys (never returned to JS) ---------------- */

    @JavascriptInterface public boolean hasKey(String id) { return secrets.has(id); }
    @JavascriptInterface public String keyHint(String id) { return secrets.hint(id); }
    @JavascriptInterface public boolean setKey(String id, String key) { return secrets.set(id, key); }
    @JavascriptInterface public boolean clearKey(String id) { secrets.clear(id); return true; }
    @JavascriptInterface public boolean secureStorage() { return secrets.secureStorage(); }

    /* ---------------- device helpers ---------------- */

    @JavascriptInterface
    public boolean copyText(final String text) {
        if (text == null) return false;
        main.post(new Runnable() { @Override public void run() {
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("ChessBuddy", text));
        } });
        return true;
    }

    @JavascriptInterface
    public boolean shareText(final String title, final String text) {
        if (text == null) return false;
        main.post(new Runnable() { @Override public void run() {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "ChessBuddy" : title);
            send.putExtra(Intent.EXTRA_TEXT, text);
            activity.startActivity(Intent.createChooser(send, title == null ? "Share" : title));
        } });
        return true;
    }

    @JavascriptInterface
    public void toast(final String msg) { main.post(new Runnable() { @Override public void run() { Toast.makeText(activity, msg == null ? "" : msg, Toast.LENGTH_SHORT).show(); } }); }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        main.post(new Runnable() { @Override public void run() {
            if (on) activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } });
    }

    @JavascriptInterface
    public String deviceInfo() {
        long memMb = 0;
        try {
            ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            if (am != null) { am.getMemoryInfo(mi); memMb = mi.totalMem / (1024 * 1024); }
        } catch (RuntimeException ignored) { /* keep 0 */ }
        String version = "", abi = Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "";
        long code = 0;
        try {
            PackageInfo pi = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            version = pi.versionName == null ? "" : pi.versionName;
            code = pi.versionCode;
        } catch (Exception ignored) { /* keep defaults */ }
        return "{\"cores\":" + Runtime.getRuntime().availableProcessors() + ",\"memMb\":" + memMb + ",\"abi\":" + Json.quote(abi)
            + ",\"sdk\":" + Build.VERSION.SDK_INT + ",\"version\":" + Json.quote(version) + ",\"versionCode\":" + code + "}";
    }

    void shutdown() {
        destroyed = true;
        EngineProcess e; synchronized (this) { e = engine; engine = null; }
        if (e != null) e.shutdown();
        for (HttpTransport.CancelToken t : inflight.values()) t.cancel();
        pool.shutdownNow();
    }

    File filesDir() { return activity.getFilesDir(); }
}
