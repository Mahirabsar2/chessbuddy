const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
console.log('online.js (Supabase client)');

function setup() {
  const calls = [];
  global.CBNative = {
    available: true,
    setKey: (id, key) => { calls.push({ type: 'setKey', id, key }); return true; },
    createAuthChallenge: () => ({ challenge: 'pkce-challenge-test' }),
    openAuthUrl: url => { calls.push({ type: 'oauth', url }); return true; },
    supabaseAuth: (op, payload) => {
      calls.push({ type: 'auth', op, payload });
      const result = op === 'signin' || op === 'refresh'
        ? { status: 200, body: JSON.stringify({ access_token: 'access-token-for-tests-123456', user: { id: 'me-uuid' }, refresh_token: '[stored natively]' }) }
        : op === 'session' ? { status: 200, body: JSON.stringify({ id: 'me-uuid', email: 'player@example.com' }) }
        : { status: 200, body: '{}' };
      return { promise: Promise.resolve(result) };
    },
    httpGet: (url, headers) => {
      calls.push({ type: 'get', url, headers });
      let body = '[]';
      if (url.includes('/chessbuddy_profiles?')) body = JSON.stringify([
        { user_id: 'other', username: 'friend_1', display_name: 'Friend' },
        { user_id: 'me-uuid', username: 'my_name', display_name: 'Me' }
      ]);
      if (url.includes('/chessbuddy_presence?')) body = JSON.stringify([{ user_id: 'other', status: 'online', last_seen: new Date().toISOString() }]);
      if (url.includes('/chessbuddy_games?')) body = JSON.stringify([{ id: 'game-uuid' }]);
      return { promise: Promise.resolve({ status: 200, body }) };
    },
    http: req => {
      calls.push({ type: 'post', req });
      const body = req.url.endsWith('/functions/v1/chessbuddy-apply-move') ? '{"ok":true}' : '"challenge-id"';
      return { promise: Promise.resolve({ status: 200, body }) };
    }
  };
  delete require.cache[require.resolve('../../app/src/main/assets/js/online.js')];
  require('../../app/src/main/assets/js/online.js');
  return { api: global.CBOnline, calls };
}

test('stores only the public key through native storage and keeps the access token in memory', async () => {
  const { api, calls } = setup();
  assert.strictEqual(calls[0].type, 'setKey');
  await api.signIn('player@example.com', 'a-password');
  assert.strictEqual(api.signedIn(), true);
  assert.strictEqual(api.user().id, 'me-uuid');
  const auth = calls.find(c => c.type === 'auth');
  assert.strictEqual(auth.op, 'signin');
  assert.deepStrictEqual(auth.payload, { email: 'player@example.com', password: 'a-password' });
});


test('email confirmation callback adopts and validates a returned access/refresh session', async () => {
  const { api, calls } = setup();
  await api.handleAuthCallback('chessbuddy://auth-callback#access_token=callback-access-token-123456&refresh_token=callback-refresh-token-123456&type=signup');
  assert.strictEqual(api.signedIn(), true);
  assert.strictEqual(api.user().id, 'me-uuid');
  const auth = calls.find(c => c.type === 'auth');
  assert.strictEqual(auth.op, 'session');
  assert.strictEqual(auth.payload.access_token, 'callback-access-token-123456');
});

test('email confirmation token hash uses Supabase verify endpoint through native auth', async () => {
  const { api, calls } = setup();
  await api.handleAuthCallback('chessbuddy://auth-callback?token_hash=confirmation-token&type=signup');
  const auth = calls.find(c => c.type === 'auth');
  assert.strictEqual(auth.op, 'verify');
  assert.deepStrictEqual(auth.payload, { token_hash: 'confirmation-token', type: 'signup' });
});


test('social sign-in builds a PKCE deep-link authorization request', async () => {
  const { api, calls } = setup();
  await api.signInWithProvider('google');
  const oauth = calls.find(c => c.type === 'oauth');
  assert.ok(oauth.url.includes('/auth/v1/authorize?provider=google'));
  assert.ok(oauth.url.includes('code_challenge=pkce-challenge-test'));
  assert.ok(oauth.url.includes('code_challenge_method=s256'));
  assert.ok(!oauth.url.includes('state='));
  assert.ok(oauth.url.includes('redirect_to=chessbuddy%3A%2F%2Fauth-callback'));
});

test('OAuth callback exchanges the authorization code through native PKCE auth', async () => {
  const { api, calls } = setup();
  await api.handleAuthCallback('chessbuddy://auth-callback?code=single-use-code-123456');
  const auth = calls.find(c => c.type === 'auth');
  assert.strictEqual(auth.op, 'exchange');
  assert.deepStrictEqual(auth.payload, { auth_code: 'single-use-code-123456' });
});

test('phone sign-in sends SMS OTP and verifies the code', async () => {
  const { api, calls } = setup();
  await api.sendPhoneCode('+8801712345678', false);
  await api.verifyPhoneCode('+8801712345678', '123456');
  const auth = calls.filter(c => c.type === 'auth');
  assert.strictEqual(auth[0].op, 'phone');
  assert.deepStrictEqual(auth[0].payload, { phone: '+8801712345678', create_user: false });
  assert.strictEqual(auth[1].op, 'verify');
  assert.deepStrictEqual(auth[1].payload, { phone: '+8801712345678', token: '123456', type: 'sms' });
});

test('roster combines profiles and a fresh presence heartbeat', async () => {
  const { api } = setup();
  await api.signIn('player@example.com', 'a-password');
  const roster = await api.roster();
  assert.strictEqual(roster.length, 1);
  assert.strictEqual(roster[0].username, 'friend_1');
  assert.strictEqual(roster[0].online, true);
});

test('direct challenge uses the expected authenticated RPC and never matchmaking', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  const id = await api.sendChallenge('opponent-uuid', '3+2', 'w');
  assert.strictEqual(id, 'challenge-id');
  const post = calls.find(c => c.type === 'post').req;
  assert.ok(post.url.endsWith('/rpc/cb_send_challenge'));
  assert.strictEqual(post.authScheme, 'none');
  assert.ok(post.extraHeaders.includes('Authorization: Bearer access-token-for-tests-123456'));
  assert.deepStrictEqual(JSON.parse(post.body), { p_to_user: 'opponent-uuid', p_time_control: '3+2', p_color: 'w' });
});

test('game lookup uses a valid PostgREST id filter', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  const game = await api.game('game-uuid');
  assert.strictEqual(game.id, 'game-uuid');
  const get = calls.find(c => c.type === 'get' && c.url.includes('/chessbuddy_games?'));
  assert.ok(get.url.includes('&id=eq.game-uuid'));
  assert.ok(!get.url.includes('& id='));
});

test('online moves send only the move to the deployed server validator', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  await api.applyMove({ id: 'game-uuid', move: { from: 'e2', to: 'e4' } });
  const post = calls.find(c => c.type === 'post' && c.req.url.endsWith('/functions/v1/chessbuddy-apply-move')).req;
  assert.strictEqual(post.authScheme, 'none');
  assert.ok(post.extraHeaders.includes('Authorization: Bearer access-token-for-tests-123456'));
  assert.deepStrictEqual(JSON.parse(post.body), { game_id: 'game-uuid', from: 'e2', to: 'e4' });
  assert.ok(!post.body.includes('p_next_fen'));
  assert.ok(!post.body.includes('p_pgn'));
  assert.ok(!post.body.includes('white_ms'));
});

test('online move rejects invalid coordinates before network submission', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  await assert.rejects(() => api.applyMove({ id: 'game-uuid', move: { from: 'z9', to: 'e4' }, whiteMs: 1, blackMs: 1 }), /valid chess move/);
  assert.strictEqual(calls.filter(c => c.type === 'post').length, 0);
});

test('timeout and resignation use authenticated participant RPCs', async () => {
  const { api, calls } = setup();
  await api.signIn('player@example.com', 'a-password');
  await api.claimTimeout('game-uuid');
  await api.resignGame('game-uuid');
  const posts = calls.filter(c => c.type === 'post').map(c => c.req);
  assert.ok(posts.some(p => p.url.endsWith('/rpc/cb_claim_timeout')));
  assert.ok(posts.some(p => p.url.endsWith('/rpc/cb_resign_game')));
});

test('sign out clears the in-memory session', async () => {
  const { api } = setup();
  await api.signIn('player@example.com', 'a-password');
  await api.signOut();
  assert.strictEqual(api.signedIn(), false);
  assert.strictEqual(api.user(), null);
});

done('online.js');
