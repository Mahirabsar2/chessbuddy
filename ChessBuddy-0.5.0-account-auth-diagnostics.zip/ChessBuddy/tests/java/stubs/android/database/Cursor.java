package android.database;
public interface Cursor { boolean moveToFirst(); long getLong(int column); String getString(int column); void close(); }
