package android.provider;
import android.net.Uri;
public class MediaStore {
 public static class MediaColumns {
  public static final String DISPLAY_NAME="_display_name", MIME_TYPE="mime_type", RELATIVE_PATH="relative_path", IS_PENDING="is_pending", _ID="_id", SIZE="_size";
 }
 public static class Files { public static Uri getContentUri(String volume){return new Uri("content://media/"+volume+"/file");} }
}
