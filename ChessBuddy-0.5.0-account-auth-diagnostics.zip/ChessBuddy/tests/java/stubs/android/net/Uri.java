package android.net;
public class Uri {
 private final String value;
 public Uri(){this("");} public Uri(String v){value=v;}
 public static Uri parse(String s){return new Uri(s);}
 public static Uri withAppendedPath(Uri base,String path){return new Uri(base.toString().replaceAll("/$","")+"/"+path);}
 public String toString(){return value;}
 public String getScheme(){try{return new java.net.URI(value).getScheme();}catch(Exception e){return null;}}
 public String getHost(){try{return new java.net.URI(value).getHost();}catch(Exception e){return null;}}
 public String getPath(){try{return new java.net.URI(value).getPath();}catch(Exception e){return null;}}
 public String getQueryParameter(String key){try{String q=new java.net.URI(value).getRawQuery(); if(q==null)return null; for(String p:q.split("&")){String[] a=p.split("=",2); if(java.net.URLDecoder.decode(a[0],"UTF-8").equals(key))return a.length>1?java.net.URLDecoder.decode(a[1],"UTF-8"):"";} }catch(Exception e){} return null;}
}