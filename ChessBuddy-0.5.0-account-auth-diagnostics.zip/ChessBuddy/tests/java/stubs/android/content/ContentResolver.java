package android.content;
import android.database.Cursor;
import android.net.Uri;
public class ContentResolver {
 public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){return null;}
 public Uri insert(Uri uri,ContentValues values){return null;}
 public java.io.OutputStream openOutputStream(Uri uri,String mode) throws java.io.FileNotFoundException{return null;}
}
