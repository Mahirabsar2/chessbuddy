# ChessBuddy development status

## Verified baseline

- Latest verified APK/source pair in the supplied build artifact: ChessBuddy 0.5.0, build 19.
- Source archive SHA-256: `9a44bea995abe256d17df804d65cb3887f296f3b58ad4f872244ff2faad2f444`.
- The build-19 APK was previously verified by its build pipeline; it is not a 5.0 release.

## 5.0 development work in this source tree

- Existing 0.5.0 prototype features: clock-aware Stockfish search, randomized bot thinking delay, faster game review, original SVG bot portrait variations, Lichess opening explorer/tablebase lookups, and friend-play client.
- Online client now submits only the move to the deployed `chessbuddy-apply-move` Edge Function.
- Server move validation replays the stored PGN with `chess.js`, checks FEN/turn consistency, and derives results.
- Database migration `20261116193538_server_validated_online_moves_v2` adds an atomic service-role-only commit that checks both expected FEN and PGN and calculates clocks server-side.
- Database migration `20261116193649_online_game_foreign_key_indexes` adds the five missing foreign-key indexes.
- API-key storage no longer falls back to plaintext. Legacy plaintext entries are migrated to Android Keystore encryption or erased; a save fails if secure storage is unavailable.

## Tests run in this workspace

- JavaScript logic tests: 90 passed.
- Java policy and SecretStore tests: passed.
- TypeScript Edge Function check with local ambient declarations: passed.
- Supabase verification: Edge Function `chessbuddy-apply-move` version 4 is active; the new move RPC is executable by `service_role` only; `anon` and `authenticated` cannot execute it.

## Not yet verified

- No new Gradle/NDK APK build was run in this workspace (Gradle and Android SDK are unavailable here).
- Playwright UI tests were not run because Playwright is not installed in this workspace.
- No two-device online match has been completed after the deployed validator update.
- Maia/Lc0 is not playable in this baseline. Do not advertise it as shipped.
- This source tree is still versioned `0.5.0`; it is a security/backend development milestone, not the finished ChessBuddy 5.0 release.
