# Maia / Leela Chess Zero integration status

Maia 1100, 1500, and 1900 are human-move prediction networks, not stand-alone engines. They require the Lc0 UCI engine and are intended to use one-node policy inference (`go nodes 1`).

## Not enabled in 0.5.0

Maia is **not** a selectable or playable opponent in this build. The current Android native bridge launches the bundled Stockfish process only; it does not launch Lc0, load Maia network files, or offer Maia 1100/1500/1900 in the opponent roster.

The official Lc0 Android release is documented as an engine-only APK intended to work with a compatible chess GUI through the Open Exchange protocol. That is a different integration path from ChessBuddy's bundled UCI process. The Maia v1 weight files are also distributed separately from the software and their redistribution terms need to be confirmed before the app bundles them. Therefore this build does not silently bundle those files or show fake Maia entries.

## Required engineering work

1. Add and test an Lc0 Android engine transport in the app's process sandbox or a verified Open Exchange client integration.
2. Confirm model-weight licensing and attribution; then provide a checksum-verified, user-initiated model download (not an unverified binary bundled in the APK).
3. Add Maia 1100, 1500, and 1900 to the existing opponent roster, pass the selected network path to Lc0, and issue the documented one-node search.
4. Verify inference, cancellation, memory use, and legal-move output on the target Android devices before enabling the entries.

References: [Maia model instructions](https://github.com/CSSLab/maia-chess), [Lc0 Android guidance](https://lczero.org/dev/wiki/running-lc0-on-android-with-a-chess-gui/), and [official Lc0 downloads](https://lczero.org/play/download/).
