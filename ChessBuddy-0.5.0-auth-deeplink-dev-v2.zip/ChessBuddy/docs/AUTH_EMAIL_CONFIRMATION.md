# Android email confirmation

ChessBuddy uses the `chessbuddy://auth-callback` Android deep link for Supabase email confirmation. The signup request explicitly supplies this redirect URL. Android's exported launcher activity accepts only the `chessbuddy` scheme and `auth-callback` host, then forwards the URI to the bundled app after the WebView is ready.

The callback supports both Supabase confirmation styles: a `token_hash` query parameter (verified through `/auth/v1/verify`) and an access/refresh-token pair returned in the URL fragment. For fragment sessions, the native bridge validates the access token against `/auth/v1/user` before storing the refresh token in encrypted Android storage. Access tokens remain in JavaScript memory only.

Supabase Dashboard → Authentication → URL Configuration → Redirect URLs must include exactly `chessbuddy://auth-callback`. The Site URL can remain unchanged.

This change requires a newly built APK. A source ZIP alone cannot update an already-installed app. Device-level confirmation testing is still required.
