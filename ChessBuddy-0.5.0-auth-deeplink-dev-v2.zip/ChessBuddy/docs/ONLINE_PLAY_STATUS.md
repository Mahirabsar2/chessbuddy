# ChessBuddy online friend play — 5.0 development

## Client flow

- Email/password sign-up and sign-in through Supabase Auth.
- Refresh tokens remain in Android `SecretStore`; Android Keystore AES-GCM encryption is required for writes. If Keystore is unavailable, saving a secret fails rather than writing plaintext. Legacy plaintext entries are migrated when possible or erased. JavaScript receives only the short-lived access token; passwords are not persisted.
- Username/display-name profile setup, online/away presence, and a roster of profiles with recent heartbeats.
- Direct challenges to a selected player with time control and colour preference; accept, decline, and cancel. No random matchmaking.
- Active-game list and polling-based FEN/PGN/clock synchronization.

## Server-side move validation — deployed

The connected Supabase project has the `chessbuddy-apply-move` Edge Function deployed at version 4. The client sends only `game_id`, `from`, `to`, and optional `promotion`; it never submits an authoritative FEN, PGN, clock value, or claimed winner.

The Edge Function validates the user's session and publishable API key, confirms the player and turn, replays the server-stored PGN, checks that the replayed FEN and side-to-move match the stored game, and applies the move with `chess.js`. It derives checkmate/draw results and writes the PGN result header itself.

The `cb_apply_move_server_v2` database RPC was added in migration `20261116193538_server_validated_online_moves_v2`. It is executable only by `service_role`; `anon` and `authenticated` cannot execute it. It locks the game row, checks the expected previous FEN **and PGN**, verifies the actor/turn again, calculates elapsed clock time from the server timestamp, awards the configured increment, and resolves timeouts. This closes the stale-history race where two different PGNs could share the same FEN.

Migration `20261116193649_online_game_foreign_key_indexes` adds indexes for the five previously unindexed foreign keys. The performance advisor no longer reports unindexed foreign keys; its remaining notices are unused-index notices on the still-small tables.

## Remaining verification limits

- The Supabase backend changes are deployed and the database grants were checked. The new Android client changes are in this development source, but a new APK has not yet been built or installed.
- Online play has not been tested end-to-end on two physical Android devices with separate accounts. Do not treat multiplayer as device-verified until that test passes.
- Presence, invitations, and games still use periodic HTTP polling; there are no push notifications or Realtime socket subscriptions.
- Server clocks advance from move timestamps and are checked when a move is committed or a timeout is claimed; there is no continuously running background clock worker.
- The security advisor still flags seven client-callable `SECURITY DEFINER` RPCs used for profile, presence, challenge, resignation, and timeout actions. Their definitions use an empty search path and check `auth.uid()`/participant ownership. These are intentional client operations, but should remain under review.

## Database objects

Tables: `chessbuddy_profiles`, `chessbuddy_presence`, `chessbuddy_challenges`, `chessbuddy_games`.

Client RPCs: `cb_register_profile`, `cb_set_presence`, `cb_send_challenge`, `cb_respond_challenge`, `cb_cancel_challenge`, `cb_claim_timeout`, and `cb_resign_game`.

Server-only move RPCs: `cb_apply_move_server`, `cb_apply_move_server_v2` (new), and the legacy `cb_apply_move`. Never put a Supabase service-role/secret key in the Android app.
