export const STANDARD_START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'

/** Rebuild the authoritative position from the stored PGN, then apply exactly one legal UCI move. */
export function validateAndApplyMove({ row, actor, move, Chess }) {
  if (!row || row.status !== 'active') throw new Error('This game is no longer active.')
  if (actor !== row.white_user_id && actor !== row.black_user_id) throw new Error('You are not a player in this game.')
  if (row.turn_user_id !== actor) throw new Error('It is not your turn.')
  if (row.initial_fen !== STANDARD_START_FEN) throw new Error('This game uses an unsupported starting position.')
  if (!move || !/^[a-h][1-8]$/.test(move.from || '') || !/^[a-h][1-8]$/.test(move.to || '') ||
      (move.promotion !== undefined && !/^[qrbn]$/.test(move.promotion))) {
    throw new Error('Invalid move coordinates or promotion.')
  }

  const game = new Chess(row.initial_fen)
  if (row.pgn) game.loadPgn(row.pgn)
  if (game.fen() !== row.current_fen || game.turn() !== row.turn_color) {
    throw new Error('The saved game history does not match its current position. Reload the game.')
  }

  const mover = game.turn()
  let played
  try {
    played = game.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) })
  } catch {
    throw new Error('That move is illegal in the current position.')
  }
  if (!played) throw new Error('That move is illegal in the current position.')

  const finished = game.isGameOver()
  let result = null
  let winner = null
  if (finished) {
    if (game.isCheckmate()) {
      result = mover === 'w' ? '1-0' : '0-1'
      winner = actor
    } else {
      result = '1/2-1/2'
    }
    game.setHeader('Result', result)
  }
  return { game, finished, result, winner }
}
