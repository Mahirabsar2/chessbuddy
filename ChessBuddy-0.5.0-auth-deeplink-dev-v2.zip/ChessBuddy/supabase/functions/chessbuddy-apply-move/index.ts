import { Chess } from 'chess.js'
import { validateAndApplyMove } from './online-validation.mjs'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? ''
const PUBLISHABLE_KEYS = readKeyMap('SUPABASE_PUBLISHABLE_KEYS')
const SECRET_KEYS = readKeyMap('SUPABASE_SECRET_KEYS')
const PUBLISHABLE_KEY = PUBLISHABLE_KEYS.default ?? Deno.env.get('SUPABASE_PUBLISHABLE_KEY') ?? Deno.env.get('SUPABASE_ANON_KEY') ?? ''
const SERVICE_KEY = SECRET_KEYS.default ?? Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
}

function readKeyMap(name: string): Record<string, string> {
  try { const value = Deno.env.get(name); return value ? JSON.parse(value) : {} }
  catch { return {} }
}
function reply(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), { status, headers: CORS })
}
function adminHeaders() {
  return { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, 'Content-Type': 'application/json' }
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS })
  if (req.method !== 'POST') return reply(405, { error: 'Method not allowed.' })
  if (!SUPABASE_URL || !PUBLISHABLE_KEY || !SERVICE_KEY) return reply(503, { error: 'Online move validation is not configured.' })

  const authorization = req.headers.get('authorization') ?? ''
  const apiKey = req.headers.get('apikey') ?? ''
  if (!/^Bearer\s+\S+$/i.test(authorization) || apiKey !== PUBLISHABLE_KEY) {
    return reply(401, { error: 'Sign in to make an online move.' })
  }

  let input: Record<string, unknown>
  try {
    const length = Number(req.headers.get('content-length') ?? 0)
    if (length > 4096) return reply(413, { error: 'Move request is too large.' })
    const raw = await req.text()
    if (new TextEncoder().encode(raw).byteLength > 4096) return reply(413, { error: 'Move request is too large.' })
    const parsed = JSON.parse(raw)
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return reply(400, { error: 'Invalid move request.' })
    input = parsed as Record<string, unknown>
  } catch {
    return reply(400, { error: 'Invalid move request body.' })
  }

  const gameId = typeof input.game_id === 'string' ? input.game_id : ''
  const from = typeof input.from === 'string' ? input.from : ''
  const to = typeof input.to === 'string' ? input.to : ''
  const promotion = typeof input.promotion === 'string' ? input.promotion.toLowerCase() : ''
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(gameId) ||
      !/^[a-h][1-8]$/.test(from) || !/^[a-h][1-8]$/.test(to) ||
      (input.promotion != null && typeof input.promotion !== 'string') ||
      (promotion && !/^[qrbn]$/.test(promotion))) {
    return reply(400, { error: 'Invalid move request.' })
  }

  try {
    const authResponse = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: PUBLISHABLE_KEY, Authorization: authorization },
    })
    if (!authResponse.ok) return reply(401, { error: 'Your session expired. Sign in again.' })
    const user = await authResponse.json()
    if (!user?.id) return reply(401, { error: 'A valid signed-in account is required.' })

    const gameUrl = new URL(`${SUPABASE_URL}/rest/v1/chessbuddy_games`)
    gameUrl.searchParams.set('select', 'id,white_user_id,black_user_id,initial_fen,current_fen,pgn,turn_user_id,turn_color,time_control,status,updated_at')
    gameUrl.searchParams.set('id', `eq.${gameId}`)
    gameUrl.searchParams.set('limit', '1')
    const gameResponse = await fetch(gameUrl, { headers: adminHeaders() })
    if (!gameResponse.ok) return reply(503, { error: 'Could not load the current game.' })
    const rows = await gameResponse.json()
    const row = rows?.[0]
    if (!row) return reply(404, { error: 'This game is no longer active.' })

    let validated
    try {
      validated = validateAndApplyMove({ row, userId: user.id, from, to, promotion, Chess })
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Move rejected.'
      const status = /not a player/i.test(message) ? 403 : /not legal|invalid move/i.test(message) ? 422 : 409
      return reply(status, { error: message })
    }
    const { chess, finished, result, winner } = validated

    const rpcResponse = await fetch(`${SUPABASE_URL}/rest/v1/rpc/cb_apply_move_server_v2`, {
      method: 'POST',
      headers: adminHeaders(),
      body: JSON.stringify({
        p_game_id: gameId,
        p_actor_user_id: user.id,
        p_expected_fen: row.current_fen,
        p_expected_pgn: row.pgn ?? '',
        p_next_fen: chess.fen(),
        p_pgn: chess.pgn(),
        p_finished: finished,
        p_result: result,
        p_winner: winner,
      }),
    })
    const rpcBody = await rpcResponse.json().catch(() => ({}))
    if (!rpcResponse.ok) {
      const detail = typeof rpcBody?.message === 'string' ? rpcBody.message : ''
      const code = typeof rpcBody?.code === 'string' ? rpcBody.code : ''
      const status = code === '40001' ? 409 : code === '42501' ? 403 : code === 'P0002' ? 404 : 400
      return reply(status, { error: detail || 'The server rejected this move.' })
    }
    if (rpcBody?.status === 'timeout') return reply(409, { error: 'Your clock ran out before the move reached the server.', result: rpcBody })
    return reply(200, { ok: true, fen: chess.fen(), pgn: chess.pgn(), finished, result, winner, clocks: rpcBody })
  } catch {
    return reply(500, { error: 'The move request could not be processed.' })
  }
})
