export const STANDARD_START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'

/** Replay the server's saved game, verify its position, and apply exactly one legal move. */
export function validateAndApplyMove({ row, userId, from, to, promotion, Chess }) {
  if (!row || row.status !== 'active') throw new Error('This game is no longer active.')
  if (userId !== row.white_user_id && userId !== row.black_user_id) throw new Error('You are not a player in this game.')
  if (row.turn_user_id !== userId) throw new Error('It is not your turn.')
  if (!/^[a-h][1-8]$/.test(from || '') || !/^[a-h][1-8]$/.test(to || '') ||
      (promotion && !/^[qrbn]$/.test(promotion))) throw new Error('Invalid move request.')

  const chess = new Chess()
  if (row.pgn) chess.loadPgn(row.pgn)
  else chess.load(row.initial_fen || STANDARD_START_FEN)
  if (chess.fen() !== row.current_fen || chess.turn() !== row.turn_color) {
    throw new Error('The saved game position changed. Reload the latest position before moving.')
  }

  let move
  try { move = chess.move({ from, to, ...(promotion ? { promotion } : {}) }) }
  catch { move = null }
  if (!move) throw new Error('That move is not legal in the current position.')

  const finished = chess.isGameOver()
  let result = null
  let winner = null
  if (finished && chess.isCheckmate()) {
    const winnerColor = chess.turn() === 'w' ? 'b' : 'w'
    result = winnerColor === 'w' ? '1-0' : '0-1'
    winner = winnerColor === 'w' ? row.white_user_id : row.black_user_id
  } else if (finished) {
    result = '1/2-1/2'
  }
  if (finished) chess.setHeader('Result', result)
  return { chess, finished, result, winner }
}
