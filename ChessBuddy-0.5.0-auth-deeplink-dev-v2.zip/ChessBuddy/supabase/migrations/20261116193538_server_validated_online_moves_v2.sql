-- Close the same-FEN/different-PGN race: the service commit must match the
-- exact server-side history that the Edge Function replayed and validated.
create or replace function public.cb_apply_move_server_v2(
  p_game_id uuid,
  p_actor_user_id uuid,
  p_expected_fen text,
  p_expected_pgn text,
  p_next_fen text,
  p_pgn text,
  p_finished boolean default false,
  p_result text default null,
  p_winner uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $function$
declare
  g public.chessbuddy_games;
  v_claims jsonb;
  v_now timestamptz := clock_timestamp();
  v_first_move boolean;
  v_base_ms bigint;
  v_increment_ms bigint;
  v_elapsed_ms bigint;
  v_remaining_ms bigint;
  v_white_ms bigint;
  v_black_ms bigint;
  v_winner uuid;
  v_result text;
begin
  v_claims := nullif(current_setting('request.jwt.claims', true), '')::jsonb;
  if coalesce(v_claims ->> 'role', '') <> 'service_role' then
    raise exception 'This operation is available only to the validated move service' using errcode = '42501';
  end if;
  if p_actor_user_id is null then raise exception 'Missing player identity'; end if;
  if p_expected_fen is null or p_expected_pgn is null or p_next_fen is null or p_pgn is null
     or char_length(p_expected_fen) > 256 or char_length(p_expected_pgn) > 12000
     or char_length(p_next_fen) > 256 or char_length(p_pgn) > 12000
     or p_finished is null then
    raise exception 'Invalid validated game state';
  end if;

  select * into g from public.chessbuddy_games where id = p_game_id for update;
  if not found or g.status <> 'active' then raise exception 'Game unavailable' using errcode = 'P0002'; end if;
  if g.turn_user_id <> p_actor_user_id or p_actor_user_id not in (g.white_user_id, g.black_user_id) then
    raise exception 'It is not your turn' using errcode = '42501';
  end if;
  if g.current_fen <> p_expected_fen or g.pgn is distinct from p_expected_pgn then
    raise exception 'The game position or history has changed' using errcode = '40001';
  end if;

  v_first_move := coalesce(g.pgn, '') = '';
  v_base_ms := case g.time_control
    when '1+0' then 60000 when '3+0' then 180000 when '3+2' then 180000
    when '5+0' then 300000 when '10+0' then 600000 when '15+10' then 900000
    when '30+0' then 1800000 else 0 end;
  v_increment_ms := case g.time_control when '3+2' then 2000 when '15+10' then 10000 else 0 end;
  v_white_ms := case when v_base_ms = 0 then 0 else g.white_ms end;
  v_black_ms := case when v_base_ms = 0 then 0 else g.black_ms end;

  -- White's first move starts Black's clock but is not charged to White.
  -- Every later move is charged against server time, then receives its increment.
  if v_base_ms > 0 and not v_first_move then
    v_elapsed_ms := greatest(0, floor(extract(epoch from (v_now - g.updated_at)) * 1000)::bigint);
    if g.turn_color = 'w' then v_remaining_ms := greatest(0, g.white_ms - v_elapsed_ms);
    else v_remaining_ms := greatest(0, g.black_ms - v_elapsed_ms); end if;
    if v_remaining_ms <= 0 then
      v_winner := case when g.turn_color = 'w' then g.black_user_id else g.white_user_id end;
      v_result := case when v_winner = g.white_user_id then '1-0' else '0-1' end;
      update public.chessbuddy_games set status = 'finished', result = v_result,
        winner_user_id = v_winner, updated_at = v_now where id = p_game_id;
      return jsonb_build_object('status', 'timeout', 'result', v_result, 'winner_user_id', v_winner);
    end if;
    if g.turn_color = 'w' then v_white_ms := v_remaining_ms + v_increment_ms;
    else v_black_ms := v_remaining_ms + v_increment_ms; end if;
  elsif v_base_ms > 0 then
    v_white_ms := greatest(0, least(g.white_ms, v_base_ms));
    v_black_ms := greatest(0, least(g.black_ms, v_base_ms));
  end if;

  if p_finished then
    if p_result is null or p_result not in ('1-0', '0-1', '1/2-1/2') then raise exception 'Invalid game result'; end if;
    if p_result = '1-0' and p_winner is distinct from g.white_user_id then raise exception 'Invalid winner'; end if;
    if p_result = '0-1' and p_winner is distinct from g.black_user_id then raise exception 'Invalid winner'; end if;
    if p_result = '1/2-1/2' and p_winner is not null then raise exception 'A drawn game has no winner'; end if;
  elsif p_result is not null or p_winner is not null then
    raise exception 'An unfinished game cannot have a result';
  end if;

  update public.chessbuddy_games set
    current_fen = p_next_fen,
    pgn = p_pgn,
    white_ms = v_white_ms,
    black_ms = v_black_ms,
    turn_user_id = case when g.turn_user_id = g.white_user_id then g.black_user_id else g.white_user_id end,
    turn_color = case when g.turn_color = 'w' then 'b' else 'w' end,
    status = case when p_finished then 'finished' else 'active' end,
    result = case when p_finished then p_result else null end,
    winner_user_id = case when p_finished then p_winner else null end,
    updated_at = v_now
  where id = p_game_id;

  return jsonb_build_object('status', 'applied', 'white_ms', v_white_ms, 'black_ms', v_black_ms);
end;
$function$;

revoke all on function public.cb_apply_move_server_v2(uuid,uuid,text,text,text,text,boolean,text,uuid) from public, anon, authenticated;
grant execute on function public.cb_apply_move_server_v2(uuid,uuid,text,text,text,text,boolean,text,uuid) to service_role;
