-- Cover the online-play foreign keys used by player/game lookups and cleanup.
create index if not exists chessbuddy_challenges_game_id_idx on public.chessbuddy_challenges (game_id);
create index if not exists chessbuddy_games_black_user_id_idx on public.chessbuddy_games (black_user_id);
create index if not exists chessbuddy_games_turn_user_id_idx on public.chessbuddy_games (turn_user_id);
create index if not exists chessbuddy_games_white_user_id_idx on public.chessbuddy_games (white_user_id);
create index if not exists chessbuddy_games_winner_user_id_idx on public.chessbuddy_games (winner_user_id);
