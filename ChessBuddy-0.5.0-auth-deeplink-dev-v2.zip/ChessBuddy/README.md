# ChessBuddy 0.5.0 prototype

A private Android chess app prototype with a **real Stockfish** engine, a large original bot roster, hand-drawn vector avatars, coaches, Game Review, Lichess reference tools, and AI models
(Claude and any OpenAI-compatible service) that can coach you or play against you.

**Build:** see `BUILD_ON_GITHUB.md` (upload this folder to your GitHub repo; Actions builds the APK). **Status:** `PROJECT_STATUS.md`.

## Play
- **Bots** screen like chess.com: greeting bubble, name + rating + flag, 5-column avatar grid, time-control + colour dock, big Play button.
  Categories: New to Chess, Beginner, Intermediate, Advanced, Master, **Adaptive** (gets stronger/gentler with your results), **Stockfish** (Levels 1–20, Maximum 3200, full strength),
  **Top Players** (living grandmasters), **Legends** (deceased players, e.g. Fischer, Morphy, Tal), Athletes, Musicians, Creators, Personalities, Characters (incl. **Mittens**), **Visualization** (hidden pieces). Crowns show your wins.
- Human vs bot / AI model, AI vs AI, pass-and-play. **Time controls** (1 min … 30 min, increments), clocks, low-time warning, timeout results.
- Game screen: **figurine move strip**, **evaluation bar on top** (or side/off), **captured pieces under the name** with material lead, Options / Analysis / Back / Forward bar, review earlier moves, takeback, hint, flip.
- **Drag and drop** (only pieces that can move can be picked up) or tap; animations (off/fast/medium/slow), sound effects, auto-queen, legal-move dots, last-move highlight, coordinates, white-always-on-bottom.

## Game Review (chess.com model)
Brilliant, Great, Best, Excellent, Good, Book, Inaccuracy, Mistake, Miss, Blunder from expected-points loss; accuracy per side, estimated performance, opening name,
evaluation graph, step-through with a badge on the board and a best-move arrow, Retry, and "Explain" with your AI model. Run it from **Analysis** or after any game.

## Coaches
12 original coaches (incl. Mittens) with their own wording for every rating, voice (optional), and a matching AI-chat style. Play against any coach at a chosen Elo.

## AI models
Models appear by name (Claude Sonnet 5.5 …); any OpenAI-compatible endpoint works. Prompts include the text board, FEN, every move explained, tactical facts, Stockfish lines, legal moves and a board screenshot.
Refresh tokens are stored by the native Android bridge (AES-GCM via Android Keystore where available); JavaScript receives only the current access token.

## Your data survives updates
Settings, models, progress, current game and archive are stored under stable keys and migrated, never reset. Android auto-backup is on (API keys are excluded by design).
Settings → Data → **Back up / Restore** exports models, settings and archive as text.

## Stockfish and clocks
Compiled in CI from the official source (`scripts/build_stockfish_android.sh`) and run as a child process over UCI. If it cannot start the app says so; it never fakes moves. Settings has a real on-device self-test. Strength: UCI_Elo limiter, Skill Level for the Level bots, and a handicap mode for very low Elo. Bot thinking varies between moves; with a clock active, UCI receives both remaining clocks and increments so it can manage its own search budget. The clock begins immediately after White's first move.

## Lichess reference tools
The in-game Options menu includes the Lichess Opening Explorer (Masters and Lichess games) and standard endgame tablebase lookup. Results are cached, requests are serialized, and the client pauses for one minute after a 429 rate-limit response.

## Online friend play (0.5.0)
- Sign in or create an account, choose a username, see currently online players, and challenge a selected person directly. There is no random matchmaking.
- Incoming requests can be accepted or declined; outgoing requests can be cancelled. Games sync moves, PGN/FEN, clocks, resignation, and timeout claims through authenticated Supabase RPCs.
- Presence, invitations, and live games currently use HTTP polling. See `docs/ONLINE_PLAY_STATUS.md` for validation status and the remaining limits. Test a match with two separate accounts/devices before relying on it.

## Maia / Lc0
Maia 1100/1500/1900 are not enabled as playable opponents in 0.5.0. Lc0 Android integration and Maia weight redistribution permission still need to be completed and verified; see `docs/MAIA_LC0_STATUS.md`.

## Not included
Puzzles, lessons, premoves, Maia/Lc0 as a playable opponent, and chess.com's own bots/coaches/artwork (they are licensed or trademarked; ChessBuddy ships original characters). Board/piece themes were intentionally not copied.

## Tests (not in the APK)
`node tests/run-all.js` (pure Node logic tests), `tests/java/run.sh` (Java compile against stubs + URL policy).
