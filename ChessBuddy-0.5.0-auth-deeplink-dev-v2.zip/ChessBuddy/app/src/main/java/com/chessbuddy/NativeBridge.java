package com.chessbuddy;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The only door between the web UI and the device: Stockfish process, HTTP with the stored API key, clipboard, share, toast. */
final class NativeBridge {
    private static final int MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
    // Public client key only. Privileged Supabase keys must never ship in this APK.
    private static final String SUPABASE_URL = "https://npicptuurxuqxepxzumi.supabase.co";
    private static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ZRVaTdi8h8IPoL8srCD6Ww_uCf7smm4";
    private static final String SUPABASE_REFRESH_ID = "supabase_refresh";
    private final Activity activity;
    private final WebView web;
    private final SecretStore secrets;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Map<String, HttpTransport.CancelToken> inflight = new ConcurrentHashMap<String, HttpTransport.CancelToken>();
    private final ArrayList<String> pending = new ArrayList<String>();
    private boolean flushScheduled;
    private EngineProcess engine;
    private volatile boolean destroyed;

    NativeBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
        this.secrets = new SecretStore(activity);
    }

    private String enginePath() { return activity.getApplicationInfo().nativeLibraryDir + "/libstockfish.so"; }

    private void js(final String code) {
        if (destroyed) return;
        main.post(new Runnable() { @Override public void run() { if (!destroyed) web.evaluateJavascript(code, null); } });
    }

    /* ---------------- Stockfish ---------------- */

    @JavascriptInterface
    public String engineStart() {
        synchronized (this) {
            if (engine == null) {
                engine = new EngineProcess(enginePath(), activity.getFilesDir(), new EngineProcess.Listener() {
                    @Override public void onLine(String line) { queueLine(line); }
                    @Override public void onExit(int code, String message) {
                        flushNow();
                        js("window.__cbNative&&window.__cbNative.engineExit(" + code + "," + Json.quote(message) + ")");
                    }
                });
            }
            String err = engine.start();
            String abi = Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "unknown";
            return err == null
                ? "{\"ok\":true,\"path\":" + Json.quote(enginePath()) + ",\"abi\":" + Json.quote(abi) + "}"
                : "{\"ok\":false,\"error\":" + Json.quote(err) + "}";
        }
    }

    @JavascriptInterface
    public void engineSend(String line) { EngineProcess e; synchronized (this) { e = engine; } if (e != null) e.send(line); }

    @JavascriptInterface
    public void engineStop() { EngineProcess e; synchronized (this) { e = engine; } if (e != null) e.stop(); }

    private void queueLine(String line) {
        synchronized (pending) {
            pending.add(line);
            if (pending.size() > 400) {                       // UI thread stalled: drop old progress lines, never results
                for (int i = 0; i < pending.size() && pending.size() > 200; ) {
                    String s = pending.get(i);
                    if (s.startsWith("info ") && !s.startsWith("info string")) pending.remove(i); else i++;
                }
            }
            if (!flushScheduled) { flushScheduled = true; main.postDelayed(flushTask, 30); }
        }
    }

    private final Runnable flushTask = new Runnable() { @Override public void run() { flushNow(); } };

    private void flushNow() {
        ArrayList<String> batch;
        synchronized (pending) { batch = new ArrayList<String>(pending); pending.clear(); flushScheduled = false; }
        if (batch.isEmpty()) return;
        StringBuilder sb = new StringBuilder("window.__cbNative&&window.__cbNative.engineLines([");
        for (int i = 0; i < batch.size(); i++) { if (i > 0) sb.append(','); sb.append(Json.quote(batch.get(i))); }
        sb.append("])");
        js(sb.toString());
    }

    /* ---------------- HTTP with the stored key ---------------- */

    @JavascriptInterface
    public void httpPost(final String reqId, final String keyId, final String url, final String authScheme, final String extraHeaders, final String body) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result r;
                try { r = run2(); } catch (RuntimeException e) { r = new HttpTransport.Result(0, "", "io", "Unexpected error: " + e.getClass().getSimpleName()); }
                inflight.remove(reqId);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(r.body) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
            private HttpTransport.Result run2() {
                String why = HostPolicy.check(url);
                if (why != null) return new HttpTransport.Result(0, "", "policy", why);
                String authName = null, authValue = null;
                String key = SecretStore.validId(keyId) ? secrets.get(keyId) : null;
                boolean local = url.toLowerCase().startsWith("http://");
                if (key == null && !local) return new HttpTransport.Result(0, "", "nokey", "");
                if (key != null) {
                    if ("x-api-key".equals(authScheme)) { authName = "x-api-key"; authValue = key; }
                    else if ("bearer".equals(authScheme)) { authName = "Authorization"; authValue = "Bearer " + key; }
                }
                return HttpTransport.post(url, authName, authValue, extraHeaders, body, 15000, 120000, MAX_RESPONSE_BYTES, tok);
            }
        });
    }

    /** Supabase Auth calls. Refresh tokens stay inside encrypted native storage and are never returned to JavaScript. */
    @JavascriptInterface
    public void supabaseAuth(final String reqId, final String operation, final String payload) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result r;
                try { r = runAuth(); }
                catch (RuntimeException e) { r = new HttpTransport.Result(0, "", "io", "Authentication request failed: " + e.getClass().getSimpleName()); }
                inflight.remove(reqId);
                String safeBody = redactRefreshToken(r.body);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(safeBody) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
            private HttpTransport.Result runAuth() {
                String op = operation == null ? "" : operation;
                String endpoint, body = payload == null ? "{}" : payload;
                String bearer = null;
                if ("signup".equals(op)) endpoint = "/auth/v1/signup?redirect_to=chessbuddy%3A%2F%2Fauth-callback";
                else if ("signin".equals(op)) endpoint = "/auth/v1/token?grant_type=password";
                else if ("verify".equals(op)) endpoint = "/auth/v1/verify";
                else if ("session".equals(op)) {
                    String access = jsonStringField(body, "access_token");
                    String refresh = jsonStringField(body, "refresh_token");
                    if (access == null || access.length() < 20 || refresh == null || refresh.length() < 20)
                        return new HttpTransport.Result(400, "", "policy", "The confirmation link did not contain a complete session.");
                    HttpTransport.Result userResult = HttpTransport.get(SUPABASE_URL + "/auth/v1/user", "apikey: " + SUPABASE_PUBLISHABLE_KEY + "\nAuthorization: Bearer " + access, 15000, 30000, MAX_RESPONSE_BYTES, tok);
                    if (userResult.kind.length() > 0 || userResult.status < 200 || userResult.status >= 300) return userResult;
                    if (!secrets.set(SUPABASE_REFRESH_ID, refresh)) return new HttpTransport.Result(500, "", "securestore", "Could not securely save the sign-in session on this device.");
                    return new HttpTransport.Result(200, "{\"access_token\":" + Json.quote(access) + ",\"user\":" + userResult.body + "}", "", "");
                }
                else if ("refresh".equals(op)) {
                    endpoint = "/auth/v1/token?grant_type=refresh_token";
                    String refresh = secrets.get(SUPABASE_REFRESH_ID);
                    if (refresh == null) return new HttpTransport.Result(401, "", "noauth", "No saved session. Sign in again.");
                    body = "{\"refresh_token\":" + Json.quote(refresh) + "}";
                } else if ("logout".equals(op)) {
                    endpoint = "/auth/v1/logout";
                    bearer = jsonStringField(body, "access_token");
                    body = "{}";
                    if (bearer == null || bearer.length() < 20) { secrets.clear(SUPABASE_REFRESH_ID); return new HttpTransport.Result(200, "{}", "", ""); }
                } else return new HttpTransport.Result(400, "", "policy", "Unsupported authentication action.");

                String headers = "apikey: " + SUPABASE_PUBLISHABLE_KEY;
                if (bearer != null) headers += "\nAuthorization: Bearer " + bearer;
                HttpTransport.Result result = HttpTransport.post(SUPABASE_URL + endpoint, null, null, headers, body,
                    15000, 30000, MAX_RESPONSE_BYTES, tok);
                if (result.kind.length() > 0 || result.status < 200 || result.status >= 300) {
                    if ("refresh".equals(op) && (result.status == 400 || result.status == 401)) secrets.clear(SUPABASE_REFRESH_ID);
                    return result;
                }

                if ("logout".equals(op)) {
                    secrets.clear(SUPABASE_REFRESH_ID);
                    return result;
                }
                String refresh = jsonStringField(result.body, "refresh_token");
                if (refresh != null && refresh.length() > 20) secrets.set(SUPABASE_REFRESH_ID, refresh);
                return result;
            }
        });
    }

    private static String jsonStringField(String json, String field) {
        if (json == null || field == null) return null;
        Pattern p = Pattern.compile("\"" + Pattern.quote(field) + "\"\\s*:\\s*\"([^\"]*)\"");
        Matcher m = p.matcher(json);
        return m.find() ? m.group(1) : null;
    }

    private static String redactRefreshToken(String json) {
        if (json == null || json.length() == 0) return json == null ? "" : json;
        return json.replaceAll("\"refresh_token\"\\s*:\\s*\"[^\"]*\"", "\"refresh_token\":\"[stored securely on device]\"");
    }

    /** Public GET requests. No API key or Authorization header is attached. */
    @JavascriptInterface
    public void httpGet(final String reqId, final String url, final String extraHeaders) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result r;
                try {
                    String why = HostPolicy.check(url);
                    r = why == null ? HttpTransport.get(url, extraHeaders, 10000, 15000, 1024 * 1024, tok)
                        : new HttpTransport.Result(0, "", "policy", why);
                } catch (RuntimeException e) { r = new HttpTransport.Result(0, "", "io", "Unexpected error: " + e.getClass().getSimpleName()); }
                inflight.remove(reqId);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(r.body) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
        });
    }

    @JavascriptInterface
    public void httpCancel(String reqId) { HttpTransport.CancelToken t = reqId == null ? null : inflight.get(reqId); if (t != null) t.cancel(); }

    /* ---------------- keys (never returned to JS) ---------------- */

    @JavascriptInterface public boolean hasKey(String id) { return secrets.has(id); }
    @JavascriptInterface public String keyHint(String id) { return secrets.hint(id); }
    @JavascriptInterface public boolean setKey(String id, String key) { return secrets.set(id, key); }
    @JavascriptInterface public boolean clearKey(String id) { secrets.clear(id); return true; }
    @JavascriptInterface public boolean secureStorage() { return secrets.secureStorage(); }

    /* ---------------- device helpers ---------------- */

    @JavascriptInterface
    public boolean copyText(final String text) {
        if (text == null) return false;
        main.post(new Runnable() { @Override public void run() {
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("ChessBuddy", text));
        } });
        return true;
    }

    @JavascriptInterface
    public boolean shareText(final String title, final String text) {
        if (text == null) return false;
        main.post(new Runnable() { @Override public void run() {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "ChessBuddy" : title);
            send.putExtra(Intent.EXTRA_TEXT, text);
            activity.startActivity(Intent.createChooser(send, title == null ? "Share" : title));
        } });
        return true;
    }

    @JavascriptInterface
    public void toast(final String msg) { main.post(new Runnable() { @Override public void run() { Toast.makeText(activity, msg == null ? "" : msg, Toast.LENGTH_SHORT).show(); } }); }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        main.post(new Runnable() { @Override public void run() {
            if (on) activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } });
    }

    @JavascriptInterface
    public String deviceInfo() {
        long memMb = 0;
        try {
            ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            if (am != null) { am.getMemoryInfo(mi); memMb = mi.totalMem / (1024 * 1024); }
        } catch (RuntimeException ignored) { /* keep 0 */ }
        String version = "", abi = Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "";
        long code = 0;
        try {
            PackageInfo pi = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            version = pi.versionName == null ? "" : pi.versionName;
            code = pi.versionCode;
        } catch (Exception ignored) { /* keep defaults */ }
        return "{\"cores\":" + Runtime.getRuntime().availableProcessors() + ",\"memMb\":" + memMb + ",\"abi\":" + Json.quote(abi)
            + ",\"sdk\":" + Build.VERSION.SDK_INT + ",\"version\":" + Json.quote(version) + ",\"versionCode\":" + code + "}";
    }

    void shutdown() {
        destroyed = true;
        EngineProcess e; synchronized (this) { e = engine; engine = null; }
        if (e != null) e.shutdown();
        for (HttpTransport.CancelToken t : inflight.values()) t.cancel();
        pool.shutdownNow();
    }

    File filesDir() { return activity.getFilesDir(); }
}
