package com.chessbuddy;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public final class SecretStoreTest {
    static final class MemoryPreferences implements SharedPreferences {
        final Map<String, String> values = new HashMap<>();
        public String getString(String key, String fallback) { return values.containsKey(key) ? values.get(key) : fallback; }
        public Editor edit() {
            return new Editor() {
                final Map<String, String> puts = new HashMap<>();
                final java.util.Set<String> removes = new java.util.HashSet<>();
                public Editor putString(String key, String value) { puts.put(key, value); removes.remove(key); return this; }
                public Editor remove(String key) { removes.add(key); puts.remove(key); return this; }
                public boolean commit() { removes.forEach(values::remove); values.putAll(puts); return true; }
            };
        }
    }
    static final class TestContext extends Context {
        final MemoryPreferences prefs = new MemoryPreferences();
        public SharedPreferences getSharedPreferences(String name, int mode) { return prefs; }
        public Object getSystemService(String name) { return null; }
        public android.content.pm.ApplicationInfo getApplicationInfo() { return null; }
        public File getFilesDir() { return new File("."); }
        public android.content.pm.PackageManager getPackageManager() { return null; }
        public String getPackageName() { return "com.chessbuddy.test"; }
    }
    public static void main(String[] args) {
        TestContext context = new TestContext();
        SecretStore store = new SecretStore(context);
        if (store.set("provider_key", "secret-value")) throw new AssertionError("plaintext fallback must not be used when Keystore is unavailable");
        if (context.prefs.values.containsKey("provider_key")) throw new AssertionError("failed key save must not persist any value");
        context.prefs.values.put("legacy_key", "p:legacy-secret");
        if (store.get("legacy_key") != null) throw new AssertionError("legacy plaintext must not be returned when it cannot be encrypted");
        if (context.prefs.values.containsKey("legacy_key")) throw new AssertionError("legacy plaintext must be erased when migration fails");
        if (store.secureStorage()) throw new AssertionError("test runtime should report Android Keystore unavailable");
        System.out.println("OK SecretStoreTest");
    }
}
