const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { test, done } = require('../helpers/mini-test');
const loadChess = require('../helpers/load-chessjs');
const Chess = loadChess().Chess;
const validationPromise = import('../../supabase/functions/chessbuddy-apply-move/online-validation.mjs');
const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
console.log('server-side online chess move validation');

function rowFor(game, overrides = {}) {
  return Object.assign({
    status: 'active', white_user_id: 'white', black_user_id: 'black',
    turn_user_id: game.turn() === 'w' ? 'white' : 'black', turn_color: game.turn(),
    initial_fen: START_FEN, current_fen: game.fen(), pgn: game.pgn()
  }, overrides);
}

test('replays authoritative PGN and accepts a legal move', async () => {
  const { validateAndApplyMove } = await validationPromise;
  const game = new Chess();
  const result = validateAndApplyMove({ row: rowFor(game), userId: 'white', from: 'e2', to: 'e4', Chess });
  assert.strictEqual(result.chess.fen(), 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1');
  assert.strictEqual(result.finished, false);
});

test('rejects illegal moves and the wrong player', async () => {
  const { validateAndApplyMove } = await validationPromise;
  const game = new Chess();
  assert.throws(() => validateAndApplyMove({ row: rowFor(game), userId: 'white', from: 'e2', to: 'e5', Chess }), /not legal/);
  assert.throws(() => validateAndApplyMove({ row: rowFor(game), userId: 'black', from: 'e7', to: 'e5', Chess }), /not your turn/);
});

test('rejects nonparticipants and tampered board state', async () => {
  const { validateAndApplyMove } = await validationPromise;
  const game = new Chess();
  assert.throws(() => validateAndApplyMove({ row: rowFor(game), userId: 'intruder', from: 'e2', to: 'e4', Chess }), /not a player/);
  assert.throws(() => validateAndApplyMove({ row: rowFor(game, { current_fen: '8/8/8/8/8/8/8/K6k w - - 0 1' }), userId: 'white', from: 'e2', to: 'e4', Chess }), /position changed/);
});

test('detects checkmate and derives the winner from the resulting position', async () => {
  const { validateAndApplyMove } = await validationPromise;
  const game = new Chess();
  for (const move of [{ from: 'f2', to: 'f3' }, { from: 'e7', to: 'e5' }, { from: 'g2', to: 'g4' }]) game.move(move);
  const result = validateAndApplyMove({ row: rowFor(game), userId: 'black', from: 'd8', to: 'h4', Chess });
  assert.strictEqual(result.finished, true);
  assert.strictEqual(result.result, '0-1');
  assert.strictEqual(result.winner, 'black');
  assert.match(result.chess.pgn(), /0-1/);
});

test('detects threefold repetition as a draw', async () => {
  const { validateAndApplyMove } = await validationPromise;
  const game = new Chess();
  for (const uci of ['g1f3','g8f6','f3g1','f6g8','g1f3','g8f6','f3g1','f6g8']) {
    game.move({ from: uci.slice(0,2), to: uci.slice(2,4) });
  }
  const result = validateAndApplyMove({ row: rowFor(game), userId: 'white', from: 'g1', to: 'f3', Chess });
  assert.strictEqual(result.finished, true);
  assert.strictEqual(result.result, '1/2-1/2');
  assert.strictEqual(result.winner, null);
});

test('Edge Function verifies bearer syntax and caps the incoming request body', () => {
  const edge = fs.readFileSync(path.join(__dirname, '../../supabase/functions/chessbuddy-apply-move/index.ts'), 'utf8');
  assert.ok(edge.includes('/^Bearer\\s+\\S+$/i.test(authorization)'));
  assert.ok(edge.includes('new TextEncoder().encode(raw).byteLength > 4096'));
  assert.ok(edge.includes('apiKey !== PUBLISHABLE_KEY'));
  assert.ok(edge.includes('p_expected_pgn: row.pgn ??'));
});

test('database migration requires the server role, locks rows, and checks both previous FEN and PGN', () => {
  const sql = fs.readFileSync(path.join(__dirname, '../../supabase/migrations/20261116193538_server_validated_online_moves_v2.sql'), 'utf8');
  assert.match(sql, /request\.jwt\.claims[\s\S]*service_role/);
  assert.match(sql, /for update/i);
  assert.match(sql, /g\.current_fen\s*<>\s*p_expected_fen/i);
  assert.match(sql, /g\.pgn\s+is distinct from\s+p_expected_pgn/i);
  assert.match(sql, /grant execute on function public\.cb_apply_move_server_v2[\s\S]*to service_role/i);
});

done('online server validation');
