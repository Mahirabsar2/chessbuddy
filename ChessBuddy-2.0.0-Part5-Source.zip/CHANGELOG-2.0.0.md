# ChessBuddy 2.0.0

- Reworked the home/lobby visual hierarchy and navigation presentation.
- Local-first startup: open the playable lobby immediately instead of opening sign-in during boot.
- Replaced the reused portrait sheet with 171 distinct, deterministic original SVG bot portraits; the same vector art is used in selection, preview, profile and game UI.
- Added more character variety to the original portrait renderer: face shapes, hair types, facial hair, eyes, expressions, clothing and accessories. Engine-bot portraits now also vary robot head geometry, visor/eye treatment, mouth display and antenna design instead of repeating one robot silhouette.
- Preserved Android system TextToSpeech for coach comments and optional bot move narration, with per-profile pitch/rate variation and browser speech fallback. Added a voice test control in Settings and a speaker preview on each selected bot profile; speech engine readiness is reported by the Android bridge.
- Included pinned ARM64 Stockfish/Lc0/Rust runtime dependencies and their provenance/license notices in the source package; no APK is included.
- Added rebuild smoke assertions for local-first startup, TTS bridge presence, bot identity/rating metadata and unique SVG portrait output.
- Updated Android version name to 2.0.0.

This remains a rebuild candidate, not a final verified release. See `docs/2.0.0_IMPLEMENTATION_STATUS.md` for explicit test results and outstanding Android/device/backend gates.
