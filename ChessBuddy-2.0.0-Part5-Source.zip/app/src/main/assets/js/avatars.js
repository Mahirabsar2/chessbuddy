/*
 * ChessBuddy original bot portrait system.
 * All artwork is hand-authored SVG assembled from deterministic character specs.
 * No generated images, third-party avatar packs, or Chess.com artwork are used.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBAvatars = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  var SKIN = { fair: '#f4d6bb', light: '#ecc19c', tan: '#d8a470', brown: '#b07845', dark: '#80532f', deep: '#5c3a22' };
  var DEFAULTS = {
    bg: '#466d89', skin: SKIN.light, hair: '#2b1d14', style: 'short', fh: 'none',
    glasses: false, suit: '#2f3a4a', shirt: '#f4f4f2', tie: null, brow: null,
    accent: '#e5bd55', expression: 'smile', eyes: 'round', accessory: 'none',
    face: 'oval', eyeColor: '#241b18', freckles: false
  };

  function hairBack(style, hair) {
    var paths = {
      long: '<path d="M33 47 C24 20 36 9 65 10 C94 11 103 26 95 61 L99 119 L29 119 L31 75Z" fill="' + hair + '"/>',
      ponytail: '<path d="M89 35 C112 38 109 78 94 90 L86 69Z" fill="' + hair + '"/><path d="M32 45 C25 19 39 10 64 10 C91 10 101 29 94 54 L89 69 L34 69Z" fill="' + hair + '"/>',
      braids: '<path d="M32 43 C24 19 39 10 64 10 C91 10 102 30 94 56 L91 91 L82 91 L88 54 L40 54 L45 91 L36 91Z" fill="' + hair + '"/><path d="M35 59 Q22 75 31 105 M92 58 Q105 76 96 106" fill="none" stroke="' + hair + '" stroke-width="10" stroke-linecap="round"/>',
      bob: '<path d="M31 45 C25 18 39 10 64 10 C91 10 101 29 94 55 L93 84 Q83 95 80 68 L47 68 Q45 94 35 84Z" fill="' + hair + '"/>',
      hood: '<path d="M18 91 C13 35 28 4 64 4 C101 4 115 35 110 91 L94 82 L85 38 L43 38 L34 82Z" fill="' + hair + '"/>',
      curly: '<g fill="' + hair + '"><circle cx="36" cy="29" r="16"/><circle cx="49" cy="17" r="16"/><circle cx="66" cy="14" r="17"/><circle cx="82" cy="20" r="16"/><circle cx="94" cy="34" r="14"/><circle cx="31" cy="46" r="13"/><circle cx="97" cy="49" r="12"/></g>',
      afro: '<path d="M28 65 C15 55 19 27 36 19 C43 5 75 4 86 18 C106 28 110 55 99 68 L91 48 L37 48Z" fill="' + hair + '"/>',
      bun: '<circle cx="64" cy="12" r="14" fill="' + hair + '"/><path d="M32 46 C25 19 39 10 64 10 C91 10 101 29 94 55 L87 72 L40 72Z" fill="' + hair + '"/>',
      wavy: '<path d="M31 47 C24 20 37 10 64 10 C91 10 101 28 94 51 C100 64 89 68 91 80 L80 77 L82 57 L43 57 L44 81 L32 78 C34 67 24 62 31 47Z" fill="' + hair + '"/>',
      spiky: '<path d="M29 47 L20 27 L39 34 L35 12 L54 28 L64 6 L75 28 L94 13 L89 36 L107 29 L95 55 L37 58Z" fill="' + hair + '"/>',
      mohawk: '<path d="M47 34 C42 17 49 2 64 2 C79 2 86 17 81 34 L77 50 L51 50Z" fill="' + hair + '"/><path d="M29 43 Q23 35 31 24 M99 43 Q105 35 97 24" stroke="' + hair + '" stroke-width="7" fill="none"/>',
      undercut: '<path d="M29 47 C25 18 39 10 64 10 C91 10 101 29 94 53 L85 39 Q64 30 43 41 L38 58Z" fill="' + hair + '"/>',
      slick: '<path d="M30 45 C24 20 39 10 66 10 C92 10 100 28 94 52 C81 37 59 33 39 48Z" fill="' + hair + '"/><path d="M38 23 Q61 8 84 26" stroke="#fff" stroke-opacity=".17" stroke-width="4" fill="none"/>',
      side: '<path d="M29 47 C23 19 39 9 65 10 C92 10 101 29 94 53 C83 36 61 33 42 46 L37 57Z" fill="' + hair + '"/><path d="M34 27 Q48 8 77 18" stroke="#fff" stroke-opacity=".15" stroke-width="3" fill="none"/>',
      receding: '<path d="M29 48 C27 25 36 14 51 13 C43 22 44 33 45 40 C60 29 78 29 84 40 C84 27 82 20 77 13 C94 18 101 32 94 51Z" fill="' + hair + '"/>',
      bald: '<path d="M29 42 Q31 22 43 20 M99 42 Q97 22 85 20" stroke="' + hair + '" stroke-width="5" fill="none" stroke-linecap="round"/>'
    };
    return paths[style] || paths.short || '';
  }

  function hairFront(style, hair) {
    var shapes = {
      short: '<path d="M32 48 C26 27 40 17 64 17 C86 17 98 29 94 49 Q84 35 64 37 Q43 35 32 48Z" fill="' + hair + '"/>',
      side: '<path d="M30 49 C24 26 40 15 66 17 C88 18 99 30 94 48 Q73 30 50 39 Q39 44 30 49Z" fill="' + hair + '"/>',
      slick: '<path d="M30 47 C25 24 41 15 66 17 C89 18 99 30 94 47 Q76 34 49 38 Q37 41 30 47Z" fill="' + hair + '"/>',
      bob: '<path d="M31 50 C25 25 40 16 64 16 C89 16 99 31 93 54 Q83 40 65 39 Q44 38 31 50Z" fill="' + hair + '"/>',
      long: '<path d="M31 49 C25 25 40 15 64 16 C90 17 99 30 94 49 Q83 34 63 35 Q42 36 31 49Z" fill="' + hair + '"/>',
      wavy: '<path d="M30 48 Q23 28 39 20 Q48 13 57 18 Q67 10 80 20 Q99 25 94 49 Q83 34 72 39 Q57 31 48 42 Q38 39 30 48Z" fill="' + hair + '"/>',
      curly: '<g fill="' + hair + '"><circle cx="37" cy="32" r="11"/><circle cx="49" cy="22" r="12"/><circle cx="64" cy="19" r="13"/><circle cx="79" cy="24" r="12"/><circle cx="91" cy="35" r="10"/></g>',
      afro: '<path d="M25 55 C17 38 25 18 43 15 C55 3 80 10 87 20 C102 27 105 45 97 57 Q80 39 64 40 Q43 39 25 55Z" fill="' + hair + '"/>',
      spiky: '<path d="M29 49 L25 30 L42 36 L41 17 L56 32 L66 13 L76 32 L93 17 L89 38 L101 33 L94 52Z" fill="' + hair + '"/>',
      mohawk: '<path d="M46 43 Q40 24 51 11 Q64 -1 77 12 Q88 25 82 43Z" fill="' + hair + '"/>',
      undercut: '<path d="M30 48 Q24 26 42 18 Q64 7 84 19 Q100 30 94 48 Q76 31 52 38Z" fill="' + hair + '"/>',
      receding: '<path d="M31 45 Q29 23 45 19 Q41 28 45 39 Q62 27 83 39 Q85 27 80 19 Q97 25 94 47 Q73 34 51 39Z" fill="' + hair + '"/>',
      bald: ''
    };
    return shapes[style] || shapes.short;
  }

  function facialHair(kind, hair) {
    if (kind === 'mustache') return '<path d="M47 81 Q54 74 63 80 Q71 74 81 81 Q77 91 64 86 Q51 91 47 81Z" fill="' + hair + '"/>';
    if (kind === 'beard') return '<path d="M37 72 Q39 101 64 108 Q89 101 91 72 Q84 85 64 84 Q44 85 37 72Z" fill="' + hair + '"/><path d="M48 89 Q64 98 80 89" stroke="#fff" stroke-opacity=".12" stroke-width="3" fill="none"/>';
    if (kind === 'goatee') return '<path d="M55 84 Q64 93 73 84 Q73 101 64 104 Q55 101 55 84Z" fill="' + hair + '"/><path d="M48 80 Q55 76 60 81 M68 81 Q75 76 80 80" stroke="' + hair + '" stroke-width="4" stroke-linecap="round"/>';
    if (kind === 'stubble') return '<path d="M39 73 Q42 96 64 100 Q86 96 89 73 Q84 91 64 92 Q44 91 39 73Z" fill="' + hair + '" opacity=".22"/>';
    return '';
  }

  function robot(s) {
    var accent = s.accent || '#81b64c', uid = 'cbRobot' + hash(JSON.stringify(s)).toString(36);
    var style = Number(s.robotStyle || 0) % 4, eyes = Number(s.robotEyes || 0) % 4;
    var mouth = Number(s.robotMouth || 0) % 4, antenna = Number(s.robotAntenna || 0) % 3;
    var head = style === 1
      ? '<path d="M31 25 L96 25 L108 43 L104 89 Q101 99 90 99 H38 Q26 99 23 88 L20 43Z" fill="url(#' + uid + '-metal)" stroke="#eaf1f6" stroke-width="2"/>'
      : style === 2
        ? '<ellipse cx="64" cy="62" rx="48" ry="39" fill="url(#' + uid + '-metal)" stroke="#eaf1f6" stroke-width="2"/>'
        : style === 3
          ? '<path d="M37 22 Q64 12 91 22 L105 48 L96 96 H32 L23 48Z" fill="url(#' + uid + '-metal)" stroke="#eaf1f6" stroke-width="2"/>'
          : '<rect x="19" y="27" width="90" height="69" rx="23" fill="url(#' + uid + '-metal)" stroke="#eaf1f6" stroke-width="2"/>';
    var visor = style === 1
      ? '<path d="M31 48 L43 39 H85 L97 48 L93 75 H35Z" fill="url(#' + uid + '-visor)" stroke="#536a7d" stroke-width="2"/>'
      : style === 2
        ? '<rect x="27" y="47" width="74" height="30" rx="15" fill="url(#' + uid + '-visor)" stroke="#536a7d" stroke-width="2"/>'
        : style === 3
          ? '<path d="M32 45 Q64 34 96 45 L91 77 H37Z" fill="url(#' + uid + '-visor)" stroke="#536a7d" stroke-width="2"/>'
          : '<rect x="28" y="45" width="72" height="31" rx="14" fill="url(#' + uid + '-visor)" stroke="#536a7d" stroke-width="2"/>';
    var eyeShapes = [
      '<ellipse cx="47" cy="60" rx="7" ry="8" fill="' + accent + '"/><ellipse cx="81" cy="60" rx="7" ry="8" fill="' + accent + '"/><circle cx="45" cy="57" r="2" fill="#fff"/><circle cx="79" cy="57" r="2" fill="#fff"/>',
      '<path d="M39 57 Q47 49 56 57 L54 66 Q47 72 40 66Z M72 57 Q81 49 89 57 L88 66 Q81 72 74 66Z" fill="' + accent + '"/><path d="M42 56 L51 56 M76 56 L85 56" stroke="#fff" stroke-width="2" stroke-linecap="round"/>',
      '<rect x="39" y="53" width="16" height="14" rx="4" fill="' + accent + '"/><rect x="73" y="53" width="16" height="14" rx="4" fill="' + accent + '"/><circle cx="44" cy="57" r="2" fill="#fff"/><circle cx="78" cy="57" r="2" fill="#fff"/>',
      '<circle cx="48" cy="60" r="9" fill="none" stroke="' + accent + '" stroke-width="4"/><circle cx="80" cy="60" r="9" fill="none" stroke="' + accent + '" stroke-width="4"/><circle cx="48" cy="60" r="2.5" fill="#fff"/><circle cx="80" cy="60" r="2.5" fill="#fff"/>'
    ];
    var mouthShapes = [
      '<path d="M52 84 Q64 91 76 84" stroke="' + accent + '" stroke-width="3.5" fill="none" stroke-linecap="round"/>',
      '<rect x="53" y="82" width="22" height="5" rx="2.5" fill="' + accent + '"/>',
      '<path d="M53 81 H75 M53 85 H75 M53 89 H75" stroke="' + accent + '" stroke-width="2" stroke-linecap="round"/>',
      '<circle cx="64" cy="85" r="4" fill="' + accent + '"/><circle cx="64" cy="85" r="1.5" fill="#fff"/>'
    ];
    var antennaShape = antenna === 1
      ? '<path d="M64 21 V11" stroke="#dbe5ee" stroke-width="3"/><path d="M64 4 L71 11 L64 18 L57 11Z" fill="' + accent + '" stroke="#fff" stroke-opacity=".6" stroke-width="1.2"/>'
      : antenna === 2
        ? '<path d="M64 22 V9" stroke="#dbe5ee" stroke-width="3"/><rect x="57" y="2" width="14" height="10" rx="3" fill="' + accent + '" stroke="#fff" stroke-opacity=".55" stroke-width="1.2"/>'
        : '<path d="M64 22 V9" stroke="#dbe5ee" stroke-width="3"/><circle cx="64" cy="7" r="6" fill="' + accent + '" stroke="#fff" stroke-opacity=".55" stroke-width="1.5"/>';
    var fins = style === 1
      ? '<path d="M21 48 L9 39 L14 71 L24 76Z M107 48 L119 39 L114 71 L104 76Z" fill="#8797a6" stroke="#dbe3ea" stroke-width="1.5"/>'
      : style === 3
        ? '<path d="M26 40 L12 30 L18 62 L28 67Z M102 40 L116 30 L110 62 L100 67Z" fill="#8797a6" stroke="#dbe3ea" stroke-width="1.5"/>'
        : '<rect x="10" y="51" width="10" height="25" rx="5" fill="#8f9eac"/><rect x="108" y="51" width="10" height="25" rx="5" fill="#8f9eac"/>';
    var chest = style === 2
      ? '<path d="M64 100 L77 111 L64 123 L51 111Z" fill="' + accent + '" stroke="#dbe3ea" stroke-opacity=".7" stroke-width="1.5"/>'
      : style === 3
        ? '<circle cx="64" cy="111" r="7" fill="' + accent + '" stroke="#dbe3ea" stroke-width="1.5"/><path d="M64 104 V118 M57 111 H71" stroke="#203141" stroke-width="1.5"/>'
        : '<path d="M64 101 L75 111 L64 123 L53 111Z" fill="' + accent + '" stroke="#dbe3ea" stroke-opacity=".7" stroke-width="1.5"/>';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" aria-hidden="true">' +
      '<defs><linearGradient id="' + uid + '-rbg" x2="1" y2="1"><stop stop-color="' + s.bg + '"/><stop offset="1" stop-color="#101d2a"/></linearGradient><linearGradient id="' + uid + '-metal" x2=".8" y2="1"><stop stop-color="#f4f7fa"/><stop offset=".48" stop-color="#aeb9c4"/><stop offset="1" stop-color="#536170"/></linearGradient><linearGradient id="' + uid + '-visor" x2="0" y2="1"><stop stop-color="#172e43"/><stop offset="1" stop-color="#07111b"/></linearGradient><linearGradient id="' + uid + '-body" x2="0" y2="1"><stop stop-color="#455e73"/><stop offset="1" stop-color="#1b2a38"/></linearGradient></defs>' +
      '<rect width="128" height="128" fill="url(#' + uid + '-rbg)"/><circle cx="64" cy="49" r="53" fill="#fff" opacity=".06"/><path d="M8 128 Q13 94 43 91 H85 Q115 94 120 128Z" fill="url(#' + uid + '-body)" stroke="#8d9cab" stroke-width="2"/>' +
      '<path d="M50 94 L64 111 L78 94" fill="#dbe3ea"/><path d="M64 91 V103" stroke="#72869a" stroke-width="3"/>' + antennaShape + fins + head +
      '<path d="M27 42 Q64 19 101 42" fill="none" stroke="#fff" stroke-opacity=".52" stroke-width="4"/>' + visor + eyeShapes[eyes] + mouthShapes[mouth] +
      '<path d="M31 31 Q64 18 97 31" fill="none" stroke="#fff" stroke-opacity=".18" stroke-width="2"/>' + chest +
      '<rect x="1" y="1" width="126" height="126" rx="15" fill="none" stroke="#fff" stroke-opacity=".19" stroke-width="1.6"/></svg>';
  }

  function svg(spec) {
    var s = {}, k;
    for (k in DEFAULTS) s[k] = DEFAULTS[k];
    for (k in (spec || {})) if (spec[k] !== undefined) s[k] = spec[k];
    if (s.animal === 'robot') return robot(s);

    var hair = s.hair, brow = s.brow || hair, facePath = s.face === 'square'
      ? 'M39 42 Q39 25 64 24 Q89 25 89 42 L91 75 Q86 101 64 104 Q42 101 37 75Z'
      : s.face === 'round'
        ? 'M36 48 Q35 23 64 23 Q93 23 92 48 L89 78 Q83 100 64 101 Q45 100 39 78Z'
        : 'M36 45 Q37 22 64 22 Q91 22 92 45 L89 77 Q82 101 64 105 Q46 101 39 77Z';
    var uid = 'cbAvatar' + hash(JSON.stringify(s)).toString(36), p = [];
    p.push('<defs>' +
      '<linearGradient id="' + uid + '-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + s.bg + '"/><stop offset="1" stop-color="#152333"/></linearGradient>' +
      '<linearGradient id="' + uid + '-coat" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + s.suit + '"/><stop offset="1" stop-color="#111923"/></linearGradient>' +
      '<linearGradient id="' + uid + '-skin" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + s.skin + '"/><stop offset=".72" stop-color="' + s.skin + '"/><stop offset="1" stop-color="#74472f" stop-opacity=".38"/></linearGradient>' +
      '<linearGradient id="' + uid + '-hair" x1="0" y1="0" x2=".8" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity=".15"/><stop offset=".28" stop-color="' + hair + '"/><stop offset="1" stop-color="#080d14" stop-opacity=".48"/></linearGradient>' +
      '<clipPath id="' + uid + '-faceClip"><path d="' + facePath + '"/></clipPath></defs>');
    p.push('<rect width="128" height="128" fill="url(#' + uid + '-bg)"/><circle cx="65" cy="43" r="57" fill="#fff" opacity=".055"/><path d="M-4 104 Q39 71 76 99 T133 91" stroke="#fff" stroke-opacity=".075" stroke-width="8" fill="none"/><path d="M12 13 L30 4 L2 49Z" fill="#fff" opacity=".05"/><path d="M96 0 L128 0 L128 29Z" fill="#fff" opacity=".045"/>');

    if (s.animal === 'cat') {
      p.push('<path d="M38 49 L31 14 L57 32 L72 32 L97 14 L90 52Z" fill="url(#' + uid + '-skin)" stroke="#4c332a" stroke-width="2"/><path d="M39 39 L36 22 L51 34Z M89 39 L92 22 L77 34Z" fill="#e7a2aa"/>');
      p.push('<path d="M18 128 Q21 98 47 91 H81 Q107 98 110 128Z" fill="url(#' + uid + '-coat)"/>');
      p.push('<ellipse cx="64" cy="65" rx="35" ry="34" fill="url(#' + uid + '-skin)" stroke="#4b352b" stroke-width="1.6"/>');
      p.push('<path d="M46 67 Q54 58 61 67 M67 67 Q75 58 83 67" stroke="#251e1c" stroke-width="3" fill="none" stroke-linecap="round"/><ellipse cx="53" cy="67" rx="4" ry="5" fill="#6e9b70"/><ellipse cx="76" cy="67" rx="4" ry="5" fill="#6e9b70"/><path d="M60 81 Q64 76 68 81 L64 86Z" fill="#d98798"/><path d="M64 86 Q57 95 51 87 M64 86 Q71 95 77 87" stroke="#633c3c" stroke-width="2" fill="none" stroke-linecap="round"/>');
      p.push('<path d="M55 56 Q64 51 73 56" stroke="' + hair + '" stroke-width="3" fill="none"/><path d="M48 88 L20 84 M48 93 L19 98 M80 88 L108 84 M80 93 L109 98" stroke="#fff" stroke-opacity=".85" stroke-width="1.5"/>');
    } else {
      p.push(hairBack(s.style, 'url(#' + uid + '-hair)'));
      p.push('<path d="M10 128 Q14 96 43 91 H85 Q114 96 118 128Z" fill="url(#' + uid + '-coat)"/><path d="M20 110 Q38 95 51 101 L64 128 H14Z" fill="#fff" opacity=".055"/><path d="M108 110 Q91 96 77 101 L64 128 H114Z" fill="#000" opacity=".13"/>');
      p.push('<path d="M51 84 H77 L81 103 Q64 114 47 103Z" fill="url(#' + uid + '-skin)"/><path d="M55 92 L64 107 L73 92" fill="' + s.shirt + '"/><path d="M47 96 L64 111 L58 128 L32 106Z" fill="#fff" opacity=".11"/><path d="M81 96 L64 111 L70 128 L96 106Z" fill="#000" opacity=".12"/>');
      if (s.tie) p.push('<path d="M60 105 L68 105 L72 125 L64 130 L56 125Z" fill="' + s.tie + '"/><path d="M60 105 L64 110 L68 105" fill="#fff" opacity=".25"/>');
      p.push('<path d="M35 47 Q30 38 26 52 Q25 72 39 77Z M93 47 Q98 38 102 52 Q103 72 89 77Z" fill="url(#' + uid + '-skin)" stroke="#6d4938" stroke-opacity=".34" stroke-width="1.2"/>');
      p.push('<path d="' + facePath + '" fill="url(#' + uid + '-skin)" stroke="#593d32" stroke-opacity=".22" stroke-width="1.5"/>');
      p.push('<g clip-path="url(#' + uid + '-faceClip)"><ellipse cx="46" cy="79" rx="8" ry="4" fill="#e67c79" opacity=".16"/><ellipse cx="82" cy="79" rx="8" ry="4" fill="#e67c79" opacity=".16"/><path d="M34 91 Q64 112 94 91 L94 111 L34 111Z" fill="#6d4137" opacity=".06"/></g>');
      p.push(hairFront(s.style, 'url(#' + uid + '-hair)'));
      if (s.style === 'bun') p.push('<circle cx="64" cy="13" r="13" fill="url(#' + uid + '-hair)" stroke="#080d14" stroke-opacity=".25"/>');
      if (s.style === 'ponytail') p.push('<path d="M90 30 Q111 31 107 63 Q106 78 96 87" fill="none" stroke="' + hair + '" stroke-width="11" stroke-linecap="round"/><path d="M94 44 Q103 54 99 69" stroke="#fff" stroke-opacity=".13" stroke-width="2" fill="none"/>');
      var browPath = s.expression === 'focused' ? 'M45 61 Q53 55 60 59 M68 59 Q76 55 84 61' : s.expression === 'sleepy' ? 'M45 59 Q53 62 60 60 M68 60 Q76 62 84 59' : s.expression === 'surprised' ? 'M45 56 Q53 51 60 56 M68 56 Q76 51 84 56' : 'M45 60 Q53 55 60 59 M68 59 Q76 55 84 60';
      p.push('<path d="' + browPath + '" stroke="' + brow + '" stroke-width="3.4" fill="none" stroke-linecap="round"/>');
      var eyeY = s.eyes === 'sleepy' ? 68 : 66, eyeH = s.eyes === 'wide' ? 7 : s.eyes === 'sleepy' ? 3 : 5;
      p.push('<ellipse cx="53" cy="' + eyeY + '" rx="6.5" ry="' + eyeH + '" fill="#fff7ed"/><ellipse cx="76" cy="' + eyeY + '" rx="6.5" ry="' + eyeH + '" fill="#fff7ed"/><ellipse cx="54" cy="' + eyeY + '" rx="3.3" ry="' + Math.max(2.3, eyeH - 1) + '" fill="' + (s.eyeColor || '#241b18') + '"/><ellipse cx="77" cy="' + eyeY + '" rx="3.3" ry="' + Math.max(2.3, eyeH - 1) + '" fill="' + (s.eyeColor || '#241b18') + '"/><circle cx="55" cy="' + (eyeY - 2) + '" r="1.5" fill="#fff"/><circle cx="78" cy="' + (eyeY - 2) + '" r="1.5" fill="#fff"/>');
      p.push('<path d="M64 69 Q60 79 64 81 Q67 83 69 80" stroke="#8b5d48" stroke-opacity=".6" stroke-width="1.8" fill="none" stroke-linecap="round"/>');
      var mouth = s.expression === 'neutral' ? 'M55 91 Q64 91 73 91' : s.expression === 'smirk' ? 'M55 90 Q67 96 74 88' : s.expression === 'grin' ? 'M53 88 Q64 102 76 88 L73 96 Q64 102 56 95Z' : s.expression === 'surprised' ? 'M60 88 Q64 84 68 88 Q70 98 64 99 Q58 98 60 88Z' : 'M55 89 Q64 97 73 89';
      p.push('<path d="' + mouth + '" fill="' + (s.expression === 'grin' || s.expression === 'surprised' ? '#8e454b' : 'none') + '" stroke="#713b39" stroke-width="2" stroke-linecap="round"/>');
      p.push(facialHair(s.fh, hair));
      if (s.freckles) p.push('<g fill="#915a47" opacity=".62"><circle cx="45" cy="81" r="1.2"/><circle cx="50" cy="84" r="1"/><circle cx="55" cy="82" r="1"/><circle cx="73" cy="82" r="1"/><circle cx="78" cy="84" r="1"/><circle cx="83" cy="81" r="1.2"/></g>');
      if (s.glasses) p.push('<g fill="none" stroke="#252b32" stroke-width="2.8"><rect x="42" y="58" width="22" height="17" rx="6"/><rect x="67" y="58" width="22" height="17" rx="6"/><path d="M64 65 Q65 63 67 65 M42 64 L37 62 M89 64 L94 62"/></g><path d="M46 60 L52 59" stroke="#fff" stroke-opacity=".5" stroke-width="1.3"/>');
      if (s.accessory === 'headset') p.push('<path d="M34 67 Q30 25 64 24 Q98 25 94 67" fill="none" stroke="#252b35" stroke-width="5"/><rect x="29" y="61" width="9" height="19" rx="4" fill="' + s.accent + '"/><rect x="90" y="61" width="9" height="19" rx="4" fill="' + s.accent + '"/>');
      if (s.accessory === 'headband') p.push('<path d="M33 49 Q64 30 95 49" stroke="' + s.accent + '" stroke-width="6" fill="none"/><path d="M38 46 Q64 32 90 46" stroke="#fff" stroke-opacity=".28" stroke-width="1.4" fill="none"/>');
      if (s.accessory === 'earring') p.push('<circle cx="35" cy="79" r="2.7" fill="' + s.accent + '" stroke="#fff" stroke-opacity=".4"/><circle cx="93" cy="79" r="2.7" fill="' + s.accent + '" stroke="#fff" stroke-opacity=".4"/>');
      if (s.accessory === 'crown') p.push('<path d="M35 34 L31 17 L47 26 L64 8 L81 26 L97 17 L93 36Z" fill="' + s.accent + '" stroke="#61451d" stroke-width="2"/><circle cx="64" cy="17" r="3" fill="#f4f6ff"/><path d="M38 35 H90" stroke="#f8d98a" stroke-width="3"/>');
      if (s.accessory === 'cap') p.push('<path d="M33 36 Q37 13 64 15 Q91 13 95 36 L94 42 Q65 35 34 43Z" fill="' + s.accent + '" stroke="#1c2935" stroke-width="1.4"/><path d="M34 40 Q62 34 103 47 Q83 56 38 47Z" fill="#192a39"/>');
      if (s.accessory === 'bow') p.push('<path d="M46 27 Q27 10 29 28 Q29 43 52 34 L64 29 L76 34 Q99 43 99 28 Q101 10 82 27 L64 29Z" fill="' + s.accent + '"/><circle cx="64" cy="30" r="5" fill="#fff" opacity=".6"/>');
      if (s.accessory === 'laurel') p.push('<path d="M31 51 Q18 26 42 23 M97 51 Q110 26 86 23" fill="none" stroke="' + s.accent + '" stroke-width="4" stroke-linecap="round"/><path d="M29 42 L20 35 M33 32 L29 23 M99 42 L108 35 M95 32 L99 23" stroke="' + s.accent + '" stroke-width="3" stroke-linecap="round"/>');
    }
    p.push('<rect x="1" y="1" width="126" height="126" rx="15" fill="none" stroke="#fff" stroke-opacity=".22" stroke-width="2"/><path d="M8 8 H35" stroke="#fff" stroke-opacity=".18" stroke-width="2" stroke-linecap="round"/>');
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" aria-hidden="true">' + p.join('') + '</svg>';
  }

  var ACCENTS = ['#e9c46a', '#f08a72', '#79c7be', '#a7a0e8', '#e7a2c2', '#8fc17b', '#85b7e6', '#f1ad57', '#d9e0ed'];
  var EXPRESSIONS = ['smile', 'grin', 'smirk', 'focused', 'sleepy', 'neutral', 'surprised'];
  var EYES = ['round', 'wide', 'sleepy'];
  var ACCESSORIES = ['none', 'none', 'none', 'none', 'none', 'none', 'none', 'none', 'none', 'none', 'headband', 'headset', 'earring', 'crown', 'cap', 'bow', 'laurel'];
  var FACES = ['oval', 'round', 'square'];
  var HAIR = ['short', 'side', 'slick', 'curly', 'bun', 'long', 'bob', 'receding', 'bald', 'wavy', 'spiky', 'mohawk', 'afro', 'ponytail', 'braids', 'undercut'];
  function hash(value) {
    var h = 2166136261, s = String(value || '');
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function forBot(bot) {
    var spec = {}, src = (bot && bot.av) || {}, k;
    for (k in src) spec[k] = src[k];
    var h = hash(bot && (bot.id || bot.botId));
    if (!spec.style) spec.style = HAIR[h % HAIR.length];
    spec.accent = spec.accent || ACCENTS[h % ACCENTS.length];
    spec.expression = spec.expression || EXPRESSIONS[(h >>> 4) % EXPRESSIONS.length];
    spec.eyes = spec.eyes || EYES[(h >>> 8) % EYES.length];
    var generated = /^(nc|bg|im|ad|ms|ap)\d+/.test(String(bot && bot.id || '')) || /^(athletes|musicians|creators|personalities|vis|maia)/.test(String(bot && bot.id || ''));
    spec.accessory = spec.accessory || (generated ? ACCESSORIES[(h >>> 12) % ACCESSORIES.length] : 'none');
    spec.face = spec.face || FACES[(h >>> 16) % FACES.length];
    spec.freckles = spec.freckles === undefined ? ((h >>> 20) % 5) === 0 : spec.freckles;
    spec.eyeColor = spec.eyeColor || (((h >>> 23) % 4) === 0 ? '#395b73' : ((h >>> 25) % 5) === 0 ? '#47745b' : '#241b18');
    if (spec.animal === 'robot') {
      spec.robotStyle = (h >>> 3) % 4;
      spec.robotEyes = (h >>> 7) % 4;
      spec.robotMouth = (h >>> 11) % 4;
      spec.robotAntenna = (h >>> 15) % 3;
    }
    return spec;
  }
  return { svg: svg, forBot: forBot, SKIN: SKIN };
});
