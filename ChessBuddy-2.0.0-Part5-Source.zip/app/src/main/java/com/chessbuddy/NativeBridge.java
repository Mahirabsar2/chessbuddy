package com.chessbuddy;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.util.Base64;
import android.widget.Toast;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** The only door between the web UI and the device: Stockfish process, HTTP with the stored API key, clipboard, share, toast. */
final class NativeBridge {
    private static final int MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
    // Public client key only. Privileged Supabase keys must never ship in this APK.
    private static final String SUPABASE_URL = "https://npicptuurxuqxepxzumi.supabase.co";
    private static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_ZRVaTdi8h8IPoL8srCD6Ww_uCf7smm4";
    private static final String SUPABASE_REFRESH_ID = "supabase_refresh";
    private static final String SUPABASE_PKCE_VERIFIER_ID = "supabase_pkce_verifier";
    private final Activity activity;
    private final WebView web;
    private final SecretStore secrets;
    private final DiagnosticsLog diagnostics;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private TextToSpeech textToSpeech;
    private volatile boolean textToSpeechReady;
    private final Map<String, HttpTransport.CancelToken> inflight = new ConcurrentHashMap<String, HttpTransport.CancelToken>();
    private final Map<String, AtomicBoolean> modelCancel = new ConcurrentHashMap<String, AtomicBoolean>();
    private final Map<String, HttpURLConnection> modelConnections = new ConcurrentHashMap<String, HttpURLConnection>();
    private final ArrayList<String> pending = new ArrayList<String>();
    private boolean flushScheduled;
    private EngineProcess engine;
    private String engineKey = "stockfish|";
    private volatile boolean destroyed;

    NativeBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
        this.secrets = new SecretStore(activity);
        this.diagnostics = new DiagnosticsLog(activity);
        this.diagnostics.log("INFO", "app.bridge_ready", "Native bridge initialized");
        this.diagnostics.log("INFO", "storage.secure", "Android Keystore available=" + this.secrets.secureStorage());
        this.textToSpeech = new TextToSpeech(activity.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
                    int language = textToSpeech.setLanguage(Locale.getDefault());
                    if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                        language = textToSpeech.setLanguage(Locale.ENGLISH);
                    }
                    textToSpeechReady = language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED;
                    diagnostics.log(textToSpeechReady ? "INFO" : "WARN", "voice.tts_ready", "Android system speech engine ready=" + textToSpeechReady);
                } else {
                    textToSpeechReady = false;
                    diagnostics.log("WARN", "voice.tts_unavailable", "Android system speech engine unavailable");
                }
            }
        });
    }

    private String enginePath() { return activity.getApplicationInfo().nativeLibraryDir + "/libstockfish.so"; }
    private String lc0Path() { return activity.getApplicationInfo().nativeLibraryDir + "/liblc0.so"; }

    private void js(final String code) {
        if (destroyed) return;
        main.post(new Runnable() { @Override public void run() { if (!destroyed) web.evaluateJavascript(code, null); } });
    }

    /* ---------------- Stockfish ---------------- */

    @JavascriptInterface
    public String engineStart() { return engineStart("stockfish", ""); }

    /** Starts the selected UCI provider. Maia models are downloaded into app-private storage first. */
    @JavascriptInterface
    public String engineStart(String provider, String modelId) {
        synchronized (this) {
            String selected = provider == null ? "stockfish" : provider.toLowerCase();
            String selectedModel = modelId == null ? "" : modelId;
            String path = enginePath();
            String name = "Stockfish";
            String[] args = new String[0];
            String key = "lc0".equals(selected) ? "lc0|" : "stockfish|";
            if ("lc0".equals(selected)) {
                if (!("maia-1100".equals(selectedModel) || "maia-1500".equals(selectedModel) || "maia-1900".equals(selectedModel))) {
                    return "{\"ok\":false,\"error\":\"Unknown Maia model.\"}";
                }
                File model = new File(new File(activity.getFilesDir(), "maia"), selectedModel + ".pb.gz");
                if (!model.isFile() || model.length() < 1024) {
                    return "{\"ok\":false,\"error\":\"Download the " + selectedModel + " model before starting this opponent.\"}";
                }
                path = lc0Path(); name = "Lc0 / " + selectedModel;
                args = new String[] { "--weights=" + model.getAbsolutePath(), "--threads=1", "--backend=blas", "--search-algorithm=policyhead" };
            } else if (!"stockfish".equals(selected)) {
                return "{\"ok\":false,\"error\":\"Unknown engine provider.\"}";
            }
            if (engine != null && !key.equals(engineKey)) { engine.shutdown(); engine = null; }
            engineKey = key;
            if (engine == null) {
                final String engineLabel = name;
                engine = new EngineProcess(path, activity.getFilesDir(), new EngineProcess.Listener() {
                    @Override public void onLine(String line) { queueLine(line); }
                    @Override public void onExit(int code, String message) {
                        flushNow();
                        js("window.__cbNative&&window.__cbNative.engineExit(" + code + "," + Json.quote(message) + ")");
                    }
                }, engineLabel, args);
            }
            String err = engine.start();
            diagnostics.log(err == null ? "INFO" : "ERROR", "engine.start", "provider=" + selected + " model=" + selectedModel + " ok=" + (err == null));
            String abi = Build.VERSION.SDK_INT >= 21 && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "unknown";
            return err == null
                ? "{\"ok\":true,\"path\":" + Json.quote(path) + ",\"provider\":" + Json.quote(selected) + ",\"abi\":" + Json.quote(abi) + "}"
                : "{\"ok\":false,\"error\":" + Json.quote(err) + "}";
        }
    }

    private static final class MaiaModelEntry {
        final String id, file, url, sha256;
        final long bytes;
        MaiaModelEntry(String id, String file, String url, String sha256, long bytes) {
            this.id = id; this.file = file; this.url = url; this.sha256 = sha256; this.bytes = bytes;
        }
    }

    private static String jsonString(String json, String key) {
        Matcher m = Pattern.compile("\\\"" + Pattern.quote(key) + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"").matcher(json);
        return m.find() ? m.group(1) : "";
    }
    private static long jsonLong(String json, String key) {
        Matcher m = Pattern.compile("\\\"" + Pattern.quote(key) + "\\\"\\s*:\\s*(\\d+)").matcher(json);
        try { return m.find() ? Long.parseLong(m.group(1)) : 0; } catch (NumberFormatException e) { return 0; }
    }
    private MaiaModelEntry maiaModelEntry(String modelId) throws Exception {
        if (!("maia-1100".equals(modelId) || "maia-1500".equals(modelId) || "maia-1900".equals(modelId))) return null;
        InputStream in = activity.getAssets().open("models/maia-models.json");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        try { while ((n = in.read(buf)) != -1) out.write(buf, 0, n); } finally { in.close(); }
        String manifest = new String(out.toByteArray(), "UTF-8");
        Matcher items = Pattern.compile("\\{[^{}]*\\}").matcher(manifest);
        while (items.find()) {
            String item = items.group();
            if (modelId.equals(jsonString(item, "id"))) {
                return new MaiaModelEntry(modelId, jsonString(item, "file"), jsonString(item, "url"),
                    jsonString(item, "sha256").toLowerCase(java.util.Locale.US), jsonLong(item, "bytes"));
            }
        }
        return null;
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        InputStream in = new java.io.FileInputStream(file);
        byte[] buf = new byte[65536];
        try { int n; while ((n = in.read(buf)) != -1) digest.update(buf, 0, n); } finally { in.close(); }
        StringBuilder hex = new StringBuilder();
        for (byte b : digest.digest()) hex.append(String.format(java.util.Locale.US, "%02x", b & 0xff));
        return hex.toString();
    }

    private File maiaModelFile(String modelId, MaiaModelEntry entry) throws Exception {
        String fileName = entry.file;
        if (!fileName.matches("maia-(1100|1500|1900)\\.pb\\.gz")) throw new IllegalArgumentException("Invalid model filename");
        File dir = new File(activity.getFilesDir(), "maia");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Could not create model directory");
        return new File(dir, fileName);
    }

    private boolean validModelFile(File file, MaiaModelEntry entry) {
        try {
            long expectedBytes = entry.bytes;
            String expectedHash = entry.sha256;
            if (!file.isFile() || expectedBytes < 1024 || file.length() != expectedBytes || !expectedHash.matches("[0-9a-f]{64}")) return false;
            return expectedHash.equals(sha256(file));
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public String maiaModelPath(String modelId) {
        try {
            MaiaModelEntry entry = maiaModelEntry(modelId);
            if (entry == null || !entry.sha256.matches("[0-9a-f]{64}") || entry.bytes < 1024) return "";
            File file = maiaModelFile(modelId, entry);
            return file.isFile() && file.length() == entry.bytes ? file.getAbsolutePath() : "";
        } catch (Exception e) { return ""; }
    }

    @JavascriptInterface
    public String maiaModelStatus(String modelId) {
        try {
            MaiaModelEntry entry = maiaModelEntry(modelId);
            if (entry == null) return "{\"ok\":false,\"error\":\"unknown_model\"}";
            File file = maiaModelFile(modelId, entry);
            boolean ready = validModelFile(file, entry);
            return "{\"ok\":true,\"modelId\":" + Json.quote(modelId) + ",\"downloaded\":" + ready + ",\"bytes\":" + (ready ? file.length() : 0) + ",\"total\":" + entry.bytes + "}";
        } catch (Exception e) { return "{\"ok\":false,\"error\":\"model_manifest_unavailable\"}"; }
    }

    @JavascriptInterface
    public String downloadMaiaModel(final String modelId) {
        try {
            final MaiaModelEntry entry = maiaModelEntry(modelId);
            if (entry == null) return "{\"ok\":false,\"error\":\"unknown_model\"}";
            final File target = maiaModelFile(modelId, entry);
            if (validModelFile(target, entry)) return "{\"ok\":true,\"downloaded\":true}";
            final String url = entry.url;
            final String expectedHash = entry.sha256;
            final long expectedBytes = entry.bytes;
            if (!url.equals("https://github.com/CSSLab/maia-chess/releases/download/v1.0/" + target.getName())
                    || !expectedHash.matches("[0-9a-f]{64}") || expectedBytes < 1024 || expectedBytes > 100L * 1024L * 1024L) {
                return "{\"ok\":false,\"error\":\"model_manifest_invalid\"}";
            }
            final AtomicBoolean cancel = new AtomicBoolean(false);
            if (modelCancel.putIfAbsent(modelId, cancel) != null) return "{\"ok\":true,\"started\":true}";
            pool.execute(new Runnable() {
                @Override public void run() {
                    File temp = new File(target.getParentFile(), target.getName() + ".part");
                    HttpURLConnection conn = null;
                    try {
                        URL modelUrl = new URL(url);
                        conn = (HttpURLConnection) modelUrl.openConnection();
                        conn.setConnectTimeout(20000); conn.setReadTimeout(120000); conn.setInstanceFollowRedirects(true);
                        conn.setRequestProperty("User-Agent", "ChessBuddy/5.0 model downloader");
                        modelConnections.put(modelId, conn);
                        int status = conn.getResponseCode();
                        String finalHost = conn.getURL().getHost();
                        if (status < 200 || status >= 300 || !("release-assets.githubusercontent.com".equals(finalHost) || "objects.githubusercontent.com".equals(finalHost))) {
                            throw new IllegalStateException("Model download host or response was not accepted");
                        }
                        long length = conn.getContentLength();
                        if (length > 0 && length != expectedBytes) throw new IllegalStateException("Model size did not match the manifest");
                        MessageDigest digest = MessageDigest.getInstance("SHA-256");
                        InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(temp);
                        byte[] buf = new byte[65536]; long count = 0; long lastNotice = 0;
                        try {
                            int n;
                            while ((n = in.read(buf)) != -1) {
                                if (cancel.get() || destroyed) throw new InterruptedException("cancelled");
                                count += n; if (count > expectedBytes) throw new IllegalStateException("Model file exceeded expected size");
                                digest.update(buf, 0, n); out.write(buf, 0, n);
                                if (count - lastNotice >= 524288) { lastNotice = count; js("window.__cbNative&&window.__cbNative.maiaDownloadProgress(" + Json.quote(modelId) + "," + count + "," + expectedBytes + ")"); }
                            }
                            out.flush();
                        } finally { try { in.close(); } catch (Exception ignored) {} try { out.close(); } catch (Exception ignored) {} }
                        StringBuilder actual = new StringBuilder();
                        for (byte b : digest.digest()) actual.append(String.format(java.util.Locale.US, "%02x", b & 0xff));
                        if (count != expectedBytes || !expectedHash.equals(actual.toString())) throw new IllegalStateException("Model checksum verification failed");
                        if (target.exists() && !target.delete()) throw new IllegalStateException("Could not replace old model file");
                        if (!temp.renameTo(target)) throw new IllegalStateException("Could not finalize downloaded model");
                        js("window.__cbNative&&window.__cbNative.maiaDownloadComplete(" + Json.quote(modelId) + ",true,\"\")");
                    } catch (Exception e) {
                        if (temp.exists()) temp.delete();
                        String reason = cancel.get() || e instanceof InterruptedException ? "Download cancelled" : "Model download failed: " + e.getClass().getSimpleName();
                        js("window.__cbNative&&window.__cbNative.maiaDownloadComplete(" + Json.quote(modelId) + ",false," + Json.quote(reason) + ")");
                    } finally {
                        if (conn != null) conn.disconnect();
                        modelConnections.remove(modelId); modelCancel.remove(modelId);
                    }
                }
            });
            return "{\"ok\":true,\"started\":true}";
        } catch (Exception e) { return "{\"ok\":false,\"error\":\"model_manifest_unavailable\"}"; }
    }

    @JavascriptInterface
    public void cancelMaiaModelDownload(String modelId) {
        AtomicBoolean flag = modelCancel.get(modelId);
        if (flag != null) flag.set(true);
        HttpURLConnection conn = modelConnections.get(modelId);
        if (conn != null) conn.disconnect();
    }

    @JavascriptInterface
    public void engineSend(String line) { EngineProcess e; synchronized (this) { e = engine; } if (e != null) e.send(line); }

    @JavascriptInterface
    public void engineStop() { EngineProcess e; synchronized (this) { e = engine; } if (e != null) e.stop(); }

    private void queueLine(String line) {
        synchronized (pending) {
            pending.add(line);
            if (pending.size() > 400) {                       // UI thread stalled: drop old progress lines, never results
                for (int i = 0; i < pending.size() && pending.size() > 200; ) {
                    String s = pending.get(i);
                    if (s.startsWith("info ") && !s.startsWith("info string")) pending.remove(i); else i++;
                }
            }
            if (!flushScheduled) { flushScheduled = true; main.postDelayed(flushTask, 30); }
        }
    }

    private final Runnable flushTask = new Runnable() { @Override public void run() { flushNow(); } };

    private void flushNow() {
        ArrayList<String> batch;
        synchronized (pending) { batch = new ArrayList<String>(pending); pending.clear(); flushScheduled = false; }
        if (batch.isEmpty()) return;
        StringBuilder sb = new StringBuilder("window.__cbNative&&window.__cbNative.engineLines([");
        for (int i = 0; i < batch.size(); i++) { if (i > 0) sb.append(','); sb.append(Json.quote(batch.get(i))); }
        sb.append("])");
        js(sb.toString());
    }

    /* ---------------- HTTP with the stored key ---------------- */

    @JavascriptInterface
    public void httpPost(final String reqId, final String keyId, final String url, final String authScheme, final String extraHeaders, final String body) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                long started = System.currentTimeMillis();
                HttpTransport.Result r;
                try { r = run2(); } catch (RuntimeException e) { r = new HttpTransport.Result(0, "", "io", "Unexpected error: " + e.getClass().getSimpleName()); }
                diagnostics.log(r.status >= 200 && r.status < 300 ? "INFO" : "WARN", "network.post", safeEndpoint(url) + " status=" + r.status + " kind=" + r.kind + " durationMs=" + (System.currentTimeMillis() - started));
                inflight.remove(reqId);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(r.body) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
            private HttpTransport.Result run2() {
                String why = HostPolicy.check(url);
                if (why != null) return new HttpTransport.Result(0, "", "policy", why);
                String authName = null, authValue = null;
                String key = SecretStore.validId(keyId) ? secrets.get(keyId) : null;
                if (key == null && HostPolicy.isSupabasePublicPost(url, keyId, SUPABASE_URL)) key = SUPABASE_PUBLISHABLE_KEY;
                boolean local = url.toLowerCase().startsWith("http://");
                if (key == null && !local) return new HttpTransport.Result(0, "", "nokey", "");
                if (key != null) {
                    if ("x-api-key".equals(authScheme)) { authName = "x-api-key"; authValue = key; }
                    else if ("bearer".equals(authScheme)) { authName = "Authorization"; authValue = "Bearer " + key; }
                }
                return HttpTransport.post(url, authName, authValue, extraHeaders, body, 15000, 120000, MAX_RESPONSE_BYTES, tok);
            }
        });
    }

    /** Supabase Auth. Refresh tokens and PKCE verifiers stay encrypted in Android Keystore storage. */
    @JavascriptInterface
    public void supabaseAuth(final String reqId, final String operation, final String payload) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result result;
                try { result = runAuth(); }
                catch (RuntimeException e) {
                    diagnostics.log("ERROR", "auth.unexpected_error", "Authentication exception=" + e.getClass().getSimpleName());
                    result = new HttpTransport.Result(0, "", "io", "Authentication request failed: " + e.getClass().getSimpleName());
                }
                inflight.remove(reqId);
                String safeBody = redactRefreshToken(result.body);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + result.status + "," + Json.quote(safeBody) + "," + Json.quote(result.kind) + "," + Json.quote(result.message) + ")");
            }

            private HttpTransport.Result runAuth() {
                String op = operation == null ? "" : operation;
                String body = payload == null ? "{}" : payload;
                String endpoint;
                String bearer = null;

                if ("signup".equals(op)) {
                    endpoint = "/auth/v1/signup?redirect_to=chessbuddy%3A%2F%2Fauth-callback";
                } else if ("signin".equals(op)) {
                    endpoint = "/auth/v1/token?grant_type=password";
                } else if ("verify".equals(op)) {
                    endpoint = "/auth/v1/verify";
                } else if ("recover".equals(op)) {
                    endpoint = "/auth/v1/recover?redirect_to=chessbuddy%3A%2F%2Fauth-callback";
                } else if ("resend".equals(op)) {
                    endpoint = "/auth/v1/resend";
                } else if ("updatePassword".equals(op)) {
                    String access = jsonStringField(body, "access_token");
                    String password = jsonStringField(body, "password");
                    if (access == null || access.length() < 20 || password == null || password.length() < 8) {
                        return new HttpTransport.Result(400, "", "authinput", "A valid signed-in session and an 8-character password are required.");
                    }
                    String updateBody = "{\"password\":" + Json.quote(password) + "}";
                    long updateStarted = System.currentTimeMillis();
                    HttpTransport.Result updated = HttpTransport.put(SUPABASE_URL + "/auth/v1/user", null, null,
                        "apikey: " + SUPABASE_PUBLISHABLE_KEY + "\nAuthorization: Bearer " + access,
                        updateBody, 15000, 30000, MAX_RESPONSE_BYTES, tok);
                    diagnostics.log(updated.status >= 200 && updated.status < 300 ? "INFO" : "WARN", "auth.password_update", "status=" + updated.status + " kind=" + updated.kind + " durationMs=" + (System.currentTimeMillis() - updateStarted));
                    return updated;
                } else if ("exchange".equals(op)) {
                    endpoint = "/auth/v1/token?grant_type=pkce";
                    String code = jsonStringField(body, "auth_code");
                    String verifier = secrets.get(SUPABASE_PKCE_VERIFIER_ID);
                    if (code == null || code.length() < 8 || verifier == null || verifier.length() < 43) {
                        secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                        return new HttpTransport.Result(400, "", "pkce", "The sign-in callback could not be verified. Start Google sign-in again.");
                    }
                    body = "{\"auth_code\":" + Json.quote(code) + ",\"code_verifier\":" + Json.quote(verifier) + "}";
                } else if ("session".equals(op)) {
                    String access = jsonStringField(body, "access_token");
                    String refresh = jsonStringField(body, "refresh_token");
                    if (access == null || access.length() < 20) {
                        return new HttpTransport.Result(400, "", "authresponse", "The callback did not contain a usable access token. Return to ChessBuddy and sign in again.");
                    }
                    HttpTransport.Result checked = HttpTransport.get(SUPABASE_URL + "/auth/v1/user",
                        "apikey: " + SUPABASE_PUBLISHABLE_KEY + "\nAuthorization: Bearer " + access,
                        15000, 30000, MAX_RESPONSE_BYTES, tok);
                    if (checked.kind.length() > 0 || checked.status < 200 || checked.status >= 300) return checked;
                    if (refresh != null && refresh.length() > 20 && !saveRefreshToken(refresh)) {
                        return new HttpTransport.Result(500, "", "securestorage", "Google sign-in worked, but Android could not securely save the session. Check device security storage and try again.");
                    }
                    secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                    diagnostics.log("INFO", "auth.callback_success", "Callback token validated; persistentSession=" + (refresh != null));
                    // The user endpoint validates the bearer, but its response does not contain the token.
                    // Return the verified access token to the in-memory JS session; refresh stays encrypted natively.
                    String userJson = checked.body == null || checked.body.trim().length() == 0 ? "{}" : checked.body;
                    String sessionJson = "{\"access_token\":" + Json.quote(access) + ",\"user\":" + userJson + "}";
                    return new HttpTransport.Result(200, sessionJson, "", "");
                } else if ("refresh".equals(op)) {
                    endpoint = "/auth/v1/token?grant_type=refresh_token";
                    String refresh = secrets.get(SUPABASE_REFRESH_ID);
                    if (refresh == null) return new HttpTransport.Result(401, "", "noauth", "No saved session on this device. Sign in or create an account.");
                    body = "{\"refresh_token\":" + Json.quote(refresh) + "}";
                } else if ("logout".equals(op)) {
                    endpoint = "/auth/v1/logout";
                    bearer = jsonStringField(body, "access_token");
                    body = "{}";
                    if (bearer == null || bearer.length() < 20) {
                        secrets.clear(SUPABASE_REFRESH_ID);
                        secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                        diagnostics.log("INFO", "auth.logout_local", "Local session cleared");
                        return new HttpTransport.Result(200, "{}", "", "");
                    }
                } else {
                    return new HttpTransport.Result(400, "", "policy", "Unsupported authentication action.");
                }

                String headers = "apikey: " + SUPABASE_PUBLISHABLE_KEY;
                if (bearer != null) headers += "\nAuthorization: Bearer " + bearer;
                long started = System.currentTimeMillis();
                HttpTransport.Result response = HttpTransport.post(SUPABASE_URL + endpoint, null, null, headers,
                    body, 15000, 30000, MAX_RESPONSE_BYTES, tok);

                if (response.kind.length() > 0 || response.status < 200 || response.status >= 300) {
                    if ("refresh".equals(op) && (response.status == 400 || response.status == 401)) secrets.clear(SUPABASE_REFRESH_ID);
                    if ("exchange".equals(op)) secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                    diagnostics.log("WARN", "auth." + op + ".failed", "status=" + response.status + " kind=" + response.kind + " durationMs=" + (System.currentTimeMillis() - started));
                    return response;
                }

                if ("logout".equals(op)) {
                    secrets.clear(SUPABASE_REFRESH_ID);
                    secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                    diagnostics.log("INFO", "auth.logout", "Session cleared from this device");
                    return response;
                }

                String refresh = jsonStringField(response.body, "refresh_token");
                String access = jsonStringField(response.body, "access_token");
                if (refresh != null && refresh.length() > 20) {
                    if (!saveRefreshToken(refresh)) {
                        diagnostics.log("ERROR", "auth.session_store_failed", "Secure refresh token storage failed after " + op);
                        return new HttpTransport.Result(500, "", "securestorage", "Sign-in succeeded, but ChessBuddy could not save the session securely on this device. Check Android security storage and try again.");
                    }
                } else if (("signin".equals(op) || "verify".equals(op) || "exchange".equals(op) || "refresh".equals(op))
                    && (access == null || access.length() < 20)) {
                    diagnostics.log("ERROR", "auth.access_missing", "Auth server returned success without a usable access token; operation=" + op + ", responseBytes=" + response.body.length());
                    return new HttpTransport.Result(502, "", "authresponse", "The server accepted the request but returned no usable session access token. Check the Supabase Auth response and any proxy in front of it.");
                } else if (access != null && access.length() > 20 && refresh == null) {
                    diagnostics.log("WARN", "auth.refresh_missing", "A usable access token arrived without a refresh token; the session cannot survive expiry or app restart");
                }

                if ("exchange".equals(op)) secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                diagnostics.log("INFO", "auth." + op + ".success", "status=" + response.status + " persistentSession=" + (refresh != null) + " durationMs=" + (System.currentTimeMillis() - started));
                return response;
            }
        });
    }

    private boolean saveRefreshToken(String refresh) {
        return refresh != null && refresh.length() > 20
            && secrets.set(SUPABASE_REFRESH_ID, refresh)
            && refresh.equals(secrets.get(SUPABASE_REFRESH_ID));
    }

    /** Builds a standards-compliant PKCE challenge and stores its verifier only in encrypted native storage. */
    @JavascriptInterface
    public String createAuthChallenge() {
        try {
            byte[] bytes = new byte[32];
            new SecureRandom().nextBytes(bytes);
            String verifier = Base64.encodeToString(bytes, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(verifier.getBytes("UTF-8"));
            String challenge = Base64.encodeToString(digest, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            if (!secrets.set(SUPABASE_PKCE_VERIFIER_ID, verifier)) {
                secrets.clear(SUPABASE_PKCE_VERIFIER_ID);
                diagnostics.log("ERROR", "auth.pkce_storage_failed", "Could not store PKCE verifier securely");
                return "";
            }
            diagnostics.log("INFO", "auth.pkce_created", "Google OAuth PKCE challenge created");
            return "{\"challenge\":" + Json.quote(challenge) + "}";
        } catch (Exception e) {
            diagnostics.log("ERROR", "auth.pkce_error", "PKCE creation failed: " + e.getClass().getSimpleName());
            return "";
        }
    }

    /** Only opens this app's configured Supabase Google authorization URL and exact callback. */
    @JavascriptInterface
    public boolean openAuthUrl(final String url) {
        if (url == null) return false;
        final Uri uri;
        try { uri = Uri.parse(url); } catch (Exception e) { return false; }
        if (!"https".equalsIgnoreCase(uri.getScheme())
            || !"npicptuurxuqxepxzumi.supabase.co".equalsIgnoreCase(uri.getHost())
            || !"/auth/v1/authorize".equals(uri.getPath())
            || !"google".equalsIgnoreCase(uri.getQueryParameter("provider"))
            || !"chessbuddy://auth-callback".equals(uri.getQueryParameter("redirect_to"))) return false;
        main.post(new Runnable() { @Override public void run() {
            try {
                activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
                diagnostics.log("INFO", "auth.google_browser_opened", "Google OAuth browser flow started");
            } catch (Exception e) {
                diagnostics.log("ERROR", "auth.google_browser_failed", "Browser launch failed: " + e.getClass().getSimpleName());
                Toast.makeText(activity, "Could not open Google sign-in. Check that a browser is installed.", Toast.LENGTH_LONG).show();
            }
        } });
        return true;
    }

    @JavascriptInterface
    public void logEvent(String event, String detail) {
        if (diagnostics != null) diagnostics.log("INFO", event, detail);
    }

    @JavascriptInterface
    public String diagnosticsLocation() { return diagnostics == null ? "" : diagnostics.location(); }

    @JavascriptInterface
    public boolean rustAvailable() { return RustChess.isLoaded(); }

    @JavascriptInterface
    public boolean rustMoveLegal(String fen, String uci) {
        if (!RustChess.isLoaded()) return true;
        boolean legal = RustChess.isLegalMove(fen, uci);
        if (!legal) diagnostics.log("WARN", "chess.rust_validation_reject", "Native rules validator rejected a move already presented by the UI rules layer");
        return legal;
    }

    private static String safeEndpoint(String raw) {
        try { Uri u = Uri.parse(raw); return (u.getHost() == null ? "unknown-host" : u.getHost()) + (u.getPath() == null ? "/" : u.getPath()); }
        catch (Exception e) { return "unknown-endpoint"; }
    }

    private static String jsonStringField(String json, String field) {
        if (json == null || field == null) return null;
        try {
            org.json.JSONObject object = new org.json.JSONObject(json);
            String value = object.optString(field, null);
            if (value != null) return value;
        } catch (Exception ignored) { }
        Pattern p = Pattern.compile("\"" + Pattern.quote(field) + "\"\\s*:\\s*\"([^\"]*)\"");
        Matcher m = p.matcher(json);
        return m.find() ? m.group(1) : null;
    }

    private static String redactRefreshToken(String json) {
        if (json == null || json.length() == 0) return json == null ? "" : json;
        return json.replaceAll("\"refresh_token\"\\s*:\\s*\"[^\"]*\"", "\"refresh_token\":\"[stored securely on device]\"");
    }

    /** Public GET requests. No API key or Authorization header is attached. */
    @JavascriptInterface
    public void httpGet(final String reqId, final String url, final String extraHeaders) {
        if (reqId == null || !reqId.matches("[A-Za-z0-9_]{1,64}")) return;
        final HttpTransport.CancelToken tok = new HttpTransport.CancelToken();
        inflight.put(reqId, tok);
        pool.execute(new Runnable() {
            @Override public void run() {
                HttpTransport.Result r;
                try {
                    String why = HostPolicy.check(url);
                    r = why == null ? HttpTransport.get(url, extraHeaders, 10000, 15000, 1024 * 1024, tok)
                        : new HttpTransport.Result(0, "", "policy", why);
                } catch (RuntimeException e) { r = new HttpTransport.Result(0, "", "io", "Unexpected error: " + e.getClass().getSimpleName()); }
                diagnostics.log(r.status >= 200 && r.status < 300 ? "INFO" : "WARN", "network.get", safeEndpoint(url) + " status=" + r.status + " kind=" + r.kind);
                inflight.remove(reqId);
                js("window.__cbNative&&window.__cbNative.httpResult(" + Json.quote(reqId) + "," + r.status + "," + Json.quote(r.body) + "," + Json.quote(r.kind) + "," + Json.quote(r.message) + ")");
            }
        });
    }

    @JavascriptInterface
    public void httpCancel(String reqId) { HttpTransport.CancelToken t = reqId == null ? null : inflight.get(reqId); if (t != null) t.cancel(); }

    /* ---------------- keys (never returned to JS) ---------------- */

    @JavascriptInterface public boolean hasKey(String id) { return secrets.has(id); }
    @JavascriptInterface public String keyHint(String id) { return secrets.hint(id); }
    @JavascriptInterface public boolean setKey(String id, String key) { return secrets.set(id, key); }
    @JavascriptInterface public boolean clearKey(String id) { secrets.clear(id); return true; }
    @JavascriptInterface public boolean secureStorage() { return secrets.secureStorage(); }

    /* ---------------- speech ---------------- */

    /** Reports whether the Android speech engine finished initialization with a supported language. */
    @JavascriptInterface
    public boolean speechReady() { return !destroyed && textToSpeechReady && textToSpeech != null; }

    /** Speaks with the Android system TTS engine; no audio or voice data is bundled. */
    @JavascriptInterface
    public boolean speakText(final String text, final float pitch, final float rate) {
        if (text == null || text.length() == 0 || text.length() > 1200 || !textToSpeechReady || textToSpeech == null) return false;
        main.post(new Runnable() { @Override public void run() {
            if (destroyed || textToSpeech == null || !textToSpeechReady) return;
            try {
                textToSpeech.setPitch(Math.max(0.5f, Math.min(2.0f, pitch)));
                textToSpeech.setSpeechRate(Math.max(0.65f, Math.min(1.5f, rate)));
                if (Build.VERSION.SDK_INT >= 21) textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "chessbuddy_" + System.currentTimeMillis());
                else textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            } catch (RuntimeException e) { diagnostics.log("WARN", "voice.speak_failed", e.getClass().getSimpleName()); }
        } });
        return true;
    }

    @JavascriptInterface
    public void stopSpeech() {
        main.post(new Runnable() { @Override public void run() {
            if (textToSpeech != null) try { textToSpeech.stop(); } catch (RuntimeException ignored) { }
        } });
    }

    /* ---------------- device helpers ---------------- */

    @JavascriptInterface
    public boolean copyText(final String text) {
        if (text == null) return false;
        main.post(new Runnable() { @Override public void run() {
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("ChessBuddy", text));
        } });
        return true;
    }

    @JavascriptInterface
    public boolean shareText(final String title, final String text) {
        if (text == null) return false;
        main.post(new Runnable() { @Override public void run() {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "ChessBuddy" : title);
            send.putExtra(Intent.EXTRA_TEXT, text);
            activity.startActivity(Intent.createChooser(send, title == null ? "Share" : title));
        } });
        return true;
    }

    @JavascriptInterface
    public void toast(final String msg) { main.post(new Runnable() { @Override public void run() { Toast.makeText(activity, msg == null ? "" : msg, Toast.LENGTH_SHORT).show(); } }); }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        main.post(new Runnable() { @Override public void run() {
            if (on) activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } });
    }

    @JavascriptInterface
    public String deviceInfo() {
        long memMb = 0;
        try {
            ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            if (am != null) { am.getMemoryInfo(mi); memMb = mi.totalMem / (1024 * 1024); }
        } catch (RuntimeException ignored) { /* keep 0 */ }
        String version = "", abi = Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "";
        long code = 0;
        try {
            PackageInfo pi = activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0);
            version = pi.versionName == null ? "" : pi.versionName;
            code = pi.versionCode;
        } catch (Exception ignored) { /* keep defaults */ }
        return "{\"cores\":" + Runtime.getRuntime().availableProcessors() + ",\"memMb\":" + memMb + ",\"abi\":" + Json.quote(abi)
            + ",\"sdk\":" + Build.VERSION.SDK_INT + ",\"version\":" + Json.quote(version) + ",\"versionCode\":" + code + "}";
    }

    void shutdown() {
        destroyed = true;
        if (textToSpeech != null) { try { textToSpeech.stop(); textToSpeech.shutdown(); } catch (RuntimeException ignored) { } textToSpeech = null; }
        textToSpeechReady = false;
        EngineProcess e; synchronized (this) { e = engine; engine = null; }
        if (e != null) e.shutdown();
        for (HttpTransport.CancelToken t : inflight.values()) t.cancel();
        for (AtomicBoolean flag : modelCancel.values()) flag.set(true);
        for (HttpURLConnection conn : modelConnections.values()) conn.disconnect();
        pool.shutdownNow();
    }

    File filesDir() { return activity.getFilesDir(); }
}
