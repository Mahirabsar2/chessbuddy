# Build ChessBuddy 2.0.0

This archive is the complete ChessBuddy 2.0.0 Android source project. Extract it so `app/build.gradle`, `settings.gradle`, `scripts/`, `tests/` and `app/src/` are at the project root. The archive contains source code plus the real ARM64 native runtime libraries required by the app; it does not contain an APK or a signing key.

## Build requirements

- JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- Android NDK 27.2.12479018
- Gradle 8.9
- Rust stable with the `aarch64-linux-android` target (only needed when rebuilding the Rust native library)
- Node.js for the JavaScript test suite

## Verify the source

From the project root:

```bash
node tests/run-all.js
bash tests/java/run.sh
node --check app/src/main/assets/js/app.js
node --check app/src/main/assets/js/avatars.js
node --check app/src/main/assets/js/native.js
```

## Build an arm64 release APK

Set `ANDROID_HOME` or `ANDROID_SDK_ROOT`, install the SDK/NDK versions above, configure a private signing keystore through `CB_KEYSTORE_FILE`, `CB_KEYSTORE_PASSWORD`, `CB_KEY_ALIAS` and `CB_KEY_PASSWORD`, then run:

```bash
gradle --no-daemon assembleRelease
```

The APK is written to `app/build/outputs/apk/release/app-release.apk`. Verify it with:

```bash
bash scripts/verify_apk.sh app/build/outputs/apk/release/app-release.apk
```

Do not commit a keystore or signing password. A new ephemeral signing key is suitable only for a one-off sideload; Android will not accept it as an in-place update to a build signed with a different key.

## Native engines and Maia

The ARM64 runtime files are included in `app/src/main/jniLibs/arm64-v8a/`, with provenance, SHA-256 manifests and license notices under `build-info/` and `app/src/main/assets/licenses/`. The source-build scripts can rebuild Stockfish, Lc0/OpenBLAS and the Rust JNI core when the Android NDK and required source downloads are available:

- `scripts/build_stockfish_android.sh`
- `scripts/build_lc0_android.sh`
- `scripts/build_rust_android.sh`

Maia weights are not packed into the ZIP. The app downloads a selected official model on demand and validates it against `app/src/main/assets/models/maia-models.json`.

## Release verification still required

A successful Node/Java test run is not proof of a working Android release. Build and install the APK on an arm64 Android phone, then verify app startup, board input, Stockfish and Maia play, SVG bot portraits, Android text-to-speech playback, account flows, Lichess lookups and two-device friend play. Browser screenshot tests require Playwright, and live backend tests require the relevant provider configuration.
