# ChessBuddy 2.0.0 — full source package

This archive is a source/build package, not an APK. It contains the Android project, HTML/CSS/JavaScript UI, Java bridge, Rust core source, backend functions and migrations, tests, build scripts, original bot vector artwork source, and the pinned ARM64 native runtime dependencies.

## Why the source archive is over 50 MB

The archive includes the real Stockfish 19 ARM64 runtime (`libstockfish.so`, approximately 95 MiB), Lc0, the Android C++ runtime and the ChessBuddy Rust JNI library. These are required runtime/build dependencies, not padding files. Their SHA-256 and upstream provenance are in `build-info/`.

## Bot artwork

The roster currently contains 171 bots. Every bot receives a deterministic, distinct SVG portrait from the hand-authored renderer in `app/src/main/assets/js/avatars.js`, using its own character traits and color/face variations. No AI-generated portraits or Chess.com assets are used. The renderer is original ChessBuddy artwork; it is not an exact copy of another company's protected avatar designs.

## Voice

Coach comments and optional bot move narration use Android's system TextToSpeech interface. Individual bot profiles vary pitch and rate, but playback uses the voices installed on the user's device; the app does not contain 171 separately recorded character voices. `SpeechSynthesis` is available as a browser fallback.

## Offline/build notes

- Android target ABI: `arm64-v8a`.
- The included native libraries let Gradle package the pinned engine runtimes directly.
- The reproduction scripts in `scripts/` can rebuild Stockfish and Lc0 from pinned upstream source revisions when network access and the Android NDK are available.
- Maia model weights are intentionally downloaded on demand; metadata and checksums are included in the model manifest.
- No APK or signing key is included in this archive.

## Verification limits

Logic tests and Java policy tests pass in the packaging environment. A local Android Gradle build, Playwright visual suite, physical-device voice playback test, full OAuth test and two-device multiplayer test remain release gates. See `docs/2.0.0_IMPLEMENTATION_STATUS.md`.
