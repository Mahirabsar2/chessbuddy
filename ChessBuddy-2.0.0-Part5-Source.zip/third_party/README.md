# Third-party engine dependencies

The source package carries the pinned ARM64 runtime libraries in `app/src/main/jniLibs/arm64-v8a/` so the Android app can be assembled without first rebuilding the native engines. `build-info/` records the exact upstream revision, toolchain, binary size and SHA-256 for Stockfish and Lc0. The JNI Rust core and NDK C++ runtime are included alongside them.

Reproducible source-build scripts are in `scripts/`:

- `build_stockfish_android.sh` fetches the pinned official Stockfish tag and builds it with the Android NDK.
- `build_lc0_android.sh` checks out the pinned Lc0 revision and OpenBLAS source, then builds the policyhead backend for arm64.

Those scripts also create corresponding-source archives under `third_party/sources/` when run with the required network access and Android NDK. The app does not bundle Maia weights; it downloads the selected official model on demand and validates the downloaded file. Model URLs, sizes and hashes are recorded in `app/src/main/assets/models/maia-models.json`.

See `app/src/main/assets/licenses/` for the included third-party license notices. No Chess.com code, logos or proprietary avatar files are included.
