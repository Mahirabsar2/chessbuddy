# ChessBuddy 2.0.0

ChessBuddy is an Android-first chess app with a polished original chess-club interface, local play, engine and model opponents, game review, coaches, voice output and private direct-friend challenges. This is a 2.0.0 rebuild candidate source package, not a verified production release. See `docs/2.0.0_IMPLEMENTATION_STATUS.md` and `docs/RELEASE_CHECKLIST.md` for the current implementation and release gates.

## Play and opponents

- Human vs engine, pass-and-play and AI vs AI.
- A 171-bot roster spanning beginner to master strengths, adaptive opponents, named chess personalities, fictional characters, visualization challenges and Maia profiles.
- Original deterministic SVG portraits with distinct character traits; the same bot portrait is used in the roster, selection preview and game UI. No Chess.com artwork, logos or proprietary assets are bundled.
- Stockfish UCI engine, optional Lc0 + Maia model support, and configurable AI opponents through supported API providers.
- Time controls with increment, live clocks passed to engines, board tap selection and drag/drop, legal move hints, promotion, castling, en passant, undo, board flip, move animations and sound.

## Training and review

- Original coaches with distinct profiles, review comments, opening references and optional spoken comments.
- Game archive, import/export, backup/restore, analysis, evaluation, move classifications, replay and opening explorer.
- Bot move announcements and per-bot voice previews use Android system TextToSpeech, with browser SpeechSynthesis fallback. Bots vary speaking pitch and pace; these are device-generated voices, not individually recorded voice actors.

## Accounts and online play

- Email/password and Google OAuth UI, profile/presence, online player list and direct friend challenges.
- No random matchmaking, rating ladder, global chat or push notifications are claimed.
- Online move sync depends on deploying the included Supabase schema and Edge Function changes together. See `docs/ONLINE_PLAY_STATUS.md` and `docs/AUTH_GOOGLE_EMAIL_SETUP.md`.

## Build and test

The source package includes the Android project, native runtime dependencies, provenance and license notices. It does not include an APK or signing key. Run `node tests/run-all.js` and `bash tests/java/run.sh` from the project root. Android build instructions are in `BUILD_ON_GITHUB.md`.

## Important limits

This is an original ChessBuddy implementation intended to offer a familiar chess-club experience, not an exact copy of Chess.com or a claim of feature parity with its proprietary services, artwork, content, matchmaking or social systems. Real Android device, external account, backend and multiplayer testing is still required before calling this a release.
