Stockfish binary fragments are in Parts 1-4. Run scripts/reassemble_stockfish.sh from the extracted project root after placing the four ZIPs in source-parts/.
