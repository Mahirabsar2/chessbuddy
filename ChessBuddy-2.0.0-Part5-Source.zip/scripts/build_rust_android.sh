#!/usr/bin/env bash
set -euo pipefail

# Resolve every path from this script, not from the caller's working directory.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CRATE_DIR="$ROOT/rust/chessbuddy-core"
MANIFEST="$CRATE_DIR/Cargo.toml"
JNI_LIBS="$ROOT/app/src/main/jniLibs"

: "${ANDROID_NDK_HOME:=${ANDROID_NDK_ROOT:-${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}/ndk/27.2.12479018}}"
export ANDROID_NDK_HOME
if [[ -z "$ANDROID_NDK_HOME" || ! -d "$ANDROID_NDK_HOME" ]]; then
  echo "Android NDK not found at: ${ANDROID_NDK_HOME:-<unset>}" >&2
  exit 2
fi

if ! command -v cargo >/dev/null 2>&1; then
  echo "Rust cargo is required to build the ChessBuddy native core." >&2
  exit 2
fi

# Fail early with a useful message if the source archive was packaged incorrectly.
if [[ ! -s "$MANIFEST" ]]; then
  echo "Rust crate manifest missing: $MANIFEST" >&2
  echo "Expected rust/chessbuddy-core/Cargo.toml inside the extracted source ZIP." >&2
  exit 2
fi

rustup target add aarch64-linux-android
if ! command -v cargo-ndk >/dev/null 2>&1; then
  cargo install cargo-ndk --locked
fi

# cargo-ndk runs `cargo metadata` before invoking Cargo. Its metadata lookup uses
# the process working directory, so run from the crate directory instead of
# relying on --manifest-path being forwarded to the later Cargo invocation.
cd "$CRATE_DIR"
cargo metadata --no-deps --format-version 1 --manifest-path "$MANIFEST" >/dev/null
mkdir -p "$JNI_LIBS"
cargo ndk -t arm64-v8a -o "$JNI_LIBS" build --release

LIB="$JNI_LIBS/arm64-v8a/libchessbuddy_core.so"
test -s "$LIB"
file "$LIB"
readelf -h "$LIB" | grep -q 'Machine:.*AArch64'
echo "Rust JNI library built and verified: $LIB"
