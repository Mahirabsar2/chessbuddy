#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PARTS="${1:-$ROOT/source-parts}"
TARGET="$ROOT/app/src/main/jniLibs/arm64-v8a/libstockfish.so"
mkdir -p "$(dirname "$TARGET")"
for i in 1 2 3 4; do
  unzip -p "$PARTS/ChessBuddy-2.0.0-Part${i}-Stockfish.zip" "engine-parts/libstockfish.so.part$(printf '%02d' "$i")"
done > "$TARGET"
EXPECTED="0470a60d55495faaa56fa4a47a938569abdbeb80cd6b4c12dcc4efc139a11bd6"
ACTUAL="$(sha256sum "$TARGET" | awk '{print $1}')"
[ "$ACTUAL" = "$EXPECTED" ] || { echo "Stockfish SHA-256 mismatch" >&2; exit 1; }
echo "Stockfish reassembled and verified: $ACTUAL"
