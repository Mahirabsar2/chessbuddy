package android.speech.tts;
import android.content.Context;
import java.util.Locale;
public class TextToSpeech {
  public static final int SUCCESS = 0, LANG_MISSING_DATA = -1, LANG_NOT_SUPPORTED = -2, QUEUE_FLUSH = 0;
  public interface OnInitListener { void onInit(int status); }
  public TextToSpeech(Context context, OnInitListener listener) { if (listener != null) listener.onInit(SUCCESS); }
  public int setLanguage(Locale locale) { return SUCCESS; }
  public int setPitch(float pitch) { return SUCCESS; }
  public int setSpeechRate(float rate) { return SUCCESS; }
  public int speak(String text, int queueMode, Object params, String utteranceId) { return SUCCESS; }
  public int speak(String text, int queueMode, Object params) { return SUCCESS; }
  public int stop() { return SUCCESS; }
  public void shutdown() { }
}
