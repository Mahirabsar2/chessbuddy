# ChessBuddy online play backend

The connected Supabase project has the initial friend-play schema applied. It contains:

- `chessbuddy_profiles` — unique usernames and display names
- `chessbuddy_presence` — online/away state and last-seen heartbeat
- `chessbuddy_challenges` — direct player-to-player invites with accept/decline/expiry
- `chessbuddy_games` — private PGN/FEN, time control, clocks, turn, and result records

RPCs:

- `cb_register_profile`
- `cb_set_presence`
- `cb_send_challenge`
- `cb_respond_challenge`
- `cb_cancel_challenge`
- `cb_apply_move`

All four tables have RLS enabled. Clients can select only public profiles/presence and challenge/game rows involving themselves. Table writes are revoked from authenticated clients; changes go through security-definer RPCs that check the caller and whose `search_path` is empty.

## Remaining client work

The Android app still needs the sign-in/sign-up UI, secure Supabase session handling, online roster polling or Realtime subscriptions, invite notifications, and the online-game sync loop. The database is ready for that client layer, but the app does not yet offer playable online matches. `cb_apply_move` checks participant and turn ownership; a production anti-cheat implementation should also validate each move server-side rather than trusting a client-supplied FEN/PGN.
