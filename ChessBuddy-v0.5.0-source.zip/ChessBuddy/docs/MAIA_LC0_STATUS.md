# Maia / Leela Chess Zero integration status

Maia is a human-move prediction model, not a complete chess engine by itself. The original Maia 1 models (1100, 1500, 1900 targets) are distributed as Leela Chess Zero network weights and are run by the Lc0 UCI engine. Maia's documented usage is effectively a one-node policy inference (`go nodes 1`), rather than a long Stockfish-style search.

## What is in this prototype

- Stockfish remains the built-in engine and the existing opponent roster is preserved.
- The app's UCI client now supports live `wtime`, `btime`, `winc`, and `binc` clock commands.
- The engine abstraction is kept UCI-based so a second engine can be added without changing chess rules or bot selection UI.

## What is not yet shipped

Maia/Lc0 is **not yet a selectable, playable opponent** in this build. The Android Lc0 release is an engine-only app, and the current ChessBuddy native bridge starts only its bundled Stockfish executable. To make Maia real, the next implementation step is to add an Lc0 engine process/adapter, provide a Maia network picker/downloader, pass the selected network path to Lc0, and expose Maia 1100/1500/1900 inside the existing opponent roster (not as a separate opponent screen). Do not show Maia as playable until that path is verified on-device.

## References

- Maia models and Lc0 usage: https://github.com/UNO-AI-Lab/maiachess
- Lc0 Android download: https://lczero.org/play/download/
- Lc0 Android + chess-app integration notes: https://lczero.org/dev/wiki/running-lc0-on-android-with-a-chess-app/
