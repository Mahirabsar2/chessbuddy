# ChessBuddy v0.4.0 — status

## Delivered
Everything in README.md: bot grid with 167 bots in 15 categories, Stockfish levels, Mittens, coaches, chess.com-style review, clocks, drag-and-drop, animations, sounds,
new game screen, settings that survive updates, backup/restore.

## Verified (actually run in the build sandbox)
- 70 logic tests: perft (5 positions), UCI client, provider requests/images, prompts + move parser, review model + opening book (all lines legal), strength/roster, coaches/clock.
- 34 UI tests in headless Chromium with a **test-only** mock Android bridge: first move as White/Black, strength options reaching the engine, drag and drop, immovable pieces, capture-square layout regression,
  captured pieces, figurines, eval bar, clocks, promotion, checkmate, undo/flip, hint, AI vs AI, engine crash/missing, export, screenshots in requests, AI-model players, review screen, coaches, bot grid,
  settings upgrade safety, backup/restore.
- All Java classes compile against Android API stubs; URL-safety policy passes 17 JVM cases.

## Not verified
Gradle/NDK build of this version (your GitHub run does it), behaviour on a real phone for the new features (sounds, haptics-free), real Stockfish strength calibration, real API calls from this sandbox.

## Ideas
Puzzles, lessons, premoves, board/piece themes, online play.


## 5.0 prototype work (2026-11-14)

- Clock now starts on Black immediately after White's first move; timed Stockfish searches receive live UCI clocks/increments.
- Bot think duration is randomized; the fixed thinking-time setting was removed from Settings.
- Game Review now uses a fast single-PV scan and only deepens tactical/swing positions, with an in-memory FEN/settings cache.
- Original SVG bot portraits now receive deterministic face-expression/accessory variations.
- Lichess Opening Explorer and standard tablebase lookups are available in the game Options menu.
- Supabase friend-play tables/RPCs and RLS hardening have been applied to the connected project; the Android online client is still pending.
- Maia/Lc0 integration is documented but not playable yet; do not advertise it as shipped.
