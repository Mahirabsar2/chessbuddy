#!/usr/bin/env bash
# Builds REAL Stockfish for 64-bit ARM Android phones and installs it as app/src/main/jniLibs/arm64-v8a/libstockfish.so.
#   1. (primary)  compile the official source tag with the Android NDK:  make net && make build ARCH=armv8 COMP=ndk
#                 (the recipe from the official Stockfish wiki, "Compiling from source" -> Android)
#   2. (fallback) download the official prebuilt Android armv8 release asset, discovered through the GitHub API
# Never substitutes anything else: if both fail, the script fails and so does the build.
set -euo pipefail

SF_TAG="${SF_TAG:-sf_19}"
SF_REPO="${SF_REPO:-https://github.com/official-stockfish/Stockfish.git}"
if [ -z "${SF_EXPECT_COMMIT+x}" ]; then if [ "$SF_TAG" = "sf_19" ]; then SF_EXPECT_COMMIT="edb0d9d"; else SF_EXPECT_COMMIT=""; fi; fi
OUT_DIR="${OUT_DIR:-app/src/main/jniLibs/arm64-v8a}"
INFO_DIR="${INFO_DIR:-build-info}"
WORK="${WORK_DIR:-$(mktemp -d)}"
MIN_BYTES=$((8 * 1024 * 1024))     # the NNUE network is embedded; a binary this small means it is missing
mkdir -p "$OUT_DIR" "$INFO_DIR"
ROOT="$(pwd)"
METHOD=""; COMMIT=""; NDK_REV=""

log() { echo "[stockfish] $*"; }
die() { echo "::error::[stockfish] $*" >&2; exit 1; }

find_ndk() {
  local d base c
  for d in "${ANDROID_NDK_HOME:-}" "${ANDROID_NDK_ROOT:-}" "${ANDROID_NDK_LATEST_HOME:-}"; do
    if [ -n "$d" ] && [ -d "$d/toolchains/llvm/prebuilt" ]; then echo "$d"; return 0; fi
  done
  for base in "${ANDROID_SDK_ROOT:-}" "${ANDROID_HOME:-}" /usr/local/lib/android/sdk; do
    if [ -n "$base" ] && [ -d "$base/ndk" ]; then
      c="$(ls -1 "$base/ndk" | sort -V | tail -1)"
      if [ -n "$c" ] && [ -d "$base/ndk/$c/toolchains/llvm/prebuilt" ]; then echo "$base/ndk/$c"; return 0; fi
    fi
  done
  return 1
}

build_from_source() {
  local ndk bin
  ndk="$(find_ndk)" || { log "no Android NDK found"; return 1; }
  bin="$ndk/toolchains/llvm/prebuilt/linux-x86_64/bin"
  [ -x "$bin/aarch64-linux-android21-clang++" ] || { log "NDK toolchain missing in $ndk"; return 1; }
  export PATH="$bin:$PATH"
  NDK_REV="$(grep -m1 'Pkg.Revision' "$ndk/source.properties" 2>/dev/null | sed 's/.*= *//' || true)"
  log "NDK: $ndk (revision ${NDK_REV:-unknown})"
  aarch64-linux-android21-clang++ --version | head -1
  rm -rf "$WORK/Stockfish"
  git clone --quiet --depth 1 --branch "$SF_TAG" "$SF_REPO" "$WORK/Stockfish" || { log "git clone failed"; return 1; }
  COMMIT="$(git -C "$WORK/Stockfish" rev-parse HEAD)"
  log "source: $SF_REPO tag $SF_TAG -> commit $COMMIT"
  if [ -n "$SF_EXPECT_COMMIT" ] && [ "${COMMIT#"$SF_EXPECT_COMMIT"}" = "$COMMIT" ]; then
    echo "::warning::[stockfish] tag $SF_TAG resolved to $COMMIT (expected a commit starting with $SF_EXPECT_COMMIT). Continuing; check STOCKFISH_PROVENANCE.txt."
  fi
  ( cd "$WORK/Stockfish/src"
    log "make net (downloads the NNUE network that gets embedded in the binary)"
    make net
    export LDFLAGS="${LDFLAGS:-} -Wl,-z,max-page-size=16384"       # 16 KB-page devices (Android 15+)
    log "make -j$(nproc) build ARCH=armv8 COMP=ndk"
    make -j"$(nproc)" build ARCH=armv8 COMP=ndk
    if command -v llvm-strip >/dev/null 2>&1; then llvm-strip --strip-all stockfish || log "strip skipped"; fi
  ) || { log "source build failed"; return 1; }
  CANDIDATE="$WORK/Stockfish/src/stockfish"
  METHOD="built from source with the Android NDK (ARCH=armv8 COMP=ndk)"
  [ -f "$CANDIDATE" ]
}

fetch_prebuilt() {
  local api json url pkg found f
  api="${GITHUB_API:-https://api.github.com}/repos/official-stockfish/Stockfish/releases/tags/$SF_TAG"
  json="$(curl -fsSL --retry 3 -H 'Accept: application/vnd.github+json' ${GITHUB_TOKEN:+-H "Authorization: Bearer $GITHUB_TOKEN"} "$api")" || { log "release API unreachable"; return 1; }
  url="$(printf '%s' "$json" | grep -o '"browser_download_url": *"[^"]*"' | sed 's/.*: *"//; s/"$//' | grep -i android | grep -i armv8 | grep -vi dotprod | head -1 || true)"
  [ -n "$url" ] || { log "no armv8 Android asset on release $SF_TAG"; return 1; }
  log "downloading $url"
  pkg="$WORK/prebuilt.pkg"; curl -fsSL --retry 3 -o "$pkg" "$url" || return 1
  rm -rf "$WORK/prebuilt"; mkdir -p "$WORK/prebuilt"
  case "$url" in *.zip) unzip -q -o "$pkg" -d "$WORK/prebuilt" ;; *) tar -xf "$pkg" -C "$WORK/prebuilt" ;; esac
  found=""
  while IFS= read -r f; do
    if file "$f" | grep -q 'ELF 64-bit.*ARM aarch64'; then found="$f"; break; fi
  done < <(find "$WORK/prebuilt" -type f -size +1M | sort)
  [ -n "$found" ] || { log "no aarch64 ELF in the downloaded asset"; return 1; }
  CANDIDATE="$found"; COMMIT="(prebuilt release asset of $SF_TAG)"
  METHOD="official prebuilt release asset: $url"
}

CANDIDATE=""
if ! build_from_source; then
  log "falling back to the official prebuilt Android binary"
  fetch_prebuilt || die "could not build or download Stockfish for Android. See the log above."
fi

# ---------- verify what we are about to ship ----------
[ -f "$CANDIDATE" ] || die "no binary produced"
file "$CANDIDATE" | tee "$WORK/file.txt"
grep -q 'ARM aarch64' "$WORK/file.txt" || die "binary is not an ARM aarch64 ELF"
SIZE="$(stat -c %s "$CANDIDATE")"
[ "$SIZE" -ge "$MIN_BYTES" ] || die "binary is only $SIZE bytes: the NNUE network is not embedded"
if command -v readelf >/dev/null 2>&1; then readelf -lW "$CANDIDATE" | grep -E 'LOAD|INTERP' | head -6 || true; fi

install -m 0755 "$CANDIDATE" "$OUT_DIR/libstockfish.so"
SHA="$(sha256sum "$OUT_DIR/libstockfish.so" | cut -d' ' -f1)"
{
  echo "Stockfish provenance"
  echo "  tag:      $SF_TAG"
  echo "  commit:   ${COMMIT:-unknown}"
  echo "  source:   $SF_REPO"
  echo "  method:   $METHOD"
  echo "  NDK:      ${NDK_REV:-n/a}"
  echo "  binary:   $OUT_DIR/libstockfish.so  ($SIZE bytes)"
  echo "  sha256:   $SHA"
  echo "  license:  GPL-3.0-or-later (https://github.com/official-stockfish/Stockfish/blob/$SF_TAG/Copying.txt)"
} | tee "$INFO_DIR/stockfish.txt"
log "OK: Stockfish $SF_TAG installed as libstockfish.so"
