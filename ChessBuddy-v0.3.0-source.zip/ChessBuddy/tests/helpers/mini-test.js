// Tiny dependency-free test runner (works on any Node >= 14).
const results = [];
let chain = Promise.resolve();
function test(name, fn) {
  chain = chain.then(async () => {
    const t0 = Date.now();
    try { await fn(); results.push({ name, ok: true, ms: Date.now() - t0 }); console.log('  PASS ' + name + ' (' + (Date.now() - t0) + ' ms)'); }
    catch (e) { results.push({ name, ok: false, err: e }); console.log('  FAIL ' + name + '\n       ' + (e && e.stack ? e.stack.split('\n').slice(0, 4).join('\n       ') : e)); }
  });
}
function done(label) {
  return chain.then(() => {
    const failed = results.filter(r => !r.ok).length;
    console.log((failed ? 'FAILED ' : 'OK ') + label + ': ' + (results.length - failed) + '/' + results.length + ' passed');
    process.exitCode = failed ? 1 : 0;
    return { passed: results.length - failed, failed, total: results.length };
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
module.exports = { test, done, sleep };
