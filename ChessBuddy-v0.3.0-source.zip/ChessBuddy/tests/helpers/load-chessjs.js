// Loads the bundled browser-style chess.js into Node (for tests only).
const fs = require('fs'), vm = require('vm'), path = require('path');
module.exports = function loadChess() {
  const file = path.join(__dirname, '..', '..', 'app', 'src', 'main', 'assets', 'js', 'chess.js');
  const ctx = { console }; ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(file, 'utf8'), ctx, { filename: 'chess.js' });
  return ctx.ChessJS;
};
