// TEST-ONLY scripted UCI peer used to exercise the engine client's protocol handling.
// It is NOT shipped in the APK and is NOT an engine: it only replays Stockfish-formatted lines.
function makeFakeTransport(opts) {
  opts = opts || {};
  const log = [];                 // every command the client sent
  let timer = null, alive = false, searching = false, pending = null;
  const t = {
    log, startCalls: 0, stopCalls: 0, onLine: null, onExit: null,
    start() { t.startCalls++; if (opts.failStart) return Promise.resolve({ ok: false, error: opts.failStart }); alive = true; return Promise.resolve({ ok: true }); },
    stop() { t.stopCalls++; alive = false; clearTimeout(timer); },
    kill(code, msg) { alive = false; clearTimeout(timer); t.onExit && t.onExit(code == null ? 1 : code, msg || 'Engine process exited'); },
    emit(l) { setImmediate(() => { if (alive || opts.emitWhenDead) t.onLine && t.onLine(l); }); },
    send(line) {
      log.push(line);
      if (!alive) return;
      const w = line.split(' ');
      if (line === 'uci') {
        ['id name Stockfish 19', 'id author the Stockfish developers (see AUTHORS file)',
         'option name Threads type spin default 1 min 1 max 1024', 'option name Hash type spin default 16 min 1 max 33554432',
         'option name Clear Hash type button', 'option name MultiPV type spin default 1 min 1 max 256',
         'option name Skill Level type spin default 20 min 0 max 20', 'option name UCI_LimitStrength type check default false',
         'option name UCI_Elo type spin default 1320 min 1320 max 3190', 'option name Move Overhead type spin default 10 min 0 max 5000',
         'uciok'].forEach(t.emit);
      } else if (line === 'isready') { t.emit('readyok'); }
      else if (w[0] === 'go') {
        searching = true;
        const mt = w[1] === 'movetime' ? +w[2] : 30;
        if (opts.silentGo) return;
        if (opts.crashOnGo) { t.emit('info string CRITICAL ERROR invalid position'); setTimeout(() => t.kill(1, 'Engine process exited'), 5); return; }
        const mpv = +(opts.multipv || 1);
        const lines = [];
        for (let k = 1; k <= mpv; k++) lines.push(`info depth 12 seldepth 16 multipv ${k} score cp ${30 - k * 10} nodes 1000 nps 100000 time 10 pv ${k === 1 ? 'e2e4 e7e5 g1f3' : 'd2d4 d7d5'}`);
        pending = () => { searching = false; pending = null; lines.forEach(t.emit); t.emit(opts.noneMove ? 'bestmove (none)' : 'bestmove e2e4 ponder e7e5'); };
        timer = setTimeout(() => { if (pending) pending(); }, Math.min(mt, opts.maxThink || 5000));
      } else if (line === 'stop') {
        if (searching && pending) { clearTimeout(timer); const p = pending; setTimeout(p, 2); }
      } else if (line === 'quit') { t.kill(0, 'quit'); }
    }
  };
  return t;
}
module.exports = { makeFakeTransport };
