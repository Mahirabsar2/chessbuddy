const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const P = require('../../app/src/main/assets/js/prompts.js');
const { Chess } = require('../helpers/load-chessjs')();
P.setChess(Chess);
console.log('prompts.js (position report, move explanations, parser)');
const play = (g, sans) => { sans.forEach(s => g.move(s)); return g; };

test('report contains board diagram, FEN, pieces, every move explained, tactical facts, legal moves', () => {
  const g = play(new Chess(), ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5']);
  const t = P.positionReport({ game: g, playerColor: 'w', opponent: 'Marlow (Elo 1500)', hasImage: true });
  ['=== GAME ===', '=== BOARD ===', '=== PIECES ===', '=== EVERY MOVE PLAYED (explained) ===', '=== COMPUTED TACTICAL FACTS ===', '=== STOCKFISH ===', '=== LEGAL MOVES (SAN) ==='].forEach(h => assert.ok(t.includes(h), h));
  assert.ok(t.includes('FEN: ' + g.fen()));
  assert.ok(/The user plays White against Marlow/.test(t));
  assert.ok(t.includes('1. e4 — White pawn e2→e4'));
  assert.ok(t.includes('2... Nc6 — Black knight b8→c6'));
  assert.ok(t.includes('3. Bb5 — White bishop f1→b5'));
  assert.ok(/screenshot of this exact position is attached/.test(t));
  assert.ok(/Current position: not available/.test(t));
  assert.ok(t.includes(g.moves().join(' ')));
});
test('board diagram has rank/file labels and correct orientation', () => {
  const d = P.boardDiagram(new Chess());
  assert.ok(/ 8 \| r n b q k b n r \| 8/.test(d) && / 1 \| R N B Q K B N R \| 1/.test(d) && / 4 \| \. \. \. \. \. \. \. \. \| 4/.test(d));
});
test('move explanations: capture, castling, en passant, promotion, check, mate', () => {
  const g = new Chess();
  ['e4', 'd5', 'exd5', 'Nf6', 'Nc3', 'Nxd5', 'Nf3', 'e6', 'Be2', 'Be7', 'O-O'].forEach(s => g.move(s));
  const h = g.history({ verbose: true });
  assert.ok(/capturing the Black pawn/.test(P.describeMove(h[2])));
  assert.ok(/castles kingside \(king e1→g1, rook h1→f1\)/.test(P.describeMove(h[10])));
  const ep = new Chess('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1'); ep.move('exd6');
  assert.ok(/en passant/.test(P.describeMove(ep.history({ verbose: true })[0])));
  const pr = new Chess('8/P6k/8/8/8/8/8/K7 w - - 0 1'); pr.move('a8=Q');
  assert.ok(/promoting to a queen/.test(P.describeMove(pr.history({ verbose: true })[0])));
  assert.ok(/CHECKMATE/.test(P.describeMove(play(new Chess(), ['f3', 'e5', 'g4', 'Qh4#']).history({ verbose: true })[3])));
});
test('tactical facts: undefended attacked piece is flagged; check is reported', () => {
  const g = new Chess('4k3/8/8/8/3q4/8/8/3RK3 w - - 0 1');   // black queen d4 attacked by rook d1, undefended
  const t = P.tacticalFacts(g);
  assert.ok(/queen d4 attacked by rook d1 \[UNDEFENDED\]/.test(t), t);
  const c = P.tacticalFacts(play(new Chess(), ['e4', 'f5', 'Qh5+']));
  assert.ok(/king on e8 IS IN CHECK from queen h5/.test(c), c);
});
test('pawn-structure notes: doubled, isolated, passed', () => {
  const t = P.tacticalFacts(new Chess('4k3/8/8/8/P7/P7/7p/4K3 w - - 0 1'));
  assert.ok(/doubled pawns on the a-file/.test(t) && /isolated pawn on a4/.test(t) && /passed pawn on a4/.test(t), t);
});
test('long games keep full narrative for the last 100 plies and SAN-only before', () => {
  const g = new Chess(); let n = 0;
  while (!g.isGameOver() && n < 130) { g.move(g.moves()[0]); n++; }
  const t = P.moveNarrative(g, 20);
  assert.ok(/earlier moves, SAN only/.test(t) || g.history().length <= 20);
});
test('Stockfish block uses White-perspective evals and SAN lines', () => {
  const g = play(new Chess(), ['e4']);
  const t = P.analysisBlock(g.fen(), [{ depth: 18, multipv: 1, score: { type: 'cp', value: 35 }, pv: ['e7e5', 'g1f3'] }], 'Current position');
  assert.ok(t.includes('1) -0.35: e5 Nf3') && t.includes('depth 18'));
});
test('system prompts state the ground-truth rule and player format', () => {
  assert.ok(/GROUND TRUTH/.test(P.SYSTEM_COACH)); assert.ok(/MOVE: <your move in SAN>/.test(P.systemPlayer('b'))); assert.ok(/playing Black/.test(P.systemPlayer('b')));
});
test('player message lists every legal move and the rejection reason on retry', () => {
  const g = new Chess();
  const m = P.playerUserMessage({ game: g, opponent: 'Stockfish', hasImage: true, rejection: 'Ke2 is not legal.' });
  assert.ok(m.includes(g.moves().join(' ')) && /REJECTED: Ke2 is not legal/.test(m) && /MOVE: <move>/.test(m));
});

/* ---- the move parser: many real-world reply shapes, all validated against legal moves ---- */
const parse = (text, fen) => { const g = fen ? new Chess(fen) : new Chess(); const r = P.parseMoveReply(text, g); return r.ok ? r.move.san : 'FAIL:' + r.reason; };
test('parser accepts the requested format, UCI, castling variants and prose', () => {
  assert.strictEqual(parse('MOVE: e4\nWHY: centre'), 'e4');
  assert.strictEqual(parse('MOVE: e2e4'), 'e4');
  assert.strictEqual(parse('MOVE: e2-e4'), 'e4');
  assert.strictEqual(parse('move: Nf3'), 'Nf3');
  assert.strictEqual(parse('{"move":"d4","reason":"x"}'), 'd4');
  assert.strictEqual(parse('I will play **Nf3** to develop.'), 'Nf3');
  assert.strictEqual(parse('1. e4'), 'e4');
  assert.strictEqual(parse('nf3'), 'Nf3');
  assert.strictEqual(parse('MOVE: e4!'), 'e4');
  const castle = 'r3k2r/pppppppp/8/8/8/8/PPPPPPPP/R3K2R w KQkq - 0 1';
  assert.strictEqual(parse('MOVE: 0-0', castle), 'O-O'); assert.strictEqual(parse('MOVE: O-O-O', castle), 'O-O-O');
  assert.strictEqual(parse('MOVE: e1g1', castle), 'O-O');
});
test('parser handles captures without x, promotions and check marks', () => {
  const fen = 'rnbqkbnr/ppp1pppp/8/3p4/4P3/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 2';
  assert.strictEqual(parse('MOVE: exd5', fen), 'exd5'); assert.strictEqual(parse('MOVE: ed5', fen), 'exd5');
  const promo = '8/P6k/8/8/8/8/8/K7 w - - 0 1';
  assert.strictEqual(parse('MOVE: a8=Q+', promo), 'a8=Q'); assert.strictEqual(parse('MOVE: a7a8q', promo), 'a8=Q'); assert.strictEqual(parse('MOVE: a8Q', promo), 'a8=Q');
});
test('parser rejects illegal or missing moves with a reason instead of guessing', () => {
  assert.strictEqual(parse('MOVE: Ke2'), 'FAIL:no_match'); assert.strictEqual(parse('MOVE: e5'), 'FAIL:no_match'); assert.strictEqual(parse(''), 'FAIL:empty');
  assert.strictEqual(parse('I think the position is roughly equal and both sides have chances.'), 'FAIL:no_match');
  const rooks = '4k3/8/8/8/8/8/4K3/R6R w - - 0 1';        // both rooks reach d1: SAN needs the file
  assert.strictEqual(parse('MOVE: Rd1', rooks), 'FAIL:ambiguous'); assert.strictEqual(parse('MOVE: Rad1', rooks), 'Rad1');
});
test('parser: the very first move of a game works for both colours (regression: "AI made an illegal move at the start")', () => {
  assert.strictEqual(parse('MOVE: e4'), 'e4');
  const black = new Chess(); black.move('e4');
  assert.strictEqual(P.parseMoveReply('MOVE: e5\nWHY: mirror', black).move.san, 'e5');
  assert.strictEqual(P.parseMoveReply('e7e5', black).move.san, 'e5');
});
done('prompts.js');
