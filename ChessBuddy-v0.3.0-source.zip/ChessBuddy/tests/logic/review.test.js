const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const R = require('../../app/src/main/assets/js/review.js');
const { Chess } = require('../helpers/load-chessjs')();
console.log('review.js');
test('classification thresholds and accuracy curve', () => {
  assert.deepStrictEqual([0, 20, 40, 80, 200, 600].map(R.classify), ['best', 'excellent', 'good', 'inaccuracy', 'mistake', 'blunder']);
  assert.ok(R.accuracy(0) > 99 && R.accuracy(100) < 5 && R.accuracy(30) > R.accuracy(60));
});
test('compute: loss from consecutive evaluations, best move scores zero, per-side summary', () => {
  const g = new Chess(); ['e4', 'e5', 'Qh5'].forEach(s => g.move(s));
  const h = g.history({ verbose: true });
  const pos = [ { score: { type: 'cp', value: 30 }, best: 'e2e4' },        // before e4: played best
                { score: { type: 'cp', value: 25 }, best: 'e7e5' },        // before e5 (Black to move; +25 for Black): played best
                { score: { type: 'cp', value: 20 }, best: 'g1f3' },        // before Qh5 (White): best Nf3 +20
                { score: { type: 'cp', value: 120 }, best: 'g8f6' } ];     // after Qh5 Black to move +120 => White's value -120
  const res = R.compute(h, pos);
  assert.strictEqual(res.rows[0].cls, 'best'); assert.strictEqual(res.rows[1].cls, 'best');
  assert.strictEqual(res.rows[2].loss, 140); assert.strictEqual(res.rows[2].cls, 'mistake');
  assert.strictEqual(res.summary.w.moves, 2); assert.strictEqual(res.summary.w.acpl, 70); assert.strictEqual(res.summary.b.acpl, 0);
  const t = R.table(h, res, i => ({ 2: 'Nf3' }[i]));
  assert.ok(/2\. Qh5 \(White\) — Mistake, lost 140 cp, best was Nf3/.test(t) && /Summary:/.test(t));
});
test('mate scores are handled without NaN and capped', () => {
  const g = new Chess(); ['f3', 'e5', 'g4', 'Qh4#'].forEach(s => g.move(s));
  const pos = [ { score: { type: 'cp', value: 0 }, best: 'e2e4' }, { score: { type: 'cp', value: 10 }, best: 'e7e5' }, { score: { type: 'cp', value: 0 }, best: 'e2e4' },
                { score: { type: 'mate', value: 1 }, best: 'd8h4' }, { score: { type: 'mate', value: 0 }, best: null } ];
  const res = R.compute(g.history({ verbose: true }), pos);
  assert.ok(res.rows.every(r => Number.isFinite(r.loss))); assert.strictEqual(res.rows[2].cls, 'blunder');
});
done('review.js');
