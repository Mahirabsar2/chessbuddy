const assert = require('assert');
const { test, done, sleep } = require('../helpers/mini-test');
const { makeFakeTransport } = require('../helpers/fake-uci');
const E = require('../../app/src/main/assets/js/engine.js');
const loadChess = require('../helpers/load-chessjs');
const { Chess } = loadChess();

console.log('engine.js (UCI client)');

test('handshake: uci -> uciok -> isready -> readyok; options + id parsed', async () => {
  const t = makeFakeTransport(); const eng = new E.UciEngine(t);
  await eng.start();
  assert.strictEqual(eng.state, 'ready');
  assert.strictEqual(eng.idName, 'Stockfish 19');
  assert.deepStrictEqual(eng.optionRange('UCI_Elo'), { min: 1320, max: 3190, def: '1320' });
  assert.ok(eng.hasOption('Clear Hash') && eng.options['Clear Hash'].type === 'button');
  assert.deepStrictEqual(t.log.slice(0, 2), ['uci', 'isready']);
});

test('start failure is reported (no fake fallback engine)', async () => {
  const t = makeFakeTransport({ failStart: 'libstockfish.so not found' }); const eng = new E.UciEngine(t);
  await assert.rejects(() => eng.start(), e => e.name === 'EngineError' && e.kind === 'start' && /not found/.test(e.message));
  assert.strictEqual(eng.state, 'dead');
  await assert.rejects(() => eng.search({ movetime: 50, moves: [] }), e => e.kind === 'start');
});

test('setOptions clamps spin values, skips unknown options, never resends unchanged values', async () => {
  const t = makeFakeTransport(); const eng = new E.UciEngine(t); await eng.start();
  const r1 = await eng.setOptions({ UCI_Elo: 800, Threads: 99999, 'Nope Option': 1, UCI_LimitStrength: true });
  assert.strictEqual(r1.sent, 3); assert.deepStrictEqual(r1.skipped, ['Nope Option']);
  assert.ok(t.log.includes('setoption name UCI_Elo value 1320'));      // clamped up to min
  assert.ok(t.log.includes('setoption name Threads value 1024'));      // clamped down to max
  assert.ok(t.log.includes('setoption name UCI_LimitStrength value true'));
  const before = t.log.length; const r2 = await eng.setOptions({ UCI_Elo: 1320, UCI_LimitStrength: true });
  assert.strictEqual(r2.sent, 0); assert.strictEqual(t.log.length, before);
});

test('search: sends position+go, returns bestmove, sorted multipv lines, calls onInfo', async () => {
  const t = makeFakeTransport({ multipv: 3 }); const eng = new E.UciEngine(t); await eng.start();
  let infos = 0;
  const r = await eng.search({ moves: ['e2e4', 'e7e5'], movetime: 60, options: { MultiPV: 3 }, onInfo: () => infos++ });
  assert.strictEqual(r.bestmove, 'e2e4'); assert.strictEqual(r.cancelled, false);
  assert.strictEqual(JSON.stringify(r.lines.map(l => l.multipv)), '[1,2,3]');
  assert.ok(infos >= 3);
  assert.ok(t.log.includes('position startpos moves e2e4 e7e5'));
  assert.ok(t.log.includes('go movetime 60'));
  assert.ok(t.log.includes('setoption name MultiPV value 3'));
});

test('search from a custom FEN uses "position fen"', async () => {
  const t = makeFakeTransport(); const eng = new E.UciEngine(t); await eng.start();
  const fen = '8/8/8/8/8/8/6k1/4K2R w K - 0 1';
  await eng.search({ startFen: fen, moves: ['h1h2'], movetime: 30 });
  assert.ok(t.log.includes('position fen ' + fen + ' moves h1h2'));
});

test('stop(): cancels a long search, resolves cancelled=true, next search is not confused', async () => {
  const t = makeFakeTransport({ maxThink: 8000 }); const eng = new E.UciEngine(t); await eng.start();
  const p = eng.search({ moves: [], movetime: 7000 });
  await sleep(30);
  assert.ok(eng.isSearching());
  await eng.stop();
  const r = await p;
  assert.strictEqual(r.cancelled, true);
  assert.ok(!eng.isSearching());
  const r2 = await eng.search({ moves: ['d2d4'], movetime: 30 });
  assert.strictEqual(r2.cancelled, false); assert.strictEqual(r2.bestmove, 'e2e4');
});

test('latest search wins: a newer search cancels the running one', async () => {
  const t = makeFakeTransport({ maxThink: 8000 }); const eng = new E.UciEngine(t); await eng.start();
  const a = eng.search({ moves: [], movetime: 7000 });
  await sleep(30);
  const b = eng.search({ moves: ['e2e4'], movetime: 30, options: { MultiPV: 1 } });
  const [ra, rb] = await Promise.all([a, b]);
  assert.strictEqual(ra.cancelled, true); assert.strictEqual(rb.cancelled, false);
});

test('isStale() aborts a queued search without sending go', async () => {
  const t = makeFakeTransport(); const eng = new E.UciEngine(t); await eng.start();
  const goBefore = t.log.filter(l => l.startsWith('go')).length;
  const r = await eng.search({ moves: [], movetime: 30, isStale: () => true });
  assert.strictEqual(r.cancelled, true);
  assert.strictEqual(t.log.filter(l => l.startsWith('go')).length, goBefore);
});

test('timeout: silent engine rejects with EngineError(timeout); next search drains with isready first', async () => {
  const t = makeFakeTransport({ silentGo: true }); const eng = new E.UciEngine(t, { searchGraceMs: 80 });
  await eng.start();
  await assert.rejects(() => eng.search({ moves: [], movetime: 50 }), e => e.kind === 'timeout');
  assert.ok(t.log.includes('stop'));
  t.log.length = 0;
  const t2 = t; // same transport, engine now answers
  await assert.doesNotReject(async () => { /* engine stays silent for go; only check ordering of the sync barrier */
    const p = eng.search({ moves: [], movetime: 50 }).catch(() => {});
    await sleep(40);
    assert.strictEqual(t2.log[0], 'isready', 'must resync with isready before the next position/go');
    eng.shutdown(); await p;
  });
});

test('engine crash with CRITICAL ERROR rejects the search with details; next search restarts the engine', async () => {
  const t = makeFakeTransport({ crashOnGo: true }); const eng = new E.UciEngine(t); await eng.start();
  await assert.rejects(() => eng.search({ moves: [], movetime: 50 }), e => e.kind === 'exited' && /CRITICAL ERROR/.test(e.message));
  assert.strictEqual(eng.state, 'dead');
  const startsBefore = t.startCalls;
  const p = eng.search({ moves: [], movetime: 50 }).catch(() => {});
  await sleep(60); await p;
  assert.ok(t.startCalls > startsBefore, 'engine must be restarted on next use');
});

test('bestmove (none) maps to none=true, bestmove=null', async () => {
  const t = makeFakeTransport({ noneMove: true }); const eng = new E.UciEngine(t); await eng.start();
  const r = await eng.search({ moves: [], movetime: 30 });
  assert.strictEqual(r.none, true); assert.strictEqual(r.bestmove, null);
});

test('commands are sanitized (no embedded newlines reach the engine)', async () => {
  const t = makeFakeTransport(); const eng = new E.UciEngine(t); await eng.start();
  await eng.search({ startFen: 'x\nquit', moves: [], movetime: 30 });
  assert.ok(t.log.every(l => !/[\r\n]/.test(l)));
});

test('uciMovesFromHistory + positionCommand agree with chess.js (castling, promotion, en passant)', () => {
  const g = new Chess();
  ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'O-O', 'Nf6'].forEach(m => g.move(m));
  assert.strictEqual(JSON.stringify(E.uciMovesFromHistory(g.history({ verbose: true }))), JSON.stringify(['e2e4', 'e7e5', 'g1f3', 'b8c6', 'f1c4', 'f8c5', 'e1g1', 'g8f6']));
  const p = new Chess('8/P7/8/8/8/8/6k1/4K3 w - - 0 1'); p.move({ from: 'a7', to: 'a8', promotion: 'q' });
  assert.strictEqual(JSON.stringify(E.uciMovesFromHistory(p.history({ verbose: true }))), JSON.stringify(['a7a8q']));
  assert.strictEqual(E.positionCommand(E.START_FEN, ['e2e4']), 'position startpos moves e2e4');
});

test('score helpers: side-to-move -> White perspective, formatting, win percent', () => {
  assert.deepStrictEqual(E.scoreToWhite({ type: 'cp', value: 50 }, 'b'), { type: 'cp', value: -50 });
  assert.strictEqual(E.formatScore({ type: 'cp', value: 34 }), '+0.34');
  assert.strictEqual(E.formatScore({ type: 'cp', value: -120 }), '-1.20');
  assert.strictEqual(E.formatScore({ type: 'mate', value: 3 }), '#3');
  assert.strictEqual(E.formatScore({ type: 'mate', value: -2 }), '-#2');
  assert.ok(Math.abs(E.whitePercent({ type: 'cp', value: 0 }) - 50) < 0.01);
  assert.ok(E.whitePercent({ type: 'cp', value: 300 }) > 70 && E.whitePercent({ type: 'mate', value: -1 }) === 0);
});

done('engine.js');
