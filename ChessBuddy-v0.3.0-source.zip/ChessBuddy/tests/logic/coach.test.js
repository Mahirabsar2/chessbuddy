const assert = require('assert');
const { test, done } = require('../helpers/mini-test');
const C = require('../../app/src/main/assets/js/coach.js');
console.log('coach.js (provider requests, images, responses, errors)');
const U = text => [{ role: 'user', content: text }];

test('Anthropic request: URL, version header, top-level system, alternating roles, no key in body', () => {
  const r = C.buildRequest({ provider: 'anthropic', baseUrl: 'https://api.anthropic.com/v1/', model: 'claude-sonnet-5-5', system: 'SYS',
    messages: [{ role: 'assistant', content: 'stray' }, { role: 'user', content: 'a' }, { role: 'user', content: 'b' }, { role: 'assistant', content: 'c' }, { role: 'user', content: 'd' }] });
  assert.ok(r.ok); assert.strictEqual(r.url, 'https://api.anthropic.com/v1/messages');
  assert.strictEqual(r.authScheme, 'x-api-key'); assert.strictEqual(r.extraHeaders, 'anthropic-version: 2023-06-01');
  const b = JSON.parse(r.body);
  assert.strictEqual(b.system, 'SYS'); assert.ok(b.max_tokens > 0);
  assert.strictEqual(b.messages.map(m => m.role).join(), 'user,assistant,user'); assert.strictEqual(b.messages[0].content, 'a\n\nb');
  assert.ok(!/api[_-]?key/i.test(r.body));
});
test('Anthropic screenshot: base64 image block first, then the text block, on the last user message only', () => {
  const r = C.buildRequest({ provider: 'anthropic', baseUrl: 'https://api.anthropic.com/v1', model: 'm', system: 's',
    messages: [{ role: 'user', content: 'first' }, { role: 'assistant', content: 'ok' }, { role: 'user', content: 'position' }], images: [{ mediaType: 'image/png', data: 'QUJD' }] });
  const b = JSON.parse(r.body); assert.ok(r.hasImages);
  assert.strictEqual(typeof b.messages[0].content, 'string');
  const last = b.messages[2].content;
  assert.deepStrictEqual(last[0], { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'QUJD' } });
  assert.deepStrictEqual(last[1], { type: 'text', text: 'position' });
});
test('OpenAI-compatible request: bearer, system first, image_url data URL, token parameter by host', () => {
  const o = C.buildRequest({ provider: 'openai', baseUrl: 'https://api.openai.com/v1', model: 'm1', system: 'S', messages: U('hi'), images: [{ mediaType: 'image/png', data: 'QUJD' }] });
  assert.strictEqual(o.url, 'https://api.openai.com/v1/chat/completions'); assert.strictEqual(o.authScheme, 'bearer');
  const b = JSON.parse(o.body);
  assert.strictEqual(b.messages[0].role, 'system'); assert.ok('max_completion_tokens' in b && !('max_tokens' in b));
  assert.deepStrictEqual(b.messages[1].content[1], { type: 'image_url', image_url: { url: 'data:image/png;base64,QUJD' } });
  assert.ok('max_tokens' in JSON.parse(C.buildRequest({ provider: 'openai', baseUrl: 'http://localhost:11434/v1', model: 'llama', messages: U('hi') }).body));
  const n = C.buildRequest({ provider: 'openai', baseUrl: 'https://x.example/v1/chat/completions', model: 'm', tokenParam: 'omit', messages: U('hi') });
  assert.strictEqual(n.url, 'https://x.example/v1/chat/completions'); assert.ok(!('max_tokens' in JSON.parse(n.body)));
});
test('config errors are explicit (missing model, bad URL, unknown provider)', () => {
  assert.strictEqual(C.buildRequest({ provider: 'openai', baseUrl: 'https://a/v1', model: '  ', messages: U('x') }).kind, 'config');
  assert.strictEqual(C.buildRequest({ provider: 'openai', baseUrl: 'ftp://a', model: 'm', messages: U('x') }).kind, 'config');
  assert.strictEqual(C.buildRequest({ provider: 'nope', model: 'm', messages: U('x') }).kind, 'config');
});
test('token-parameter retry only when a 400 names max_completion_tokens', () => {
  assert.strictEqual(C.alternateTokenParam(400, "Unsupported parameter: 'max_tokens' ... Use 'max_completion_tokens' instead.", 'max_tokens'), 'max_completion_tokens');
  assert.strictEqual(C.alternateTokenParam(400, 'something else', 'max_tokens'), null);
  assert.strictEqual(C.alternateTokenParam(500, 'max_completion_tokens', 'max_tokens'), null);
});
test('imageRejected detects vision-less models but not auth/rate errors', () => {
  assert.ok(C.imageRejected(400, '{"error":{"message":"This model does not support image input"}}'));
  assert.ok(C.imageRejected(400, 'unknown variant `image_url`, expected `text`'));
  assert.ok(C.imageRejected(422, 'content must be a string'));
  assert.ok(!C.imageRejected(401, 'invalid x-api-key')); assert.ok(!C.imageRejected(429, 'image rate')); assert.ok(!C.imageRejected(400, 'max_tokens too large'));
});
test('responses: Anthropic blocks, OpenAI string/array content, empty flagged', () => {
  assert.deepStrictEqual(C.parseResponse('anthropic', 200, JSON.stringify({ content: [{ type: 'text', text: 'A' }, { type: 'tool_use' }, { type: 'text', text: 'B' }] })), { ok: true, text: 'A\nB', empty: false });
  assert.strictEqual(C.parseResponse('openai', 200, JSON.stringify({ choices: [{ message: { content: ' hello ' } }] })).text, 'hello');
  assert.strictEqual(C.parseResponse('openai', 200, JSON.stringify({ choices: [{ message: { content: [{ type: 'text', text: 'x' }, { type: 'text', text: 'y' }] } }] })).text, 'xy');
  assert.strictEqual(C.parseResponse('openai', 200, JSON.stringify({ choices: [{ message: { content: '' } }] })).empty, true);
});
test('HTTP errors map to actionable messages with provider text', () => {
  const a = C.parseResponse('anthropic', 401, JSON.stringify({ type: 'error', error: { type: 'authentication_error', message: 'invalid x-api-key' } }));
  assert.ok(!a.ok && a.kind === 'auth' && /Settings/.test(a.message) && /invalid x-api-key/.test(a.message));
  assert.strictEqual(C.parseResponse('openai', 429, '{"error":{"message":"quota"}}').kind, 'ratelimit');
  assert.strictEqual(C.parseResponse('openai', 404, '{"error":{"message":"model not found"}}').kind, 'notfound');
  assert.strictEqual(C.parseResponse('anthropic', 529, '{"error":{"message":"Overloaded"}}').kind, 'server');
  assert.strictEqual(C.parseResponse('openai', 200, '<html>login</html>').kind, 'parse');
  assert.ok(C.parseResponse('openai', 500, 'x'.repeat(5000)).message.length < 600);
});
test('native transport errors are mapped', () => {
  assert.ok(/Settings/.test(C.transportError('nokey').message)); assert.ok(/internet/.test(C.transportError('dns').message));
});
done('coach.js');
