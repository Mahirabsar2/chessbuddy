package com.chessbuddy;
/** Plain-JVM checks for HostPolicy and Json (run by tests/java/run.sh). */
public class PolicyTest {
    static int fails = 0;
    static void eq(String name, Object got, Object want) { if (!String.valueOf(got).equals(String.valueOf(want))) { fails++; System.out.println("FAIL " + name + ": got " + got + " want " + want); } }
    static boolean ok(String url) { return HostPolicy.check(url) == null; }
    public static void main(String[] a) {
        eq("https any host", ok("https://api.anthropic.com/v1/messages"), true);
        eq("http internet blocked", ok("http://api.openai.com/v1"), false);
        eq("http localhost", ok("http://localhost:11434/v1"), true);
        eq("http 192.168", ok("http://192.168.1.20:1234/v1"), true);
        eq("http 10.x", ok("http://10.0.2.2:11434/v1"), true);
        eq("http 172.16", ok("http://172.16.5.4/v1"), true);
        eq("http 172.32 blocked", ok("http://172.32.5.4/v1"), false);
        eq("http public ip blocked", ok("http://8.8.8.8/v1"), false);
        eq("http single label", ok("http://ollama:11434/v1"), true);
        eq("http .local", ok("http://mac.local:11434/v1"), true);
        eq("http ipv6 loopback", ok("http://[::1]:8080/v1"), true);
        eq("lookalike host blocked", ok("http://localhost.evil.com/v1"), false);
        eq("creds in url blocked", ok("https://user:pw@api.example.com/v1"), false);
        eq("ftp blocked", ok("ftp://example.com/x"), false);
        eq("garbage blocked", ok("not a url"), false);
        eq("null blocked", ok(null), false);
        eq("quote basic", Json.quote("a\"b\\c\n\u2028"), "\"a\\\"b\\\\c\\n\\u2028\"");
        eq("quote control", Json.quote("\u0001"), "\"\\u0001\"");
        System.out.println(fails == 0 ? "OK PolicyTest" : "FAILED PolicyTest: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
