package android.content;
public abstract class Context { public static final int MODE_PRIVATE=0; public static final String CLIPBOARD_SERVICE="clipboard", ACTIVITY_SERVICE="activity";
 public abstract SharedPreferences getSharedPreferences(String n,int m); public abstract Object getSystemService(String n);
 public abstract android.content.pm.ApplicationInfo getApplicationInfo(); public abstract java.io.File getFilesDir(); public abstract android.content.pm.PackageManager getPackageManager(); public abstract String getPackageName(); }