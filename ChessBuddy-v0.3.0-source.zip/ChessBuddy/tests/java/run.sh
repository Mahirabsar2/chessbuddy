#!/usr/bin/env bash
# Compiles every app Java class against minimal Android stubs and runs the plain-JVM policy checks. Needs a JDK (or a JRE with jdk.compiler).
set -euo pipefail
cd "$(dirname "$0")/../.."
OUT="$(mktemp -d)"
JAVAC="javac"; command -v javac >/dev/null 2>&1 || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
$JAVAC -source 8 -target 8 -Xlint:-options,-deprecation -d "$OUT" $(find tests/java/stubs -name '*.java') app/src/main/java/com/chessbuddy/*.java tests/java/PolicyTest.java
java -cp "$OUT" com.chessbuddy.PolicyTest
