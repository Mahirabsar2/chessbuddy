// Runs every logic test (pure Node, no browser). Exit code != 0 if anything fails.
const { spawnSync } = require('child_process'), path = require('path'), fs = require('fs');
const dir = path.join(__dirname, 'logic'); let bad = 0;
for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.test.js')).sort()) {
  const r = spawnSync(process.execPath, [path.join(dir, f)], { encoding: 'utf8', timeout: 300000 });
  process.stdout.write(r.stdout); if (r.stderr) process.stderr.write(r.stderr);
  if (r.status !== 0) bad++;
}
console.log(bad ? '\nFAILED test files: ' + bad : '\nAll logic test files passed');
process.exit(bad ? 1 : 0);
