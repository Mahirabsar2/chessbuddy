const path = require('path'), assert = require('assert'), fs = require('fs');
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const { test, done } = require('../helpers/mini-test');
const URL = 'file://' + path.join(__dirname, '..', '..', 'app', 'src', 'main', 'assets', 'index.html');
const SHOTS = process.env.SHOTS_DIR || '/home/claude/work/shots'; fs.mkdirSync(SHOTS, { recursive: true });
let browser;
const MOCK = fs.readFileSync(path.join(__dirname, 'mock-android.js'), 'utf8');

async function open(opts) {
  opts = opts || {};
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  if (opts.mock !== false) await page.addInitScript(MOCK);
  if (opts.pre) await page.addInitScript(opts.pre);
  await page.goto(URL);
  await page.waitForSelector('#lobby');
  page.errors = errors; page.ctx = ctx;
  return page;
}
const hist = page => page.evaluate(() => window.__cb.game.history());
const waitPlies = (page, n, ms) => page.waitForFunction(k => window.__cb.game.history().length >= k, n, { timeout: ms || 8000 });
async function startVsBot(page, bot, color) {
  await page.click('#rowBots'); await page.click('.bot[data-bot="' + bot + '"]');
  await page.click('#psColor button[data-v="' + color + '"]'); await page.click('#psPlay');
  await page.waitForSelector('#gamePage:not([hidden])');
}
const tap = (page, sq) => page.click('#board .sq[data-sq="' + sq + '"]');
const noErrors = page => assert.deepStrictEqual(page.errors, [], 'page errors: ' + page.errors.join(' | '));
const ANTH_OK = text => ({ status: 200, body: JSON.stringify({ content: [{ type: 'text', text }] }) });

(async () => {
  browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
  console.log('UI tests (headless Chromium over file://, mock Android bridge)');

  test('app loads under the strict CSP with no errors; engine handshake completes', async () => {
    const p = await open(); await p.waitForSelector('#enginePill.ok');
    assert.ok(await p.locator('#rowBots').isVisible()); assert.strictEqual(await p.locator('.tab').count(), 4);
    assert.ok(/Stockfish 19/.test(await p.textContent('#engineLabel')));
    await p.screenshot({ path: SHOTS + '/01-lobby.png' }); noErrors(p); await p.ctx.close();
  });

  test('bot list shows categories with Elo; AI Models tab shows real model names', async () => {
    const p = await open(); await p.click('#rowBots');
    assert.strictEqual(await p.locator('.bot[data-bot]').count(), 12);   // 11 bots + custom
    assert.ok((await p.textContent('#botsList')).includes('Intermediate'));
    await p.screenshot({ path: SHOTS + '/02-bots.png' });
    await p.click('#botsTabs button[data-v="llm"]');
    const t = await p.textContent('#botsList');
    ['Claude Sonnet 5.5', 'Claude Haiku 5.5', 'Claude Opus 5.5'].forEach(n => assert.ok(t.includes(n), n));
    assert.ok(!/API ?[AB]/i.test(await p.textContent('body')), 'no generic "API A/B" labels anywhere');
    await p.screenshot({ path: SHOTS + '/03-models.png' }); noErrors(p); await p.ctx.close();
  });

  test('Human (White) vs bot: legal-move hints, move is made, bot replies', async () => {
    const p = await open(); await startVsBot(p, 'marlow', 'w');
    assert.strictEqual(await p.locator('#board .sq').count(), 64); assert.strictEqual(await p.locator('#board svg.pc').count(), 32);
    await tap(p, 'e2'); assert.strictEqual(await p.locator('#board .sq.legal').count(), 2);
    await tap(p, 'e4'); await waitPlies(p, 2);
    assert.strictEqual((await hist(p))[0], 'e4'); noErrors(p);
    await p.waitForFunction(() => !window.__cb.thinking);
    assert.ok(/Your move/.test(await p.textContent('#status'))); await p.ctx.close();
  });

  test('REGRESSION: bot plays the first move when the human is Black (no "illegal move" at game start)', async () => {
    const p = await open(); await startVsBot(p, 'sunny', 'b');
    await waitPlies(p, 1, 6000);
    const h = await hist(p); assert.strictEqual(h.length, 1);
    assert.ok(/^(Nf3|Nc3|a3|a4|b3|b4|c3|c4|d3|d4|e3|e4|f3|f4|g3|g4|h3|h4|Na3|Nh3)$/.test(h[0]), h[0]);
    assert.ok(/Your move/.test(await p.textContent('#status')));
    assert.ok(await p.evaluate(() => window.__cb.ctx.flipped), 'board is flipped for Black');
    noErrors(p); await p.ctx.close();
  });

  test('strength settings reach the engine: Elo limiter >=1320, handicap below, full strength for Stockfish', async () => {
    let p = await open(); await startVsBot(p, 'marlow', 'b'); await waitPlies(p, 1);
    let u = await p.evaluate(() => window.__mock.log.uci);
    assert.ok(u.includes('setoption name UCI_LimitStrength value true') && u.includes('setoption name UCI_Elo value 1500'), 'Marlow 1500: ' + u.join(' | '));
    assert.ok(u.some(l => /^go movetime/.test(l))); await p.ctx.close();
    p = await open(); await startVsBot(p, 'pip', 'b'); await waitPlies(p, 1);
    u = await p.evaluate(() => window.__mock.log.uci);
    assert.ok(u.includes('setoption name UCI_LimitStrength value false') && u.includes('setoption name MultiPV value 6'), 'Pip: ' + u.join(' | '));
    assert.ok(u.some(l => /^go nodes \d+$/.test(l)), 'handicap bots use a node budget'); await p.ctx.close();
    p = await open(); await startVsBot(p, 'stockfish', 'b'); await waitPlies(p, 1);
    u = await p.evaluate(() => window.__mock.log.uci);
    assert.ok(!u.includes('setoption name UCI_LimitStrength value true') && u.some(l => /^go movetime/.test(l)), 'Stockfish full: ' + u.join(' | ')); await p.ctx.close();
    p = await open({ pre: 'window.__pre = 1;' }); await p.evaluate(() => { window.__mock.noUciElo = true; });
    await p.evaluate(() => window.__cb.engine.restart()); await startVsBot(p, 'marlow', 'b'); await waitPlies(p, 1);
    u = await p.evaluate(() => window.__mock.log.uci);
    assert.ok(u.some(l => /^go nodes \d+$/.test(l)) && !u.includes('setoption name UCI_Elo value 1500'), 'engine without UCI_Elo falls back to handicap'); await p.ctx.close();
  });

  test('custom strength slider starts a game against the chosen Elo', async () => {
    const p = await open(); await p.click('#rowBots'); await p.click('.bot[data-bot="custom"]');
    await p.fill('#csElo', '2200'); await p.click('#psColor button[data-v="b"]'); await p.click('#psPlay');
    await waitPlies(p, 1); const u = await p.evaluate(() => window.__mock.log.uci);
    assert.ok(u.includes('setoption name UCI_Elo value 2200')); noErrors(p); await p.ctx.close();
  });

  test('promotion dialog: choose a piece; underpromotion works', async () => {
    const p = await open(); await p.click('#rowFriend');
    await p.click('#tabbar, .tab[data-tab="history"]'); await p.fill('#importText', '8/P6k/8/8/8/8/8/K7 w - - 0 1'); await p.click('#btnImport');
    await p.waitForSelector('#gamePage:not([hidden])');
    await tap(p, 'a7'); await tap(p, 'a8'); await p.waitForSelector('.promo');
    assert.strictEqual(await p.locator('.promo button').count(), 4);
    await p.click('.promo button[data-p="n"]');
    assert.strictEqual((await hist(p))[0], 'a8=N'); noErrors(p); await p.ctx.close();
  });

  test('checkmate (fool\'s mate) ends the game, shows the result card and saves it to the archive', async () => {
    const p = await open(); await p.click('#rowFriend');
    for (const [a, b] of [['f2', 'f3'], ['e7', 'e5'], ['g2', 'g4'], ['d8', 'h4']]) { await tap(p, a); await tap(p, b); }
    await p.waitForSelector('#boardOverlay:not([hidden])');
    assert.ok(/Checkmate/.test(await p.textContent('#boardOverlay'))); await p.screenshot({ path: SHOTS + '/05-gameover.png' });
    await p.click('#ovClose'); await p.click('.tab[data-tab="history"]');
    assert.ok(/Checkmate — Black wins/.test(await p.textContent('#historyList'))); noErrors(p); await p.ctx.close();
  });

  test('undo takes back the bot reply and the human move; flip works', async () => {
    const p = await open(); await startVsBot(p, 'maple', 'w'); await tap(p, 'd2'); await tap(p, 'd4'); await waitPlies(p, 2);
    await p.waitForFunction(() => !window.__cb.thinking); await p.click('#btnUndo');
    assert.strictEqual((await hist(p)).length, 0);
    await p.click('#btnFlip'); assert.ok(await p.evaluate(() => window.__cb.ctx.flipped)); noErrors(p); await p.ctx.close();
  });

  test('hint highlights a legal move for the human', async () => {
    const p = await open(); await startVsBot(p, 'maple', 'w'); await p.click('#btnHint');
    await p.waitForSelector('#board .sq.hint'); assert.strictEqual(await p.locator('#board .sq.hint').count(), 2); noErrors(p); await p.ctx.close();
  });

  test('AI vs AI between two bots plays on its own, pauses and resumes', async () => {
    const p = await open(); await p.click('#rowAvA'); await p.selectOption('#avW', 'sf:atlas'); await p.selectOption('#avB', 'sf:pip'); await p.click('#avGo');
    await waitPlies(p, 4, 10000); await p.click('#btnPause'); const n = (await hist(p)).length; await p.waitForTimeout(1200);
    assert.ok((await hist(p)).length <= n + 1, 'paused'); await p.click('#btnPause'); await waitPlies(p, n + 2, 8000); noErrors(p); await p.ctx.close();
  });

  test('engine crash shows a clear error; Retry restarts the engine and the bot moves', async () => {
    const p = await open(); await p.evaluate(() => { window.__mock.crashNextGo = true; }); await startVsBot(p, 'marlow', 'b');
    await p.waitForSelector('#engineBanner:not([hidden])'); assert.ok(/CRITICAL ERROR/.test(await p.textContent('#engineBannerText')));
    await p.click('#btnRetryEngine'); await waitPlies(p, 1, 8000); await p.ctx.close();
  });

  test('missing Stockfish (start failure) is reported honestly; no fake moves are played', async () => {
    const p = await open({ pre: 'window.__x=1' }); await p.evaluate(() => { window.__mock.failStart = 'libstockfish.so not found'; return window.__cb.engine.restart().catch(() => {}); });
    await startVsBot(p, 'marlow', 'b'); await p.waitForSelector('#engineBanner:not([hidden])');
    assert.ok(/not found/.test(await p.textContent('#engineBannerText'))); await p.waitForTimeout(500); assert.strictEqual((await hist(p)).length, 0); await p.ctx.close();
  });

  test('export: FEN and PGN (with headers) are copied through the native clipboard', async () => {
    const p = await open(); await startVsBot(p, 'maple', 'w'); await tap(p, 'e2'); await tap(p, 'e4'); await waitPlies(p, 2); await p.waitForFunction(() => !window.__cb.thinking);
    await p.click('#btnMenu'); await p.click('[data-m="fen"]'); await p.click('#btnMenu'); await p.click('[data-m="pgn"]');
    const clip = await p.evaluate(() => window.__mock.log.clip);
    assert.ok(/ [wb] /.test(clip[0]) && clip[0].split('/').length === 8, clip[0]);
    assert.ok(/\[Event "ChessBuddy game"\]/.test(clip[1]) && /\[White "Player"\]/.test(clip[1]) && /\[Black "Maple \(700\)"\]/.test(clip[1]) && /1\. e4/.test(clip[1]), clip[1]);
    noErrors(p); await p.ctx.close();
  });

  test('board screenshot renders to a real PNG with pieces', async () => {
    const p = await open(); await startVsBot(p, 'maple', 'w'); await tap(p, 'e2'); await tap(p, 'e4'); await waitPlies(p, 2);
    const r = await p.evaluate(async () => { const s = await window.CBSnapshot.render(window.__cb.game, { flipped: false, last: { from: 'e2', to: 'e4' } }); return { sig: atob(s.data.slice(0, 12)).slice(1, 4), len: s.data.length, w: s.width }; });
    assert.strictEqual(r.sig, 'PNG'); assert.ok(r.len > 8000 && r.w > 500, JSON.stringify(r));
    const data = await p.evaluate(async () => (await window.CBSnapshot.render(window.__cb.game, { flipped: false, last: { from: 'e2', to: 'e4' } })).data);
    fs.writeFileSync(SHOTS + '/snapshot-for-models.png', Buffer.from(data, 'base64')); noErrors(p); await p.ctx.close();
  });

  test('Coach: Stockfish analysis lines render; model reply shows the real model name', async () => {
    const p = await open(); await startVsBot(p, 'maple', 'w'); await tap(p, 'e2'); await tap(p, 'e4'); await waitPlies(p, 2); await p.waitForFunction(() => !window.__cb.thinking);
    await p.evaluate(() => { window.__mock.keys['k_anthropic_api_anthropic_com'] = 'sk-ant-TESTKEY1234'; window.__mock.httpResponder = () => ({ status: 200, body: JSON.stringify({ content: [{ type: 'text', text: '**Verdict:** roughly equal.\n\n- Develop the knight\n- Castle early' }] }) }); });
    await p.click('.tab[data-tab="coach"]'); await p.click('#btnAnalyze'); await p.waitForSelector('#coachLines .line');
    assert.ok((await p.locator('#coachLines .line').count()) >= 1);
    await p.click('#chips [data-q="explain"]'); await p.waitForSelector('.msg.ai');
    assert.strictEqual((await p.textContent('.msg.ai .who')).trim(), 'Claude Sonnet 5.5');
    assert.ok(/Develop the knight/.test(await p.textContent('.msg.ai')));
    const req = await p.evaluate(() => window.__mock.log.http[0]);
    assert.strictEqual(req.url, 'https://api.anthropic.com/v1/messages'); assert.strictEqual(req.scheme, 'x-api-key'); assert.strictEqual(req.extra, 'anthropic-version: 2023-06-01');
    assert.strictEqual(req.keyId, 'k_anthropic_api_anthropic_com'); assert.ok(!/TESTKEY/.test(req.raw), 'API key never travels through JS/request body');
    const last = req.body.messages[req.body.messages.length - 1].content;
    assert.strictEqual(last[0].type, 'image'); assert.ok(last[0].source.data.startsWith('iVBORw0KGgo'), 'PNG screenshot attached');
    const txt = last[1].text;
    ['=== BOARD ===', '=== EVERY MOVE PLAYED (explained) ===', '1. e4 — White pawn e2→e4', '=== COMPUTED TACTICAL FACTS ===', '=== STOCKFISH ===', '=== LEGAL MOVES (SAN) ===', '=== QUESTION ==='].forEach(s => assert.ok(txt.includes(s), s));
    assert.ok(/GROUND TRUTH/.test(req.body.system)); await p.screenshot({ path: SHOTS + '/06-coach.png' }); noErrors(p); await p.ctx.close();
  });

  test('Coach errors are clear: 401 -> key message with Settings button; no key -> setup hint', async () => {
    const p = await open(); await p.click('.tab[data-tab="coach"]');
    assert.ok(await p.locator('#coachSetupHint').isVisible()); await p.fill('#coachInput', 'hello'); await p.click('#btnAsk');
    assert.ok(/API key/.test(await p.textContent('.bubble.err')));
    await p.evaluate(() => { window.__mock.keys['k_anthropic_api_anthropic_com'] = 'bad'; window.__mock.httpResponder = () => ({ status: 401, body: '{"type":"error","error":{"type":"authentication_error","message":"invalid x-api-key"}}' }); });
    await p.fill('#coachInput', 'again'); await p.click('#btnAsk'); await p.waitForFunction(() => document.querySelectorAll('.bubble.err').length >= 2);
    const t = await p.textContent('#chat'); assert.ok(/rejected your API key/.test(t) && /invalid x-api-key/.test(t)); noErrors(p); await p.ctx.close();
  });

  test('vision-less model: image rejected -> automatic retry as text only, remembered', async () => {
    const p = await open(); await p.evaluate(() => { window.__mock.keys['k_anthropic_api_anthropic_com'] = 'k';
      window.__mock.httpResponder = req => JSON.stringify(req.body).includes('"image"') ? { status: 400, body: '{"error":{"message":"This model does not support image input"}}' } : { status: 200, body: JSON.stringify({ content: [{ type: 'text', text: 'text-only answer' }] }) }; });
    await p.click('.tab[data-tab="coach"]'); await p.fill('#coachInput', 'what now?'); await p.click('#btnAsk'); await p.waitForSelector('.msg.ai');
    assert.ok(/text-only answer/.test(await p.textContent('.msg.ai'))); const reqs = await p.evaluate(() => window.__mock.log.http);
    assert.strictEqual(reqs.length, 2); assert.ok(!JSON.stringify(reqs[1].body).includes('"image"'));
    assert.strictEqual(await p.evaluate(() => window.__cb.settings().models[0].vision), false); noErrors(p); await p.ctx.close();
  });

  test('AI MODEL AS PLAYER: Claude plays White; first move accepted; reply shown; retry after an illegal reply includes the rejection', async () => {
    const p = await open(); await p.evaluate(() => { window.__mock.keys['k_anthropic_api_anthropic_com'] = 'k'; let n = 0;
      window.__mock.httpResponder = req => { n++; const u = req.body.messages[req.body.messages.length - 1].content; const text = (Array.isArray(u) ? u[u.length - 1].text : u);
        if (n === 1) return { status: 200, body: JSON.stringify({ content: [{ type: 'text', text: 'MOVE: Ke2\nWHY: bold king walk' }] }) };
        return { status: 200, body: JSON.stringify({ content: [{ type: 'text', text: 'MOVE: e4\nWHY: Take the centre.' }] }) }; }; });
    await p.click('#rowModels'); await p.click('.bot[data-model="m_sonnet"]'); await p.click('#psColor button[data-v="b"]'); await p.click('#psPlay');
    await waitPlies(p, 1, 8000); assert.strictEqual((await hist(p))[0], 'e4');
    const reqs = await p.evaluate(() => window.__mock.log.http); assert.strictEqual(reqs.length, 2);
    const second = reqs[1].body.messages[0].content; const sText = second[second.length - 1].text;
    assert.ok(/REJECTED/.test(sText) && /Ke2/.test(sText), 'retry prompt explains the rejection');
    assert.ok(/MOVE: <your move in SAN>/.test(reqs[0].body.system) && /playing White/.test(reqs[0].body.system));
    assert.ok(/Take the centre/.test(await p.textContent('#caption'))); assert.ok(/Claude Sonnet 5.5/.test(await p.textContent('#topName')));
    await p.screenshot({ path: SHOTS + '/04-game-llm.png' }); noErrors(p); await p.ctx.close();
  });

  test('AI model that never gives a legal move: failure card with choices; "Let Stockfish move" continues the game', async () => {
    const p = await open(); await p.evaluate(() => { window.__mock.keys['k_anthropic_api_anthropic_com'] = 'k'; window.__mock.httpResponder = () => ({ status: 200, body: JSON.stringify({ content: [{ type: 'text', text: 'I think the position is balanced.' }] }) }); });
    await p.click('#rowModels'); await p.click('.bot[data-model="m_haiku"]'); await p.click('#psColor button[data-v="b"]'); await p.click('#psPlay');
    await p.waitForSelector('#lfSf', { timeout: 8000 }); assert.ok(/Claude Haiku 5.5 couldn’t move/.test(await p.textContent('#boardOverlay')));
    assert.strictEqual((await p.evaluate(() => window.__mock.log.http)).length, 3, '3 attempts'); assert.strictEqual((await hist(p)).length, 0);
    await p.click('#lfSf'); await waitPlies(p, 1, 6000); noErrors(p); await p.ctx.close();
  });

  test('AI model without a key: opponent sheet asks for the key instead of failing mid-game', async () => {
    const p = await open(); await p.click('#rowModels'); await p.click('.bot[data-model="m_opus"]');
    assert.ok(/Add API key/.test(await p.textContent('#psPlay'))); await p.click('#psPlay'); await p.waitForSelector('#mdSave'); assert.ok(/Claude Opus 5.5/.test(await p.textContent('#modalCard'))); noErrors(p); await p.ctx.close();
  });

  test('Settings: add an OpenAI-compatible model with a key; pretty name; key stored natively under a shared key id; test connection', async () => {
    const p = await open(); await p.click('.tab[data-tab="settings"]'); await p.click('#btnAddModel');
    await p.click('#mdProvider button[data-v="openai"]'); await p.fill('#mdModel', 'gpt-4o-mini'); await p.fill('#mdKey', 'sk-testkey-9876');
    await p.evaluate(() => { window.__mock.httpResponder = () => ({ status: 200, body: JSON.stringify({ choices: [{ message: { content: 'OK' } }] }) }); });
    await p.click('#mdTest'); await p.waitForFunction(() => /Connected/.test(document.getElementById('mdMsg').textContent));
    const r = await p.evaluate(() => window.__mock.log.http[0]); assert.strictEqual(r.url, 'https://api.openai.com/v1/chat/completions'); assert.strictEqual(r.scheme, 'bearer');
    assert.ok('max_completion_tokens' in r.body); await p.click('#mdSave');
    assert.ok((await p.textContent('#modelList')).includes('GPT-4o Mini')); assert.strictEqual(await p.evaluate(() => window.__mock.keys['k_openai_api_openai_com']), 'sk-testkey-9876');
    await p.screenshot({ path: SHOTS + '/07-settings.png', fullPage: false }); noErrors(p); await p.ctx.close();
  });

  test('Game review classifies every move with Stockfish and the explanation request carries the table', async () => {
    const p = await open(); await p.evaluate(() => { window.__mock.keys['k_anthropic_api_anthropic_com'] = 'k'; window.__mock.thinkMs = 5; window.__mock.httpResponder = () => ({ status: 200, body: JSON.stringify({ content: [{ type: 'text', text: 'Opening: fine. Middlegame: fine.' }] }) }); });
    await p.click('#rowFriend'); for (const [a, b] of [['e2', 'e4'], ['e7', 'e5'], ['g1', 'f3'], ['b8', 'c6']]) { await tap(p, a); await tap(p, b); }
    await p.click('.tab[data-tab="coach"]'); await p.click('#btnReview'); await p.waitForSelector('#reviewBox:not([hidden])', { timeout: 15000 });
    assert.ok((await p.locator('#reviewBox .rv').count()) === 4); assert.ok(/accuracy/.test(await p.textContent('#reviewBox')));
    await p.click('#chips [data-q="review"]'); await p.waitForSelector('.msg.ai', { timeout: 15000 });
    const body = await p.evaluate(() => JSON.stringify(window.__mock.log.http[0].body)); assert.ok(/STOCKFISH GAME REVIEW TABLE/.test(body) && /Summary: White accuracy/.test(body)); await p.screenshot({ path: SHOTS + '/08-review.png' }); noErrors(p); await p.ctx.close();
  });

  test('game state survives an app restart (resume card); archive replay works', async () => {
    const p = await open(); await startVsBot(p, 'maple', 'w'); await tap(p, 'e2'); await tap(p, 'e4'); await waitPlies(p, 2); await p.waitForFunction(() => !window.__cb.thinking);
    await p.reload(); await p.waitForSelector('#resumeCard:not([hidden])'); assert.ok(/2 moves/.test(await p.textContent('#resumeText')));
    await p.click('#btnResume'); assert.strictEqual((await hist(p)).length, 2); await p.screenshot({ path: SHOTS + '/09-game.png' });
    await p.click('#btnMenu'); await p.click('[data-m="resign"]'); await p.click('#cdOk'); await p.waitForSelector('#ovNew');
    await p.click('#ovClose'); await p.click('.tab[data-tab="history"]'); await p.click('.hitem'); await p.click('[data-g="replay"]');
    await p.click('#rplFirst'); assert.ok(/Start position/.test(await p.textContent('#rplInfo'))); await p.click('#rplNext'); assert.ok(/e4/.test(await p.textContent('#rplInfo'))); noErrors(p); await p.ctx.close();
  });

  test('Android back button handler closes sheets, then leaves the game, then the tab', async () => {
    const p = await open(); await startVsBot(p, 'maple', 'w'); await p.click('#btnMenu'); assert.strictEqual(await p.evaluate(() => window.cbBack()), true);
    assert.ok(await p.locator('#modal').isHidden()); assert.strictEqual(await p.evaluate(() => window.cbBack()), true); assert.ok(await p.locator('#lobby').isVisible());
    assert.strictEqual(await p.evaluate(() => window.cbBack()), false, 'lobby: let the app exit'); await p.ctx.close();
  });

  test('plain browser (no Android bridge): honest message, no fake engine', async () => {
    const p = await open({ mock: false }); await p.waitForFunction(() => /error/i.test(document.getElementById('engineLabel').textContent));
    await p.click('#rowFriend'); assert.ok(await p.locator('#gamePage').isVisible()); noErrors(p); await p.ctx.close();
  });

  await require('../helpers/mini-test').done('UI');
  await browser.close();
})();
