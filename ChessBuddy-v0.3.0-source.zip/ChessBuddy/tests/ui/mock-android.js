// TEST-ONLY stand-in for the Android bridge (NativeBridge.java). Injected before the app loads.
// The "engine" below only speaks UCI so the UI flow can be exercised; it is NOT Stockfish and is never packaged.
(function () {
  const log = { uci: [], http: [], clip: [], share: [], keepOn: [] };
  const M = window.__mock = { log, keys: {}, httpResponder: null, thinkMs: 20, crashNextGo: false, failStart: null, noUciElo: false };
  let g = null, timer = null, pending = null, alive = false;
  const emit = arr => setTimeout(() => window.__cbNative && window.__cbNative.engineLines(arr), 0);
  const OPTS = ['id name Stockfish 19 (mock UCI peer)', 'id author test',
    'option name Threads type spin default 1 min 1 max 1024', 'option name Hash type spin default 16 min 1 max 33554432', 'option name Clear Hash type button',
    'option name MultiPV type spin default 1 min 1 max 256', 'option name Skill Level type spin default 20 min 0 max 20', 'option name Move Overhead type spin default 10 min 0 max 5000',
    'option name UCI_LimitStrength type check default false', 'option name UCI_Elo type spin default 1320 min 1320 max 3190'];
  const val = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
  const mat = (c, color) => { let s = 0; c.board().forEach(r => r.forEach(q => { if (q) s += (q.color === color ? 1 : -1) * val[q.type]; })); return s; };
  let mpv = 1;
  function setPosition(line) {
    const C = window.ChessJS.Chess, t = line.split(' '), mi = t.indexOf('moves');
    const head = mi < 0 ? t.slice(1) : t.slice(1, mi);
    g = head[0] === 'startpos' ? new C() : new C(head.slice(1).join(' '));
    (mi < 0 ? [] : t.slice(mi + 1)).forEach(u => { g.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }); });
  }
  function search() {
    const side = g.turn(), moves = g.moves({ verbose: true });
    if (!moves.length) return ['bestmove (none)'];
    const scored = moves.map(m => { g.move(m); const s = mat(g, side) * 100 + Math.floor(Math.random() * 15); g.undo(); return { m, s }; }).sort((a, b) => b.s - a.s);
    const out = scored.slice(0, mpv).map((x, i) => 'info depth 6 seldepth 8 multipv ' + (i + 1) + ' score cp ' + x.s + ' nodes 500 nps 100000 time 5 pv ' + x.m.from + x.m.to + (x.m.promotion || ''));
    out.push('bestmove ' + scored[0].m.from + scored[0].m.to + (scored[0].m.promotion || ''));
    return out;
  }
  window.Android = {
    engineStart() {
      if (M.failStart) return JSON.stringify({ ok: false, error: M.failStart });
      alive = true; return JSON.stringify({ ok: true, path: '/mock/libstockfish.so' });
    },
    engineSend(line) {
      log.uci.push(line);
      if (!alive) return;
      const w = line.split(' ');
      if (line === 'uci') emit(OPTS.filter(o => !(M.noUciElo && /UCI_Elo|UCI_LimitStrength/.test(o))).concat(['uciok']));
      else if (line === 'isready') emit(['readyok']);
      else if (w[0] === 'setoption') { const m = /name (.+?) value (.+)$/.exec(line); if (m && m[1] === 'MultiPV') mpv = +m[2]; }
      else if (w[0] === 'position') setPosition(line);
      else if (w[0] === 'go') {
        if (M.crashNextGo) { M.crashNextGo = false; emit(['info string CRITICAL ERROR mock crash']); setTimeout(() => window.__cbNative.engineExit(1, 'Engine process exited'), 5); alive = false; return; }
        const ms = w[1] === 'movetime' ? Math.min(+w[2], M.thinkMs) : M.thinkMs;
        pending = () => { pending = null; emit(search()); };
        timer = setTimeout(() => pending && pending(), ms);
      } else if (line === 'stop') { if (pending) { clearTimeout(timer); const p = pending; setTimeout(p, 2); } }
    },
    engineStop() { alive = false; clearTimeout(timer); pending = null; },
    httpPost(id, keyId, url, scheme, extra, body) {
      const req = { id, keyId, url, scheme, extra, body: JSON.parse(body), raw: body };
      log.http.push(req);
      const reply = (M.httpResponder ? M.httpResponder(req, log.http.length) : null) || { status: 200, body: JSON.stringify({ content: [{ type: 'text', text: 'ok' }] }) };
      setTimeout(() => window.__cbNative.httpResult(id, reply.status || 0, reply.body || '', reply.kind || '', reply.message || ''), reply.delay || 15);
    },
    httpCancel(id) {}, hasKey(k) { return !!M.keys[k]; }, keyHint(k) { return M.keys[k] ? M.keys[k].slice(-4) : ''; },
    setKey(k, v) { if (!v || v.length > 512) return false; M.keys[k] = v; return true; }, clearKey(k) { delete M.keys[k]; return true; }, secureStorage() { return true; },
    copyText(t) { log.clip.push(t); return true; }, shareText(title, t) { log.share.push(t); return true; }, toast() {}, keepScreenOn(b) { log.keepOn.push(b); },
    deviceInfo() { return JSON.stringify({ cores: 8, memMb: 8000, abi: 'arm64-v8a', sdk: 34, version: '0.2.0-test', versionCode: 1002 }); }
  };
})();
