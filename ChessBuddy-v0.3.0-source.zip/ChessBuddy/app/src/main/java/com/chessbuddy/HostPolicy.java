package com.chessbuddy;

import java.net.URI;
import java.util.Locale;

/** Decides which API URLs the app may talk to. Pure Java (no Android classes) so it is unit-testable on a JVM. */
final class HostPolicy {
    private HostPolicy() { }

    /** Returns null when the URL may be used, otherwise a user-facing reason. */
    static String check(String url) {
        if (url == null || url.length() == 0 || url.length() > 2048) return "The API URL is missing or too long.";
        URI u;
        try { u = new URI(url.trim()); } catch (Exception e) { return "The API URL is not valid."; }
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        String host = u.getHost();
        if (host == null || host.length() == 0) return "The API URL has no host name.";
        if (u.getUserInfo() != null) return "URLs with embedded credentials are not allowed.";
        if (scheme.equals("https")) return null;
        if (scheme.equals("http")) {
            return isLocalHost(host) ? null
                : "Plain http:// is only allowed for local servers (localhost, 192.168.x.x, 10.x.x.x). Use https:// for internet providers so your API key is encrypted.";
        }
        return "The API URL must start with https:// (or http:// for a local server).";
    }

    /** True for loopback, private (RFC 1918), link-local and local-network host names. No DNS lookup is made. */
    static boolean isLocalHost(String rawHost) {
        String h = rawHost.toLowerCase(Locale.ROOT);
        if (h.startsWith("[") && h.endsWith("]")) h = h.substring(1, h.length() - 1);
        if (h.equals("localhost") || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".lan")
            || h.endsWith(".home.arpa") || h.endsWith(".internal")) return true;
        if (h.indexOf(':') >= 0) {                                   // IPv6 literal
            return h.equals("::1") || h.startsWith("fc") || h.startsWith("fd")
                || h.startsWith("fe8") || h.startsWith("fe9") || h.startsWith("fea") || h.startsWith("feb");
        }
        String[] p = h.split("\\.", -1);
        if (p.length == 4) {
            int[] o = new int[4];
            for (int i = 0; i < 4; i++) {
                if (p[i].length() == 0 || p[i].length() > 3) return false;
                try { o[i] = Integer.parseInt(p[i]); } catch (NumberFormatException e) { return false; }
                if (o[i] < 0 || o[i] > 255) return false;
            }
            return o[0] == 127 || o[0] == 10 || (o[0] == 192 && o[1] == 168) || (o[0] == 172 && o[1] >= 16 && o[1] <= 31) || (o[0] == 169 && o[1] == 254);
        }
        return h.indexOf('.') < 0;                                    // single-label names such as "ollama" or "mypc"
    }
}
