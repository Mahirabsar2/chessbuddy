package com.chessbuddy;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/** Runs the Stockfish executable and exchanges UCI lines with it. Pure Java (API 23 safe: no Process.isAlive/destroyForcibly). */
final class EngineProcess {
    interface Listener { void onLine(String line); void onExit(int code, String message); }

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private final String exePath;
    private final File workDir;
    private final Listener listener;
    private volatile Process process;
    private volatile OutputStream stdin;
    private final ExecutorService writer = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable r) { Thread t = new Thread(r, "stockfish-writer"); t.setDaemon(true); return t; }
    });

    EngineProcess(String exePath, File workDir, Listener listener) { this.exePath = exePath; this.workDir = workDir; this.listener = listener; }

    /** Returns null on success, otherwise a user-facing error. */
    synchronized String start() {
        if (process != null) return null;
        File f = new File(exePath);
        if (!f.exists()) return "The Stockfish binary is missing from this build (" + exePath + "). Rebuild the APK with the GitHub workflow.";
        if (!f.canExecute() && !f.setExecutable(true)) return "The Stockfish binary is not executable: " + exePath;
        ProcessBuilder pb = new ProcessBuilder(exePath);
        if (workDir != null) pb.directory(workDir);
        pb.redirectErrorStream(true);
        final Process p;
        try { p = pb.start(); } catch (IOException e) { return "Could not start Stockfish: " + e.getMessage(); }
        process = p;
        stdin = p.getOutputStream();
        final InputStream in = p.getInputStream();
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    BufferedReader r = new BufferedReader(new InputStreamReader(in, UTF8));
                    String line;
                    while ((line = r.readLine()) != null) listener.onLine(line);
                } catch (IOException ignored) { /* stream closed */ }
                int code = -1;
                try { code = p.waitFor(); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                synchronized (EngineProcess.this) {
                    if (process == p) {                  // genuine crash or exit (stop() clears `process` first)
                        process = null;
                        listener.onExit(code, "Stockfish stopped unexpectedly (exit code " + code + ").");
                    }
                }
            }
        }, "stockfish-reader");
        t.setDaemon(true);
        t.start();
        return null;
    }

    void send(String line) {
        if (line == null) return;
        final byte[] data = (line.replace('\r', ' ').replace('\n', ' ').trim() + "\n").getBytes(UTF8);
        final OutputStream os = stdin;
        if (os == null) return;
        writer.execute(new Runnable() {
            @Override public void run() { try { os.write(data); os.flush(); } catch (IOException ignored) { /* reader reports the exit */ } }
        });
    }

    synchronized void stop() {
        final Process p = process;
        final OutputStream os = stdin;
        process = null; stdin = null;
        if (p == null) return;
        writer.execute(new Runnable() { @Override public void run() { try { if (os != null) { os.write("quit\n".getBytes(UTF8)); os.flush(); } } catch (IOException ignored) { } } });
        Thread killer = new Thread(new Runnable() {
            @Override public void run() { try { Thread.sleep(300); } catch (InterruptedException ignored) { } p.destroy(); }
        }, "stockfish-killer");
        killer.setDaemon(true);
        killer.start();
    }

    void shutdown() { stop(); writer.shutdown(); }

    boolean isRunning() { return process != null; }
}
