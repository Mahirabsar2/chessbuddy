package com.chessbuddy;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Stores API keys in app-private storage, encrypted with an AES-GCM key held in the Android Keystore.
 * If the Keystore is unavailable on a device, the key is stored unencrypted (still private to the app) and
 * secureStorage() reports false. Keys are never returned to JavaScript; only a 4-character hint is.
 */
final class SecretStore {
    private static final String PREFS = "chessbuddy_secrets";
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final String ALIAS = "chessbuddy_wrap_v1";
    private final SharedPreferences prefs;

    SecretStore(Context c) { prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static boolean validId(String id) { return id != null && id.matches("[a-z0-9_]{1,80}"); }

    synchronized boolean set(String id, String key) {
        if (!validId(id) || key == null) return false;
        String k = key.trim();
        if (k.length() == 0 || k.length() > 512 || k.indexOf('\n') >= 0 || k.indexOf('\r') >= 0) return false;
        String enc = encrypt(k);
        prefs.edit().putString(id, enc != null ? "e:" + enc : "p:" + k).commit();
        return true;
    }

    synchronized String get(String id) {
        if (!validId(id)) return null;
        String v = prefs.getString(id, null);
        if (v == null || v.length() < 3) return null;
        if (v.startsWith("p:")) return v.substring(2);
        return v.startsWith("e:") ? decrypt(v.substring(2)) : null;
    }

    synchronized boolean has(String id) { return get(id) != null; }

    synchronized void clear(String id) { if (validId(id)) prefs.edit().remove(id).commit(); }

    synchronized String hint(String id) {
        String k = get(id);
        return k == null ? "" : (k.length() <= 4 ? "" : k.substring(k.length() - 4));
    }

    boolean secureStorage() { try { return key() != null; } catch (Exception e) { return false; } }

    private SecretKey key() throws GeneralSecurityException, IOException {
        KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    private String encrypt(String plain) {
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = c.getIV();
            byte[] ct = c.doFinal(plain.getBytes("UTF-8"));
            return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
        } catch (Exception e) { return null; }
    }

    private String decrypt(String stored) {
        try {
            int i = stored.indexOf(':');
            if (i <= 0) return null;
            byte[] iv = Base64.decode(stored.substring(0, i), Base64.NO_WRAP);
            byte[] ct = Base64.decode(stored.substring(i + 1), Base64.NO_WRAP);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(c.doFinal(ct), "UTF-8");
        } catch (Exception e) { return null; }
    }
}
