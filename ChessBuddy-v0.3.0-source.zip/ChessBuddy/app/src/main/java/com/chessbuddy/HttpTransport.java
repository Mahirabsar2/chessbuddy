package com.chessbuddy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import javax.net.ssl.SSLException;

/** One JSON POST with an API key header. Pure Java. Never logs headers, never follows redirects (the key must not leak). */
final class HttpTransport {
    private HttpTransport() { }

    static final Charset UTF8 = Charset.forName("UTF-8");

    static final class Result {
        final int status; final String body; final String kind; final String message;
        Result(int status, String body, String kind, String message) { this.status = status; this.body = body; this.kind = kind; this.message = message; }
    }

    static final class CancelToken {
        private volatile boolean cancelled;
        private volatile HttpURLConnection conn;
        void cancel() { cancelled = true; HttpURLConnection c = conn; if (c != null) c.disconnect(); }
        boolean isCancelled() { return cancelled; }
    }

    private static final class TooLarge extends IOException { }

    static Result post(String url, String authName, String authValue, String extraHeaders, String body,
                       int connectMs, int readMs, int maxBytes, CancelToken tok) {
        HttpURLConnection c = null;
        String host = "the server";
        try {
            URL u = new URL(url);
            host = u.getHost();
            c = (HttpURLConnection) u.openConnection();
            tok.conn = c;
            if (tok.isCancelled()) return new Result(0, "", "cancelled", "Cancelled.");
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod("POST");
            c.setConnectTimeout(connectMs);
            c.setReadTimeout(readMs);
            c.setDoOutput(true);
            c.setUseCaches(false);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "ChessBuddy-Android");
            applyExtraHeaders(c, extraHeaders);
            if (authName != null && authValue != null) c.setRequestProperty(authName, authValue);
            byte[] data = body.getBytes(UTF8);
            c.setFixedLengthStreamingMode(data.length);
            OutputStream os = c.getOutputStream();
            try { os.write(data); } finally { os.close(); }
            int status = c.getResponseCode();
            if (status >= 300 && status < 400) {
                String loc = c.getHeaderField("Location");
                return new Result(status, "", "redirect", "The server redirected the request (HTTP " + status + ")"
                    + (loc != null ? " to " + loc : "") + ". Redirects are not followed so your API key is never sent elsewhere; update the base URL.");
            }
            InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = in == null ? "" : readCapped(in, maxBytes);
            return new Result(status, text, "", "");
        } catch (TooLarge e) {
            return new Result(0, "", "toolarge", "The response was larger than " + (maxBytes / 1024) + " KB and was dropped.");
        } catch (UnknownHostException e) {
            return fail(tok, "dns", "Could not resolve " + host + ". Check your internet connection and the base URL.");
        } catch (SocketTimeoutException e) {
            return fail(tok, "timeout", "The request to " + host + " timed out. Check your connection and try again.");
        } catch (SSLException e) {
            return fail(tok, "ssl", "Secure connection to " + host + " failed (" + safe(e.getMessage()) + ").");
        } catch (java.net.ConnectException e) {
            return fail(tok, "connect", "Could not connect to " + host + " (" + safe(e.getMessage()) + ").");
        } catch (IOException e) {
            return fail(tok, "io", "Network error talking to " + host + ": " + safe(e.getMessage()));
        } catch (RuntimeException e) {
            return fail(tok, "io", "Request failed: " + safe(e.getMessage()));
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static Result fail(CancelToken tok, String kind, String msg) {
        return tok.isCancelled() ? new Result(0, "", "cancelled", "Cancelled.") : new Result(0, "", kind, msg);
    }

    private static String safe(String s) { return s == null ? "no details" : (s.length() > 160 ? s.substring(0, 160) : s); }

    private static void applyExtraHeaders(HttpURLConnection c, String extra) {
        if (extra == null || extra.length() == 0) return;
        for (String line : extra.split("\n")) {
            int i = line.indexOf(':');
            if (i <= 0) continue;
            String name = line.substring(0, i).trim(), value = line.substring(i + 1).trim();
            if (name.matches("[A-Za-z0-9-]{1,64}") && value.length() <= 512 && value.indexOf('\r') < 0 && value.indexOf('\n') < 0) c.setRequestProperty(name, value);
        }
    }

    private static String readCapped(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(8192);
        byte[] buf = new byte[8192];
        try {
            int n;
            while ((n = in.read(buf)) > 0) {
                if (out.size() + n > max) throw new TooLarge();
                out.write(buf, 0, n);
            }
        } finally { in.close(); }
        return new String(out.toByteArray(), UTF8);
    }
}
