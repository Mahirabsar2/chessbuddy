/* ChessBuddy provider layer (pure functions; no DOM, no network).
 * Builds requests for Anthropic's Messages API and OpenAI-compatible Chat Completions (with optional
 * board screenshots), parses responses, and maps every failure to a clear message.
 * The HTTP call itself, with the stored API key, happens natively (native.js / NativeBridge.java). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBCoach = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  var PROVIDERS = {
    anthropic: { id: 'anthropic', label: 'Anthropic (Claude)', baseUrl: 'https://api.anthropic.com/v1', authScheme: 'x-api-key',
      suggested: ['claude-sonnet-5-5', 'claude-haiku-5-5', 'claude-opus-5-5'] },
    openai: { id: 'openai', label: 'OpenAI-compatible', baseUrl: 'https://api.openai.com/v1', authScheme: 'bearer', suggested: [] }
  };
  var BASE_URL_PRESETS = [
    { label: 'OpenAI', url: 'https://api.openai.com/v1' },
    { label: 'OpenRouter', url: 'https://openrouter.ai/api/v1' },
    { label: 'Groq', url: 'https://api.groq.com/openai/v1' },
    { label: 'Ollama (this device / local)', url: 'http://localhost:11434/v1' },
    { label: 'LM Studio (local)', url: 'http://localhost:1234/v1' }
  ];

  function normalizeBaseUrl(u) { return String(u || '').trim().replace(/\/+$/, ''); }
  function joinUrl(base, path) {
    var b = normalizeBaseUrl(base);
    return /\/(chat\/completions|messages)$/.test(b) ? b : b + path;
  }
  function hostOf(url) { var m = /^[a-z]+:\/\/([^\/:?#]+)/i.exec(url || ''); return m ? m[1].toLowerCase() : ''; }
  function defaultTokenParam(baseUrl) { return hostOf(baseUrl) === 'api.openai.com' ? 'max_completion_tokens' : 'max_tokens'; }

  /** Anthropic needs alternating roles starting with "user": merge neighbours of the same role. */
  function normalizeTurns(messages) {
    var out = [];
    messages.forEach(function (m) {
      if (!m.content) return;
      var last = out[out.length - 1];
      if (last && last.role === m.role) last.content += '\n\n' + m.content;
      else out.push({ role: m.role, content: m.content });
    });
    while (out.length && out[0].role !== 'user') out.shift();
    return out;
  }

  /**
   * cfg: { provider, baseUrl, model, system, messages:[{role,content}], images:[{mediaType,data}],
   *        maxTokens, tokenParam: 'auto'|'max_tokens'|'max_completion_tokens'|'omit' }
   * Images are attached to the last user message.
   * -> { ok:true, provider, url, authScheme, extraHeaders, body, tokenParam, hasImages } | { ok:false, kind:'config', message }
   */
  function buildRequest(cfg) {
    var p = PROVIDERS[cfg.provider];
    if (!p) return { ok: false, kind: 'config', message: 'Unknown provider.' };
    var baseUrl = normalizeBaseUrl(cfg.baseUrl || p.baseUrl);
    if (!/^https?:\/\//i.test(baseUrl)) return { ok: false, kind: 'config', message: 'The API base URL must start with https:// (or http:// for a local server).' };
    var model = String(cfg.model || '').trim();
    if (!model) return { ok: false, kind: 'config', message: 'Enter a model name in Settings → AI models.' };
    var msgs = normalizeTurns(cfg.messages || []);
    if (!msgs.length) return { ok: false, kind: 'config', message: 'Nothing to send.' };
    var images = (cfg.images || []).filter(function (i) { return i && i.data; });
    var maxTokens = cfg.maxTokens || 1200;
    var system = cfg.system || '';
    var last = msgs[msgs.length - 1];
    var url, body, extra = '', tokenParam = null;
    if (cfg.provider === 'anthropic') {
      url = joinUrl(baseUrl, '/messages');
      if (images.length && last.role === 'user') {
        last.content = images.map(function (i) { return { type: 'image', source: { type: 'base64', media_type: i.mediaType || 'image/png', data: i.data } }; })
          .concat([{ type: 'text', text: last.content }]);
      }
      body = { model: model, max_tokens: maxTokens, messages: msgs };
      if (system) body.system = system;
      extra = 'anthropic-version: 2023-06-01';
    } else {
      url = joinUrl(baseUrl, '/chat/completions');
      tokenParam = !cfg.tokenParam || cfg.tokenParam === 'auto' ? defaultTokenParam(baseUrl) : cfg.tokenParam;
      if (images.length && last.role === 'user') {
        last.content = [{ type: 'text', text: last.content }].concat(images.map(function (i) {
          return { type: 'image_url', image_url: { url: 'data:' + (i.mediaType || 'image/png') + ';base64,' + i.data } };
        }));
      }
      body = { model: model, messages: (system ? [{ role: 'system', content: system }] : []).concat(msgs) };
      if (tokenParam !== 'omit') body[tokenParam] = maxTokens;
    }
    return { ok: true, provider: cfg.provider, url: url, authScheme: p.authScheme, extraHeaders: extra, body: JSON.stringify(body), tokenParam: tokenParam, hasImages: images.length > 0 };
  }

  /** OpenAI changed max_tokens -> max_completion_tokens for newer models; retry once with the other name. */
  function alternateTokenParam(status, bodyText, used) {
    if (status !== 400 || !used || used === 'omit') return null;
    var t = String(bodyText || '');
    if (used === 'max_tokens' && /max_completion_tokens/.test(t)) return 'max_completion_tokens';
    if (used === 'max_completion_tokens' && /max_completion_tokens/.test(t) && /unrecogni|unknown|unsupported|not supported/i.test(t)) return 'max_tokens';
    return null;
  }

  /** True when a 4xx means "this model/endpoint does not accept images". */
  function imageRejected(status, bodyText) {
    if ([400, 404, 413, 415, 422].indexOf(status) < 0) return false;
    return /image|vision|multimodal|multi-modal|image_url|content.{0,40}(string|array|type)|does not support/i.test(String(bodyText || ''));
  }

  function clip(s, n) { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
  function providerMessage(j) {
    if (!j || typeof j !== 'object') return '';
    var e = j.error;
    if (typeof e === 'string') return e;
    if (e && typeof e === 'object' && e.message) return String(e.message);
    if (typeof j.message === 'string') return j.message;
    if (typeof j.detail === 'string') return j.detail;
    if (Array.isArray(j.detail) && j.detail[0] && j.detail[0].msg) return String(j.detail[0].msg);
    return '';
  }
  function textFromOpenAI(j) {
    var c = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
    if (typeof c === 'string') return c;
    if (Array.isArray(c)) return c.map(function (p) { return typeof p === 'string' ? p : (p && p.text) || ''; }).join('');
    return '';
  }
  function textFromAnthropic(j) {
    if (!j || !Array.isArray(j.content)) return '';
    return j.content.filter(function (b) { return b && b.type === 'text'; }).map(function (b) { return b.text || ''; }).join('\n');
  }
  var HTTP_KINDS = { 400: 'badrequest', 401: 'auth', 403: 'auth', 404: 'notfound', 408: 'timeout', 413: 'toolarge', 429: 'ratelimit' };

  /** -> { ok:true, text, empty } | { ok:false, kind, status, message } */
  function parseResponse(provider, status, bodyText) {
    var j = null;
    try { j = JSON.parse(bodyText); } catch (e) { j = null; }
    if (status >= 200 && status < 300) {
      if (!j) return { ok: false, kind: 'parse', status: status, message: 'The provider answered, but not with JSON. Is the base URL correct? (Got: ' + clip(bodyText, 80) + ')' };
      var text = provider === 'anthropic' ? textFromAnthropic(j) : textFromOpenAI(j);
      return { ok: true, text: text.trim(), empty: !text.trim() };
    }
    var pm = clip(providerMessage(j) || bodyText, 300);
    var kind = HTTP_KINDS[status] || (status >= 500 ? 'server' : 'http'), msg;
    switch (kind) {
      case 'auth': msg = 'The provider rejected your API key (HTTP ' + status + '). Check the key in Settings → AI models.'; break;
      case 'ratelimit': msg = 'Rate limit or quota reached (HTTP 429). Wait a moment, or check your plan and credits.'; break;
      case 'notfound': msg = 'Not found (HTTP 404). Check the model name and the base URL.'; break;
      case 'badrequest': msg = 'The provider refused the request (HTTP 400).'; break;
      case 'toolarge': msg = 'The request was too large (HTTP 413).'; break;
      case 'timeout': msg = 'The provider timed out (HTTP ' + status + '). Try again.'; break;
      case 'server': msg = 'The provider had a problem (HTTP ' + status + '). Try again shortly.'; break;
      default: msg = 'Unexpected response (HTTP ' + status + ').';
    }
    return { ok: false, kind: kind, status: status, message: msg + (pm ? ' Provider says: ' + pm : '') };
  }

  /** Transport-level failures reported by the native HTTP layer. */
  function transportError(kind, message) {
    var map = {
      policy: message || 'This URL is not allowed.',
      nokey: 'No API key saved for this model’s provider. Add it in Settings → AI models.',
      dns: message || 'Could not find the server. Check your internet connection and the base URL.',
      connect: message || 'Could not connect to the server. Check your connection and the base URL.',
      timeout: message || 'The request timed out. Check your connection and try again.',
      ssl: message || 'Secure connection failed (certificate/TLS problem).',
      redirect: message || 'The server redirected the request; update the base URL.',
      toolarge: message || 'The response was too large.',
      cancelled: 'Cancelled.',
      io: message || 'Network error.'
    };
    return { ok: false, kind: kind, status: 0, message: map[kind] || message || 'Request failed.' };
  }

  return { PROVIDERS: PROVIDERS, BASE_URL_PRESETS: BASE_URL_PRESETS, normalizeBaseUrl: normalizeBaseUrl, joinUrl: joinUrl,
    defaultTokenParam: defaultTokenParam, normalizeTurns: normalizeTurns, buildRequest: buildRequest,
    alternateTokenParam: alternateTokenParam, imageRejected: imageRejected, parseResponse: parseResponse, transportError: transportError };
});
