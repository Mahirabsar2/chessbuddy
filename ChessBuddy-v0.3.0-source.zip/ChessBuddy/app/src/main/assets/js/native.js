/* ChessBuddy native bridge adapter.
 * Inside the Android app, `window.Android` (NativeBridge.java) provides: the Stockfish process,
 * HTTP with the securely stored API key, clipboard, share sheet, toast, screen-on.
 * In a plain browser `Native.available` is false and every engine call fails with a clear message
 * (there is no fallback engine). */
(function (root) {
  'use strict';
  var A = root.Android || null;
  var handlers = { lines: null, exit: null, http: {} };
  var seq = 0, keepOn = false;

  root.__cbNative = {
    engineLines: function (arr) { if (handlers.lines) for (var i = 0; i < arr.length; i++) handlers.lines(arr[i]); },
    engineExit: function (code, msg) { if (handlers.exit) handlers.exit(code, msg); },
    httpResult: function (id, status, body, kind, message) {
      var cb = handlers.http[id];
      if (cb) { delete handlers.http[id]; cb({ status: status, body: body, kind: kind || '', message: message || '' }); }
    }
  };

  function safeJson(s, fallback) { try { return JSON.parse(s); } catch (e) { return fallback; } }
  function call(name, args, fallback) {
    if (!A || typeof A[name] !== 'function') return fallback;
    try { return A[name].apply(A, args || []); } catch (e) { return fallback; }
  }

  var Native = {
    available: !!A,

    engineTransport: function () {
      var t = {
        onLine: null, onExit: null,
        start: function () {
          if (!A) return Promise.resolve({ ok: false, error: 'Stockfish only runs inside the ChessBuddy Android app.' });
          var r = safeJson(call('engineStart', [], null), null);
          return Promise.resolve(r || { ok: false, error: 'The engine did not answer the start request.' });
        },
        send: function (line) { call('engineSend', [line], null); },
        stop: function () { call('engineStop', [], null); }
      };
      handlers.lines = function (l) { if (t.onLine) t.onLine(l); };
      handlers.exit = function (c, m) { if (t.onExit) t.onExit(c, m); };
      return t;
    },

    /** req: {keyId,provider,url,authScheme,extraHeaders,body}. Returns {promise, cancel}. */
    http: function (req) {
      var id = 'h' + (++seq) + '_' + Date.now();
      var promise = new Promise(function (resolve) {
        if (!A) { resolve({ status: 0, body: '', kind: 'io', message: 'Network access for the coach needs the ChessBuddy Android app.' }); return; }
        handlers.http[id] = resolve;
        call('httpPost', [id, req.keyId, req.url, req.authScheme, req.extraHeaders || '', req.body], null);
      });
      return { promise: promise, cancel: function () { call('httpCancel', [id], null); } };
    },

    hasKey: function (p) { return call('hasKey', [p], false) === true; },
    keyHint: function (p) { return String(call('keyHint', [p], '') || ''); },
    setKey: function (p, k) { return call('setKey', [p, k], false) === true; },
    clearKey: function (p) { return call('clearKey', [p], false) === true; },
    secureStorage: function () { return call('secureStorage', [], false) === true; },

    copy: function (text) {
      if (A) return call('copyText', [text], false) === true;
      try {
        var ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); document.body.removeChild(ta); return ok;
      } catch (e) { return false; }
    },
    share: function (title, text) { return call('shareText', [title, text], false) === true; },
    toast: function (m) { call('toast', [m], null); },
    keepScreenOn: function (on) { on = !!on; if (on === keepOn) return; keepOn = on; call('keepScreenOn', [on], null); },
    deviceInfo: function () {
      return safeJson(call('deviceInfo', [], null), null) || { cores: (root.navigator && navigator.hardwareConcurrency) || 4, memMb: 0, abi: '', sdk: 0, version: 'web', versionCode: 0 };
    }
  };
  root.CBNative = Native;
})(window);
