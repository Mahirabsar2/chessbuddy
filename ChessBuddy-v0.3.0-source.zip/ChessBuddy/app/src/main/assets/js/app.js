/* ChessBuddy app controller (part 1: state, players, engine/AI moves, game screen). */
(function () {
  'use strict';
  const Chess = window.ChessJS.Chess;
  const Eng = window.CBEngine, Str = window.CBStrength, Models = window.CBModels, Coach = window.CBCoach, Prompts = window.CBPrompts,
    Review = window.CBReview, Native = window.CBNative, Board = window.CBBoard, Pieces = window.CBPieces, Snap = window.CBSnapshot;
  Prompts.setChess(Chess);
  Pieces.install(document);

  const $ = id => document.getElementById(id);
  const noop = () => {};
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pad2 = n => (n < 10 ? '0' : '') + n;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clip = (s, n) => { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

  /* ---------------- icons ---------------- */
  const ICON = {
    back: '<path d="M15 5l-7 7 7 7"/>', chev: '<path d="M9 5l7 7-7 7"/>', menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
    hint: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.6 10.8c.7.5 1.1 1.3 1.1 2.2h5c0-.9.4-1.7 1.1-2.2A6 6 0 0 0 12 3z"/>',
    flip: '<path d="M7 4v14M7 18l-3-3M7 18l3-3M17 20V6M17 6l-3 3M17 6l3 3"/>', pause: '<path d="M8 5v14M16 5v14"/>', play: '<path d="M7 4l13 8-13 8z" fill="currentColor"/>',
    tPlay: '<rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="M3.5 3.5h8.5v8.5H3.5zM12 12h8.5v8.5H12z" fill="currentColor"/>',
    tCoach: '<path d="M12 3l2.1 5.6L20 11l-5.9 2.4L12 19l-2.1-5.6L4 11l5.9-2.4z" fill="currentColor"/>',
    tHist: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5.2l3.4 2"/>',
    tSet: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9M4 12h5M13 12h7"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/><circle cx="11" cy="12" r="2"/>',
    robot: '<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M9 16h6"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3.5 19c.5-3.5 3-5 5.5-5s5 1.5 5.5 5"/><circle cx="17" cy="9" r="2.4"/><path d="M16 14.2c2.6-.3 4.6 1 5 4.3"/>',
    versus: '<path d="M5 19L19 5M5 5l14 14"/>', plus: '<path d="M12 5v14M5 12h14"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    share: '<circle cx="6" cy="12" r="2.5"/><circle cx="17" cy="6" r="2.5"/><circle cx="17" cy="18" r="2.5"/><path d="M8.2 10.8l6.6-3.6M8.2 13.2l6.6 3.6"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>', again: '<path d="M20 12a8 8 0 1 1-2.5-5.8M20 4v5h-5"/>', exit: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
    spark: '<path d="M12 3l2.1 5.6L20 11l-5.9 2.4L12 19l-2.1-5.6L4 11l5.9-2.4z"/>'
  };
  const ic = n => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICON[n] + '</svg>';
  const hydrateIcons = root => (root || document).querySelectorAll('[data-ic]').forEach(el => { el.innerHTML = ic(el.getAttribute('data-ic')); });

  /* ---------------- storage + settings ---------------- */
  const K_SET = 'chessbuddy.settings.v3', K_GAMES = 'chessbuddy.games.v3', K_CUR = 'chessbuddy.current.v3';
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };
  const lsDel = k => { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } };

  const dev = Native.deviceInfo();
  const autoThreads = c => (c >= 8 ? 4 : c >= 6 ? 3 : c >= 4 ? 2 : 1);
  const autoHash = m => (m >= 6000 ? 128 : m >= 3000 ? 64 : 32);
  function defaultSettings() {
    return {
      ui: { theme: 'green', coords: true, last: true, legal: true, eval: true },
      play: { movetime: 1000, color: 'w' },
      engine: { threads: autoThreads(dev.cores || 4), hash: autoHash(dev.memMb || 0), analysisMs: 1500 },
      coach: { modelId: 'm_sonnet', screenshot: true },
      custom: { elo: 1500 },
      ava: { w: 'sf:atlas', b: 'sf:marlow' },
      models: Models.defaultModels()
    };
  }
  function merge(base, over) {
    if (!over || typeof over !== 'object') return base;
    Object.keys(base).forEach(k => {
      if (Array.isArray(base[k])) { if (Array.isArray(over[k])) base[k] = over[k]; }
      else if (base[k] && typeof base[k] === 'object') base[k] = merge(base[k], over[k]);
      else if (over[k] !== undefined && typeof over[k] === typeof base[k]) base[k] = over[k];
    });
    return base;
  }
  let settings = merge(defaultSettings(), lsGet(K_SET, null));
  const saveSettings = () => lsSet(K_SET, settings);
  const modelById = id => settings.models.find(m => m.id === id) || null;
  const keyIdOf = m => Models.keyId(m.provider, m.baseUrl);
  const isLocalUrl = u => /^http:\/\//i.test(u || '');
  const modelReady = m => !!m && !!m.model && (Native.hasKey(keyIdOf(m)) || isLocalUrl(m.baseUrl));

  /* ---------------- players ---------------- */
  const HUMAN = { kind: 'human', name: 'You' };
  const hueOf = s => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  const sfPlayer = b => ({ kind: 'sf', botId: b.id, name: b.name, elo: b.elo, hue: b.hue, piece: b.piece });
  const customPlayer = elo => ({ kind: 'sf', botId: 'custom', name: 'Custom bot', elo, hue: 150, piece: 'n' });
  const llmPlayer = m => ({ kind: 'llm', modelId: m.id, name: Models.displayName(m) });
  const eloText = p => (p.kind === 'sf' ? (p.elo ? '(' + p.elo + ')' : '(Max)') : p.kind === 'llm' ? 'AI model' : '');
  const descPlayer = p => (p.kind === 'human' ? 'a human player' : p.kind === 'llm' ? p.name + ' (an AI language model)' : p.name + ' (Stockfish bot' + (p.elo ? ', about ' + p.elo + ' Elo' : ', full strength') + ')');
  function avatarHtml(p) {
    if (!p || p.kind === 'human') return '<span class="avatar human"><svg viewBox="0 0 40 40"><circle cx="20" cy="15" r="7" fill="#a3a19e"/><path d="M6 38c1-9 7-13 14-13s13 4 14 13z" fill="#a3a19e"/></svg></span>';
    if (p.kind === 'sf') return '<span class="avatar" style="background:hsl(' + (p.hue || 140) + ',42%,36%)"><svg viewBox="0 0 45 45"><use href="#w' + (p.piece || 'n').toUpperCase() + '"/></svg></span>';
    return '<span class="avatar" style="background:hsl(' + hueOf(p.name) + ',45%,38%)"><svg viewBox="0 0 40 40"><text x="20" y="27.5" text-anchor="middle" font-size="22" font-weight="800" fill="#fff" font-family="system-ui,sans-serif">' + esc((p.name || '?').charAt(0)) + '</text></svg></span>';
  }

  /* ---------------- state ---------------- */
  let game = new Chess();
  const newCtx = players => ({ players, flipped: false, startedAt: Date.now(), saved: false, evalWhite: null, evalDepth: 0 });
  let ctx = newCtx({ w: HUMAN, b: sfPlayer(Str.botById('marlow')) });
  let sel = null, legalMap = {}, capMap = {}, lastMove = null, hint = null;
  let over = null, paused = false, thinking = false, moveJob = null, token = 0, hintTok = 0, llmHandle = null;
  let currentTab = 'play', playScreen = 'lobby';
  let lastAnalysis = null, reviewResult = null, reviewTok = 0;

  const modeOf = () => { const a = ctx.players.w.kind === 'human', b = ctx.players.b.kind === 'human'; return a && b ? 'hvh' : (!a && !b ? 'ava' : 'hva'); };
  const humanSide = () => (modeOf() === 'hva' ? (ctx.players.w.kind === 'human' ? 'w' : 'b') : null);
  const playerOf = side => ctx.players[side];
  const usesEngine = () => ctx.players.w.kind === 'sf' || ctx.players.b.kind === 'sf';
  const humanTurn = () => playerOf(game.turn()).kind === 'human';
  const aiTurn = () => !over && !humanTurn();

  const engine = new Eng.UciEngine(Native.engineTransport());
  engine.onState = () => renderEngineUi();
  const engineName = () => (engine.idName || 'Stockfish').replace(/ by .*/, '');
  const baseOptions = () => ({ Threads: settings.engine.threads, Hash: settings.engine.hash, 'Move Overhead': 30 });
  const analysisOptions = mpv => Object.assign(baseOptions(), { MultiPV: mpv, UCI_LimitStrength: false, 'Skill Level': 20 });
  const startFenOf = g => { const h = g.getHeaders ? g.getHeaders() : g.header(); return (h && h.FEN) || Eng.START_FEN; };
  const uciHistory = g => Eng.uciMovesFromHistory(g.history({ verbose: true }));
  const startEngine = () => engine.ensureReady().catch(noop);

  /* ---------------- toast / modal ---------------- */
  let toastTimer = null;
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600); }
  const openModal = html => { $('modalCard').innerHTML = html; hydrateIcons($('modalCard')); $('modal').hidden = false; };
  const closeModal = () => { $('modal').hidden = true; $('modalCard').innerHTML = ''; };
  function confirmDialog(message, okLabel, danger) {
    return new Promise(res => {
      openModal('<h3>Please confirm</h3><p class="muted">' + esc(message) + '</p><div class="controls"><button class="btn ' + (danger ? 'danger' : 'primary') + '" id="cdOk" type="button">' + esc(okLabel || 'OK') + '</button><button class="btn" id="cdNo" type="button">Cancel</button></div>');
      $('cdOk').onclick = () => { closeModal(); res(true); };
      $('cdNo').onclick = () => { closeModal(); res(false); };
    });
  }
  const setSeg = (id, v) => $(id).querySelectorAll('button').forEach(b => b.classList.toggle('on', b.getAttribute('data-v') === v));
  const bindSeg = (id, fn) => $(id).addEventListener('click', e => { const b = e.target.closest('button'); if (b) fn(b.getAttribute('data-v')); });
  const fmtDate = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()) + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()); };

  /* ---------------- game helpers ---------------- */
  function computeOver() {
    const loser = game.turn(), winner = loser === 'w' ? 'b' : 'w', nm = winner === 'w' ? 'White' : 'Black';
    if (game.isCheckmate()) return { type: 'mate', winner, text: 'Checkmate — ' + nm + ' wins' };
    if (game.isStalemate()) return { type: 'draw', text: 'Draw by stalemate' };
    if (game.isInsufficientMaterial()) return { type: 'draw', text: 'Draw — insufficient material' };
    if (game.isThreefoldRepetition()) return { type: 'draw', text: 'Draw by threefold repetition' };
    if (game.isDrawByFiftyMoves && game.isDrawByFiftyMoves()) return { type: 'draw', text: 'Draw by the fifty-move rule' };
    if (game.isDraw()) return { type: 'draw', text: 'Draw' };
    return null;
  }
  const resultCode = () => (!over ? '*' : over.winner ? (over.winner === 'w' ? '1-0' : '0-1') : '1/2-1/2');
  const labelOf = side => { const p = playerOf(side); return p.kind === 'human' ? (modeOf() === 'hvh' ? (side === 'w' ? 'White' : 'Black') : 'Player') : p.name + (p.kind === 'sf' && p.elo ? ' (' + p.elo + ')' : ''); };
  function setHeaders() {
    const d = new Date();
    game.setHeader('Event', 'ChessBuddy game'); game.setHeader('Site', 'ChessBuddy (Android)');
    game.setHeader('Date', d.getFullYear() + '.' + pad2(d.getMonth() + 1) + '.' + pad2(d.getDate())); game.setHeader('Round', '-');
    game.setHeader('White', labelOf('w')); game.setHeader('Black', labelOf('b'));
  }
  function saveCurrent() { lsSet(K_CUR, { pgn: game.pgn(), players: ctx.players, flipped: ctx.flipped, startedAt: ctx.startedAt, saved: ctx.saved, evalWhite: ctx.evalWhite }); }
  function recordGame() {
    const list = lsGet(K_GAMES, []);
    game.setHeader('Result', resultCode());
    list.unshift({ id: 'g' + Date.now(), date: new Date().toISOString(), players: ctx.players, human: humanSide(), mode: modeOf(),
      white: labelOf('w'), black: labelOf('b'), result: resultCode(), resultText: over ? over.text : 'Unfinished game',
      plies: game.history().length, pgn: game.pgn(), fen: game.fen(), done: !!over });
    lsSet(K_GAMES, list.slice(0, 100));
    ctx.saved = true;
  }
  const saveIfUnfinished = () => { if (!ctx.saved && game.history().length > 0) recordGame(); };

  /* ---------------- AI moves ---------------- */
  function cancelEngine() {
    token++; thinking = false; hintTok++; moveJob = null;
    if (llmHandle) { try { llmHandle.cancel(); } catch (e) { /* ignore */ } llmHandle = null; }
    if (engine.isSearching()) engine.stop();
  }
  function scheduleMove() { if (over || paused || humanTurn()) return; makeAiMove(); }

  function makeAiMove(forcePlayer) {
    const myToken = ++token, side = game.turn(), p = forcePlayer || playerOf(side);
    thinking = true; hint = null; setCaption('');
    renderStatus(); renderCards(); renderControls();
    const job = (p.kind === 'llm' ? llmMove(side, p, myToken) : stockfishMove(side, p, myToken)).catch(err => { if (myToken === token) aiError(err, side, p); });
    moveJob = job; return job;
  }

  async function stockfishMove(side, p, myToken) {
    const t0 = Date.now();
    await engine.ensureReady();
    const rng = engine.optionRange('UCI_Elo');
    const plan = Str.plan(p.elo, { movetime: settings.play.movetime, uciMin: rng && rng.min, uciMax: rng && rng.max, hasLimit: engine.hasOption('UCI_Elo') && engine.hasOption('UCI_LimitStrength') });
    const req = { startFen: startFenOf(game), moves: uciHistory(game), options: Object.assign(baseOptions(), plan.options), isStale: () => myToken !== token };
    if (plan.go.nodes) req.nodes = plan.go.nodes; else req.movetime = plan.go.movetime;
    const res = await engine.search(req);
    if (myToken !== token || res.cancelled) return;
    if (res.none || !res.bestmove) { thinking = false; moveJob = null; over = over || computeOver(); render(); if (!over) setStatus('Stockfish reports no legal move.', 'warn'); return; }
    const uci = plan.mode === 'handicap' ? (Str.pickMove(res.lines, plan) || res.bestmove) : res.bestmove;
    const line = res.lines[0];
    if (line && line.score) { ctx.evalWhite = Eng.scoreToWhite(line.score, side); ctx.evalDepth = line.depth || 0; }
    const wait = (modeOf() === 'ava' ? 0 : 450) - (Date.now() - t0);
    if (wait > 0) await sleep(wait);
    if (myToken !== token) return;
    let mv;
    try { mv = game.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci.length > 4 ? uci[4] : undefined }); }
    catch (e) { throw new Eng.EngineError('protocol', 'Stockfish sent a move that the rules engine rejected (' + uci + ' in ' + game.fen() + ').'); }
    thinking = false; moveJob = null;
    afterMove(mv, true);
  }

  async function maybeShot(model) {
    if (!settings.coach.screenshot || model.vision === false) return null;
    try { return await Snap.render(game, { flipped: false, last: lastMove }); } catch (e) { return null; }
  }

  async function llmMove(side, p, myToken) {
    const model = modelById(p.modelId);
    if (!model) throw new Error('The model for this player is no longer in Settings → AI models.');
    const maxAttempts = 3, opp = descPlayer(playerOf(side === 'w' ? 'b' : 'w'));
    let rejection = null, lastText = '';
    for (let a = 1; a <= maxAttempts; a++) {
      if (myToken !== token) return;
      const shot = await maybeShot(model);
      if (myToken !== token) return;
      const user = Prompts.playerUserMessage({ game, opponent: opp, hasImage: !!shot, rejection });
      setCaption(p.name + ' is thinking' + (a > 1 ? ' (attempt ' + a + ' of ' + maxAttempts + ')' : '') + '…');
      const r = await callModel(model, { system: Prompts.systemPlayer(side), messages: [{ role: 'user', content: user }], images: shot ? [shot] : [], maxTokens: 400,
        aborted: () => myToken !== token, onHandle: h => { llmHandle = h; } });
      llmHandle = null;
      if (myToken !== token) return;
      if (!r.ok) { llmFailure(side, p, r.message); return; }
      lastText = r.text;
      if (r.empty) { rejection = 'Your reply was empty.'; continue; }
      const parsed = Prompts.parseMoveReply(r.text, game);
      if (parsed.ok) {
        const why = (/WHY\s*[:\-]\s*([^\n]+)/i.exec(r.text) || [])[1];
        let mv;
        try { mv = game.move({ from: parsed.move.from, to: parsed.move.to, promotion: parsed.move.promotion }); }
        catch (e) { rejection = 'That move was not legal.'; continue; }
        thinking = false; moveJob = null; ctx.why = ctx.why || {}; ctx.why[side] = why ? clip(why, 160) : '';
        setCaption(why ? p.name + ': ' + clip(why, 160) : '');
        afterMove(mv, true);
        return;
      }
      rejection = parsed.message + ' You wrote: "' + clip(r.text, 80) + '".';
    }
    llmFailure(side, p, p.name + ' did not return a legal move after ' + maxAttempts + ' attempts (last reply: "' + clip(lastText, 80) + '").');
  }

  function llmFailure(side, p, message) {
    thinking = false; moveJob = null; paused = modeOf() === 'ava' ? true : paused;
    setCaption(''); renderCards(); renderControls(); renderStatus();
    const ov = $('boardOverlay');
    ov.innerHTML = '<div class="ov-card"><h4>' + esc(p.name) + ' couldn’t move</h4><p>' + esc(message) + '</p><div class="controls" style="justify-content:center"><button class="btn primary small" id="lfRetry" type="button">Try again</button><button class="btn small" id="lfSf" type="button">Let Stockfish move</button><button class="btn danger small" id="lfRes" type="button">Resign for it</button></div></div>';
    ov.hidden = false; ov.onclick = null;
    $('lfRetry').onclick = () => { ov.hidden = true; paused = false; makeAiMove(); };
    $('lfSf').onclick = () => { ov.hidden = true; paused = false; toast('Stockfish plays this move for ' + p.name); makeAiMove(sfPlayer(Str.botById('stockfish'))); };
    $('lfRes').onclick = () => { ov.hidden = true; resign(side); };
  }

  function aiError(e, side, p) {
    thinking = false; moveJob = null;
    let msg = (e && e.message) || 'Unknown error';
    if (e && e.kind === 'timeout') msg += ' Try a shorter thinking time or fewer threads in Settings.';
    if (modeOf() === 'ava') paused = true;
    setStatus((p && p.kind === 'llm' ? p.name : 'Engine') + ' problem: ' + msg, 'bad');
    renderControls(); renderCards(); renderEngineUi();
  }

  function afterMove(m, byAi) {
    lastMove = { from: m.from, to: m.to }; sel = null; legalMap = {}; capMap = {}; hint = null; lastAnalysis = null; reviewResult = null;
    over = computeOver();
    saveCurrent(); render();
    if (over) { onGameOver(); return; }
    if (byAi && modeOf() === 'ava') { const tk = token; setTimeout(() => { if (tk === token) scheduleMove(); }, 500); }
    else scheduleMove();
  }

  function onGameOver() {
    cancelEngine();
    game.setHeader('Result', resultCode());
    if (!ctx.saved) recordGame();
    saveCurrent();
    const hs = humanSide();
    let title = over.text, sub = '';
    if (hs && over.winner) { title = over.winner === hs ? 'You won!' : playerOf(over.winner).name + ' wins'; sub = over.text; }
    else if (!over.winner) sub = 'The game is a draw.';
    showOverlay('<h4>' + esc(title) + '</h4><p>' + esc(sub) + '</p><div class="controls" style="justify-content:center"><button class="btn primary" id="ovNew" type="button">Rematch</button><button class="btn" id="ovCoach" type="button">Review</button><button class="btn" id="ovClose" type="button">Close</button></div>');
    $('ovNew').onclick = () => rematch();
    $('ovCoach').onclick = () => { hideOverlay(); showTab('coach'); };
    $('ovClose').onclick = hideOverlay;
    renderControls();
  }
  function showOverlay(inner) { const ov = $('boardOverlay'); ov.innerHTML = '<div class="ov-card">' + inner + '</div>'; ov.hidden = false; ov.onclick = null; }
  function hideOverlay() { const ov = $('boardOverlay'); ov.hidden = true; ov.onclick = null; }

  /* ---------------- human input ---------------- */
  function onSquareTap(sq) {
    if (over || thinking || !humanTurn() || !$('boardOverlay').hidden) return;
    const p = game.get(sq);
    if (sel && legalMap[sq]) { tryMove(sel, sq); return; }
    if (p && p.color === game.turn()) { selectSquare(sq); return; }
    sel = null; legalMap = {}; capMap = {}; render();
  }
  function selectSquare(sq) {
    sel = sq; legalMap = {}; capMap = {}; hint = null;
    game.moves({ square: sq, verbose: true }).forEach(m => { legalMap[m.to] = true; if (m.captured || m.flags.indexOf('e') >= 0) capMap[m.to] = true; });
    render();
  }
  function tryMove(from, to) {
    const c = game.moves({ square: from, verbose: true }).filter(m => m.to === to);
    if (!c.length) return;
    if (c[0].promotion) { showPromotion(from, to, c[0].color); return; }
    commitHuman({ from, to });
  }
  function commitHuman(mv) {
    let m;
    try { m = game.move(mv); } catch (e) { toast('Illegal move'); return; }
    afterMove(m, false);
  }
  function showPromotion(from, to, color) {
    showOverlay('<h4>Promote to</h4><div class="promo">' + ['q', 'r', 'b', 'n'].map(t => '<button type="button" data-p="' + t + '" aria-label="' + t + '"><svg viewBox="0 0 45 45"><use href="#' + color + t.toUpperCase() + '"/></svg></button>').join('') + '</div>');
    $('boardOverlay').onclick = e => { const b = e.target.closest('button'); if (!b) return; hideOverlay(); commitHuman({ from, to, promotion: b.getAttribute('data-p') }); };
  }

  /* ---------------- game actions ---------------- */
  function startGame(players) {
    cancelEngine(); saveIfUnfinished(); hideOverlay();
    game = new Chess(); ctx = newCtx(players); ctx.flipped = humanSide() === 'b';
    over = null; paused = false; sel = null; legalMap = {}; capMap = {}; lastMove = null; hint = null; lastAnalysis = null; reviewResult = null;
    setHeaders(); saveCurrent();
    showPlayScreen('game'); render();
    if (usesEngine() && engine.state === 'ready') engine.newGame().catch(noop);
    scheduleMove();
  }
  const rematch = () => startGame({ w: ctx.players.b, b: ctx.players.w });
  function resign(side) {
    cancelEngine(); hideOverlay();
    const winner = side === 'w' ? 'b' : 'w';
    over = { type: 'resign', winner, text: (side === 'w' ? 'White' : 'Black') + ' resigned — ' + (winner === 'w' ? 'White' : 'Black') + ' wins' };
    render(); onGameOver();
  }
  function undo() {
    cancelEngine(); hideOverlay();
    if (!game.history().length) return;
    game.undo();
    if (modeOf() === 'hva') { while (game.history().length && game.turn() !== humanSide()) game.undo(); }
    if (modeOf() === 'ava') paused = true;
    over = null; sel = null; legalMap = {}; capMap = {}; hint = null; ctx.saved = false; ctx.evalWhite = null; lastAnalysis = null; reviewResult = null;
    const h = game.history({ verbose: true });
    lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
    saveCurrent(); render(); scheduleMove();
  }
  /** Analysis never interrupts a move in progress: it waits for it (AI-vs-AI pauses for analysis). */
  function runAnalysis(o) {
    const wait = moveJob ? moveJob.catch(noop) : Promise.resolve();
    if (modeOf() === 'ava' && !paused) { paused = true; renderControls(); }
    return wait.then(() => engine.search({ startFen: o.startFen || startFenOf(game), moves: o.moves || uciHistory(game), movetime: o.ms,
      options: analysisOptions(o.multipv || 1), onInfo: o.onInfo, isStale: o.isStale }));
  }
  async function doHint() {
    if (over || thinking || !humanTurn() || modeOf() === 'hvh') return;
    if (engine.state !== 'ready') { toast('Stockfish is not ready'); return; }
    const my = ++hintTok; setStatus('Asking Stockfish…');
    try {
      const res = await runAnalysis({ ms: 700, multipv: 1 });
      if (my !== hintTok || res.cancelled) return;
      if (res.bestmove) { hint = { from: res.bestmove.slice(0, 2), to: res.bestmove.slice(2, 4) }; render(); }
    } catch (e) { if (my === hintTok) aiError(e, game.turn(), null); }
  }

  /* ---------------- generic model call (coach + AI players) ---------------- */
  async function callModel(model, o) {
    let tokenParam = model.tokenParam || 'auto', images = (o.images || []).slice();
    for (let attempt = 0; attempt < 3; attempt++) {
      const req = Coach.buildRequest({ provider: model.provider, baseUrl: model.baseUrl, model: model.model, system: o.system, messages: o.messages, images, maxTokens: o.maxTokens, tokenParam });
      if (!req.ok) return req;
      const h = Native.http({ keyId: keyIdOf(model), provider: req.provider, url: req.url, authScheme: req.authScheme, extraHeaders: req.extraHeaders, body: req.body });
      if (o.onHandle) o.onHandle(h);
      const r = await h.promise;
      if (o.aborted && o.aborted()) return Coach.transportError('cancelled');
      if (r.kind) return Coach.transportError(r.kind, r.message);
      const alt = Coach.alternateTokenParam(r.status, r.body, req.tokenParam);
      if (alt) { tokenParam = alt; model.tokenParam = alt; saveSettings(); continue; }
      if (images.length && Coach.imageRejected(r.status, r.body)) { images = []; model.vision = false; saveSettings(); toast(Models.displayName(model) + ' does not accept images — sending text only'); continue; }
      return Coach.parseResponse(model.provider, r.status, r.body);
    }
    return Coach.transportError('io', 'The request failed.');
  }

  /* ---------------- import / export ---------------- */
  const exportFen = () => game.fen();
  const exportPgn = () => { game.setHeader('Result', resultCode()); return game.pgn(); };
  const copyText = (text, label) => toast(Native.copy(text) ? label + ' copied' : 'Could not copy');
  function parseImport(text) {
    const t = text.trim();
    if (!t) return { error: 'Paste a FEN or PGN first.' };
    const looksFen = /^[rnbqkpRNBQKP1-8\/]+\s+[wb]\s+/.test(t);
    const asFen = () => new Chess(t), asPgn = () => { const g = new Chess(); g.loadPgn(t); return g; };
    try { return { game: looksFen ? asFen() : asPgn() }; }
    catch (e1) { try { return { game: looksFen ? asPgn() : asFen() }; } catch (e2) { return { error: 'Could not read that as a FEN or PGN: ' + clip(e1.message || e1, 90) }; } }
  }
  async function loadImported(g) {
    if (game.history().length && !over && !(await confirmDialog('Replace the current game with the loaded one? The current game is saved to the archive.', 'Load'))) return false;
    cancelEngine(); saveIfUnfinished(); hideOverlay();
    game = g; ctx = newCtx({ w: HUMAN, b: HUMAN });
    const h = game.history({ verbose: true });
    lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
    over = computeOver(); paused = false; sel = null; legalMap = {}; capMap = {}; hint = null; lastAnalysis = null; reviewResult = null;
    saveCurrent(); showTab('play'); showPlayScreen('game'); render();
    return true;
  }

  /* ---------------- game screen rendering ---------------- */
  function setStatus(text, cls) { const s = $('status'); s.textContent = text; s.className = 'statusline' + (cls ? ' ' + cls : ''); }
  function setCaption(text) { const c = $('caption'); c.hidden = !text; c.textContent = text || ''; }
  function renderStatus() {
    if (over) { setStatus(over.text, over.winner && humanSide() && over.winner !== humanSide() ? 'bad' : ''); return; }
    const side = game.turn(), p = playerOf(side), nm = side === 'w' ? 'White' : 'Black', chk = game.inCheck();
    if (thinking) { setStatus(p.name + ' is thinking…'); return; }
    if (p.kind === 'human') { setStatus(modeOf() === 'hva' ? (chk ? 'Check! Your move.' : 'Your move') : nm + ' to move' + (chk ? ' — check!' : ''), chk ? 'warn' : ''); return; }
    if (paused) { setStatus('Paused — ' + nm + ' to move'); return; }
    if (p.kind === 'sf' && engine.state === 'dead') { setStatus('Waiting for Stockfish — see the message above.', 'bad'); return; }
    setStatus(p.name + ' to move');
  }
  function capturedHtml(side) {
    const opp = side === 'w' ? 'b' : 'w', m = Prompts.material(game), start = { q: 1, r: 2, b: 2, n: 2, p: 8 };
    let html = '';
    ['q', 'r', 'b', 'n', 'p'].forEach(t => { for (let i = 0, n = Math.max(0, start[t] - m[opp][t]); i < n; i++) html += '<svg viewBox="0 0 45 45"><use href="#' + opp + t.toUpperCase() + '"/></svg>'; });
    const diff = m[side].pts - m[opp].pts;
    return html + (diff > 0 ? '<span>+' + diff + '</span>' : '');
  }
  function renderCards() {
    const bottom = ctx.flipped ? 'b' : 'w', top = bottom === 'w' ? 'b' : 'w';
    [['top', top], ['bot', bottom]].forEach(([k, side]) => {
      const p = playerOf(side);
      $(k + 'Av').outerHTML = avatarHtml(p).replace('class="avatar', 'id="' + k + 'Av" class="avatar');
      $(k + 'Name').textContent = p.kind === 'human' ? (modeOf() === 'hvh' ? (side === 'w' ? 'White' : 'Black') : 'You') : p.name;
      $(k + 'Sub').textContent = p.kind === 'human' ? (modeOf() === 'hvh' ? 'Player' : (side === 'w' ? 'White' : 'Black')) : eloText(p) + ' · ' + (side === 'w' ? 'White' : 'Black');
      $(k + 'Cap').innerHTML = capturedHtml(side);
      const chip = $(k + 'Chip'), mine = thinking && game.turn() === side && p.kind !== 'human' && !over;
      chip.hidden = !mine; chip.className = 'chip think dots'; chip.textContent = mine ? 'Thinking' : '';
    });
  }
  function renderMoves() {
    const host = $('moves'), v = game.history({ verbose: true });
    if (!v.length) { host.innerHTML = '<span class="muted">No moves yet</span>'; return; }
    let html = '';
    v.forEach((m, i) => {
      const n = m.before.split(' ')[5];
      if (m.color === 'w') html += '<span class="mv num">' + n + '.</span>'; else if (i === 0) html += '<span class="mv num">' + n + '…</span>';
      html += '<span class="mv' + (i === v.length - 1 ? ' cur' : '') + '">' + esc(m.san) + '</span>';
    });
    host.innerHTML = html; host.scrollLeft = host.scrollWidth;
  }
  function paintEval(fillId, textId, vId, ev, flipped) {
    const v = $(vId), fill = $(fillId), txt = $(textId);
    if (!settings.ui.eval || !ev) { v.style.display = 'none'; return; }
    v.style.display = '';
    const pct = Eng.whitePercent(ev);
    fill.style.height = pct.toFixed(1) + '%'; fill.style.top = flipped ? '0' : 'auto'; fill.style.bottom = flipped ? 'auto' : '0';
    txt.textContent = Eng.formatScore(ev).replace(/^\+/, ''); txt.style.top = '3px';
    txt.style.color = (flipped ? pct > 8 : pct > 92) ? '#262522' : '#a3a19e';
  }
  function renderControls() {
    const mode = modeOf();
    $('btnUndo').disabled = game.history().length === 0;
    $('btnHint').hidden = mode !== 'hva';
    $('btnHint').disabled = !!over || thinking || !humanTurn() || engine.state !== 'ready';
    const bp = $('btnPause'); bp.hidden = mode !== 'ava'; $('pauseLabel').textContent = paused ? 'Resume' : 'Pause'; bp.disabled = !!over;
    bp.querySelector('[data-ic]').innerHTML = ic(paused ? 'play' : 'pause');
    Native.keepScreenOn((mode === 'ava' && !paused && !over) || thinking);
  }
  function renderEngineUi() {
    const pill = $('enginePill'), lab = $('engineLabel');
    pill.classList.remove('ok', 'bad');
    if (engine.state === 'ready') { pill.classList.add('ok'); lab.textContent = engineName(); }
    else if (engine.state === 'dead') { pill.classList.add('bad'); lab.textContent = 'Engine error'; }
    else lab.textContent = 'Engine starting…';
    const banner = $('engineBanner');
    if (engine.state === 'dead' && usesEngine() && playScreen === 'game') {
      banner.hidden = false;
      $('engineBannerText').textContent = 'Stockfish is unavailable: ' + (engine.lastError ? engine.lastError.message : 'not running') + (Native.available ? ' Bots cannot move until it starts.' : '');
    } else banner.hidden = true;
    const st = $('engStatus');
    if (st) { const r = engine.optionRange('UCI_Elo'); st.textContent = engine.state === 'ready' ? engineName() + ' is running' + (r ? ' · limiter Elo ' + r.min + '–' + r.max : ' · full strength only') : engine.state === 'dead' ? 'Not running: ' + (engine.lastError ? engine.lastError.message : 'unknown error') : 'Starting…'; }
  }
  function render() {
    Board.draw($('board'), game, { flipped: ctx.flipped, selected: sel, legal: settings.ui.legal ? legalMap : {}, captures: capMap, last: settings.ui.last ? lastMove : null, check: Board.checkSquare(game), hint, coords: settings.ui.coords });
    renderCards(); renderMoves(); renderControls(); renderStatus(); renderEngineUi();
    paintEval('evalFill', 'evalText', 'evalV', modeOf() === 'hvh' ? null : ctx.evalWhite, ctx.flipped);
    renderHeader(); renderLobbyResume(); renderCoachMini();
  }

  /* ================= part 2: navigation, lobby, sheets ================= */
  let botsTab = 'sf';
  const TAB_TITLES = { coach: 'Coach', history: 'Archive', settings: 'Settings' };
  const gameTitle = () => {
    const m = modeOf();
    if (m === 'hva') { const o = playerOf(humanSide() === 'w' ? 'b' : 'w'); return 'vs ' + o.name + (o.kind === 'sf' ? ' ' + eloText(o) : ''); }
    return m === 'ava' ? ctx.players.w.name + ' vs ' + ctx.players.b.name : 'Two players';
  };
  function renderHeader() {
    const inPlay = currentTab === 'play', showBack = inPlay && playScreen !== 'lobby';
    const back = $('hdrBack'); back.hidden = !showBack; if (showBack) back.innerHTML = ic('back');
    $('hdrBrand').querySelector('.logo').style.display = (showBack || !inPlay) ? 'none' : '';
    $('hdrTitle').textContent = !inPlay ? TAB_TITLES[currentTab] : playScreen === 'bots' ? (botsTab === 'sf' ? 'Play Bots' : 'AI Models') : playScreen === 'game' ? gameTitle() : 'ChessBuddy';
  }
  function showPlayScreen(name) {
    playScreen = name;
    $('lobby').hidden = name !== 'lobby'; $('botsPage').hidden = name !== 'bots'; $('gamePage').hidden = name !== 'game';
    if (name === 'bots') renderBots();
    if (name === 'lobby') renderLobbyResume();
    renderHeader(); renderEngineUi(); window.scrollTo(0, 0);
  }
  function showTab(name) {
    currentTab = name;
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + name));
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.getAttribute('data-tab') === name));
    if (name === 'coach') { renderCoachSettings(); renderCoachMini(); }
    if (name === 'history') renderHistory();
    if (name === 'settings') renderSettings();
    renderHeader(); window.scrollTo(0, 0);
  }
  function renderLobbyResume() {
    const card = $('resumeCard'), live = game.history().length > 0 && !over;
    card.hidden = !live;
    const names = settings.models.map(Models.displayName);
    $('modelsSub').textContent = names.length ? names.slice(0, 3).join(', ') + (names.length > 3 ? '…' : '') : 'Add a model in Settings';
    if (!live) return;
    Board.draw($('resumeBoard'), game, { flipped: ctx.flipped, coords: false, last: lastMove });
    $('resumeTitle').textContent = gameTitle();
    $('resumeText').textContent = game.history().length + ' moves · ' + (playerOf(game.turn()).kind === 'human' ? 'your move' : playerOf(game.turn()).name + ' to move');
  }

  const botBlurb = b => b.blurb;
  function botRow(b) {
    return '<button class="bot" data-bot="' + b.id + '" type="button">' + avatarHtml(sfPlayer(b)) + '<span class="bi"><b>' + esc(b.name) + '</b><small>' + esc(botBlurb(b)) + '</small></span><span class="elo">' + (b.elo || 'Max') + '</span></button>';
  }
  function renderBots() {
    setSeg('botsTabs', botsTab);
    const host = $('botsList');
    if (botsTab === 'sf') {
      let html = '<button class="bot" data-bot="custom" type="button">' + avatarHtml(customPlayer(settings.custom.elo)) + '<span class="bi"><b>Custom strength</b><small>Choose any Elo from 300 to 3200</small></span><span class="elo">' + settings.custom.elo + '</span></button>';
      ['Beginner', 'Intermediate', 'Advanced', 'Master'].forEach(cat => {
        const bots = Str.BOTS.filter(b => Str.category(b.elo) === cat);
        if (bots.length) html += '<div class="bgroup">' + cat + '</div>' + bots.map(botRow).join('');
      });
      host.innerHTML = html;
    } else {
      host.innerHTML = settings.models.map(m => {
        const p = llmPlayer(m), ready = modelReady(m);
        return '<button class="bot" data-model="' + m.id + '" type="button">' + avatarHtml(p) + '<span class="bi"><b>' + esc(p.name) + '</b><small>' + esc(Models.providerLabel(m)) + ' · ' + esc(m.model) + '</small></span>' + (ready ? '' : '<span class="warnchip">Add API key</span>') + '</button>';
      }).join('') + '<button class="bot" data-addmodel="1" type="button"><span class="avatar human"><svg viewBox="0 0 24 24" fill="none" stroke="#a3a19e" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span><span class="bi"><b>Add a model</b><small>Claude, OpenAI-compatible, OpenRouter, Ollama…</small></span></button>';
    }
  }
  function resolvePlayer(spec) {
    const [k, id] = String(spec).split(':');
    if (k === 'llm') { const m = modelById(id); return m ? llmPlayer(m) : null; }
    const b = Str.botById(id); return b ? sfPlayer(b) : null;
  }
  function playerOptionsHtml(selected) {
    return '<optgroup label="Stockfish bots">' + Str.BOTS.map(b => '<option value="sf:' + b.id + '"' + (selected === 'sf:' + b.id ? ' selected' : '') + '>' + esc(b.name) + ' (' + (b.elo || 'Max') + ')</option>').join('') + '</optgroup>' +
      (settings.models.length ? '<optgroup label="AI models">' + settings.models.map(m => '<option value="llm:' + m.id + '"' + (selected === 'llm:' + m.id ? ' selected' : '') + '>' + esc(Models.displayName(m)) + '</option>').join('') + '</optgroup>' : '');
  }
  function openAvASheet() {
    openModal('<h3>Watch AI vs AI</h3><p class="muted tiny">Pick any two opponents — Stockfish bots or AI models. The game pauses while you analyse it.</p>' +
      '<div class="field"><label for="avW">White</label><select id="avW">' + playerOptionsHtml(settings.ava.w) + '</select></div>' +
      '<div class="field"><label for="avB">Black</label><select id="avB">' + playerOptionsHtml(settings.ava.b) + '</select></div>' +
      '<div class="controls"><button class="btn primary" id="avGo" type="button">Start</button><button class="btn" id="avNo" type="button">Cancel</button></div>');
    $('avNo').onclick = closeModal;
    $('avGo').onclick = () => {
      const w = resolvePlayer($('avW').value), b = resolvePlayer($('avB').value);
      settings.ava = { w: $('avW').value, b: $('avB').value }; saveSettings();
      const bad = [w, b].find(p => p && p.kind === 'llm' && !modelReady(modelById(p.modelId)));
      if (bad) { toast(bad.name + ' needs an API key (Settings → AI models)'); return; }
      closeModal(); startGame({ w, b });
    };
  }
  function openOpponentSheet(p, blurb) {
    let color = settings.play.color;
    const llm = p.kind === 'llm', m = llm ? modelById(p.modelId) : null, ready = !llm || modelReady(m);
    openModal('<div class="center"><div class="big-av">' + avatarHtml(p) + '</div><h3>' + esc(p.name) + ' <span class="muted">' + esc(eloText(p)) + '</span></h3><p class="muted">' + esc(blurb) + '</p></div>' +
      '<div class="seg" id="psColor"><button type="button" data-v="w">White</button><button type="button" data-v="r">Random</button><button type="button" data-v="b">Black</button></div>' +
      (llm ? '<div class="notice warn">' + esc(p.name) + ' reasons about the position from text and a board screenshot. It can make mistakes; if it fails to give a legal move after 3 tries, you decide what happens.' + (ready ? '' : ' <b>Add an API key first.</b>') + '</div>' : '') +
      '<div class="controls"><button class="btn primary" id="psPlay" type="button">' + (ready ? 'Play' : 'Add API key') + '</button><button class="btn" id="psNo" type="button">Cancel</button></div>');
    setSeg('psColor', color);
    bindSeg('psColor', v => { color = v; setSeg('psColor', v); });
    $('psNo').onclick = closeModal;
    $('psPlay').onclick = () => {
      if (!ready) { closeModal(); openModelEditor(m.id); return; }
      const c = color === 'r' ? (Math.random() < 0.5 ? 'w' : 'b') : color;
      settings.play.color = color; saveSettings(); closeModal();
      startGame(c === 'w' ? { w: HUMAN, b: p } : { w: p, b: HUMAN });
    };
  }
  function openCustomSheet() {
    openModal('<div class="center"><div class="big-av">' + avatarHtml(customPlayer(settings.custom.elo)) + '</div><h3>Custom strength <span class="muted" id="csLabel"></span></h3><p class="muted">Stockfish limited to the Elo you choose. Below 1320 it plays with deliberate human-like mistakes.</p></div>' +
      '<input type="range" id="csElo" min="300" max="3200" step="50"><div class="seg" id="psColor"><button type="button" data-v="w">White</button><button type="button" data-v="r">Random</button><button type="button" data-v="b">Black</button></div>' +
      '<div class="controls"><button class="btn primary" id="psPlay" type="button">Play</button><button class="btn" id="psNo" type="button">Cancel</button></div>');
    let color = settings.play.color;
    const el = $('csElo'), lab = $('csLabel'); el.value = settings.custom.elo;
    const upd = () => { lab.textContent = el.value >= 3200 ? '(Max)' : '(' + el.value + ')'; }; upd(); el.oninput = upd;
    setSeg('psColor', color); bindSeg('psColor', v => { color = v; setSeg('psColor', v); });
    $('psNo').onclick = closeModal;
    $('psPlay').onclick = () => {
      const elo = +el.value; settings.custom.elo = elo; settings.play.color = color; saveSettings(); closeModal();
      const p = customPlayer(elo >= 3200 ? null : elo), c = color === 'r' ? (Math.random() < 0.5 ? 'w' : 'b') : color;
      startGame(c === 'w' ? { w: HUMAN, b: p } : { w: p, b: HUMAN });
    };
  }
  function openMenu() {
    const items = [['again', 'Rematch (swap colours)', 'rematch'], ['spark', 'Analyze with Coach', 'coach'], ['copy', 'Copy FEN', 'fen'], ['copy', 'Copy PGN', 'pgn'], ['share', 'Share PGN', 'share']];
    if (!over && modeOf() !== 'ava') items.push(['flag', 'Resign', 'resign']);
    items.push(['exit', 'Back to lobby', 'lobby']);
    openModal('<h3>Game menu</h3>' + items.map(i => '<button class="menu-item" data-m="' + i[2] + '" type="button">' + ic(i[0]) + '<span>' + i[1] + '</span></button>').join(''));
    $('modalCard').onclick = async e => {
      const b = e.target.closest('[data-m]'); if (!b) return;
      const a = b.getAttribute('data-m'); closeModal();
      if (a === 'rematch') rematch(); else if (a === 'coach') showTab('coach'); else if (a === 'fen') copyText(exportFen(), 'FEN');
      else if (a === 'pgn') copyText(exportPgn(), 'PGN'); else if (a === 'share') { if (!Native.share('ChessBuddy game (PGN)', exportPgn())) copyText(exportPgn(), 'PGN'); }
      else if (a === 'resign') { if (await confirmDialog('Resign this game?', 'Resign', true)) resign(modeOf() === 'hva' ? humanSide() : game.turn()); }
      else if (a === 'lobby') showPlayScreen('lobby');
    };
  }

  /* ================= coach ================= */
  let chatLog = [], askBusy = false, askAborted = false, askHandle = null;
  const coachModel = () => modelById(settings.coach.modelId) || settings.models[0] || null;

  function renderCoachSettings() {
    const sel = $('modelSelect');
    sel.innerHTML = settings.models.map(m => '<option value="' + m.id + '">' + esc(Models.displayName(m)) + (modelReady(m) ? '' : ' (no key)') + '</option>').join('') || '<option value="">No models</option>';
    const cm = coachModel(); if (cm) sel.value = cm.id;
    $('togShot').checked = settings.coach.screenshot;
    const hintBox = $('coachSetupHint'), ready = cm && Native.available && modelReady(cm);
    hintBox.hidden = !!ready;
    hintBox.textContent = !cm ? 'Add an AI model in Settings → AI models.' : !Native.available ? 'The coach needs the Android app (requests go through it).' : 'Add an API key for ' + Models.displayName(cm) + ' in Settings → AI models. Stockfish analysis works without it.';
  }
  function renderCoachMini() {
    if (currentTab !== 'coach') return;
    Board.draw($('coachBoard'), game, { flipped: ctx.flipped, last: lastMove, check: Board.checkSquare(game), coords: false });
    const la = lastAnalysis && lastAnalysis.fen === game.fen() && lastAnalysis.lines[0] ? Eng.scoreToWhite(lastAnalysis.lines[0].score, game.turn()) : ctx.evalWhite;
    paintEval('coachEvalFill', 'coachEvalText', 'coachEvalV', la, ctx.flipped);
    $('coachMeta').textContent = (over ? over.text : (game.turn() === 'w' ? 'White' : 'Black') + ' to move') + ' · ' + game.history().length + ' moves' + (la ? ' · ' + Eng.formatScore(la) : '');
  }
  function renderLines(fen, lines) {
    const host = $('coachLines');
    if (!lines || !lines.length) { host.innerHTML = ''; return; }
    const turn = fen.split(' ')[1];
    host.innerHTML = lines.map(l => '<div class="line"><b>' + esc(Eng.formatScore(Eng.scoreToWhite(l.score, turn))) + '</b><span>' + esc(Prompts.pvToSan(fen, l.pv, 8).join(' ')) + ' <span class="muted tiny">d' + (l.depth || '?') + '</span></span></div>').join('');
  }
  let analyzeRaf = 0;
  async function doAnalyze() {
    if (engine.state === 'dead' && !Native.available) throw new Eng.EngineError('dead', 'Stockfish only runs inside the Android app.');
    const fen = game.fen(); let latest = {};
    $('btnAnalyze').disabled = true; $('coachLines').innerHTML = '<div class="muted">Stockfish is analysing…</div>';
    try {
      const res = await runAnalysis({ ms: settings.engine.analysisMs, multipv: 3, onInfo: (info, byPv) => {
        latest = byPv; if (!analyzeRaf) analyzeRaf = requestAnimationFrame(() => { analyzeRaf = 0; renderLines(fen, Object.keys(latest).map(k => latest[k]).sort((a, b) => a.multipv - b.multipv)); });
      } });
      if (res.cancelled) { $('coachLines').innerHTML = '<div class="muted">Analysis interrupted.</div>'; return null; }
      renderLines(fen, res.lines); lastAnalysis = { fen, lines: res.lines }; renderCoachMini();
      return lastAnalysis;
    } finally { $('btnAnalyze').disabled = false; }
  }

  async function runReview(onProgress) {
    const h = game.history({ verbose: true });
    if (h.length < 2) { toast('Play a few moves first'); return null; }
    const my = ++reviewTok, startFen = startFenOf(game), moves = uciHistory(game);
    const ms = Math.max(250, Math.min(600, Math.round(settings.engine.analysisMs / 3))), positions = [];
    for (let i = 0; i <= h.length; i++) {
      if (my !== reviewTok) return null;
      if (onProgress) onProgress(i, h.length);
      if (i === h.length && game.isGameOver()) { positions.push({ score: game.isCheckmate() ? { type: 'mate', value: 0 } : { type: 'cp', value: 0 }, best: null }); continue; }
      const r = await runAnalysis({ startFen, moves: moves.slice(0, i), ms, multipv: 1 });
      if (r.cancelled || my !== reviewTok) return null;
      const l = r.lines[r.lines.length - 1]; positions.push({ score: l ? l.score : null, best: r.bestmove });
    }
    const result = Review.compute(h, positions);
    result.table = Review.table(h, result, i => (positions[i] && positions[i].best ? Prompts.pvToSan(h[i].before, [positions[i].best], 1)[0] : null));
    result.plies = h.length;
    reviewResult = result; renderReview();
    return result;
  }
  function renderReview() {
    const box = $('reviewBox');
    if (!reviewResult) { box.hidden = true; return; }
    const s = reviewResult.summary; box.hidden = false;
    box.innerHTML = '<div class="rv-sum"><div class="rv-side"><b>' + s.w.accuracy + '%</b><span>White accuracy</span></div><div class="rv-side"><b>' + s.b.accuracy + '%</b><span>Black accuracy</span></div></div>' +
      '<div class="rv-list">' + reviewResult.rows.filter(r => r.cls).map(r => '<span class="rv ' + r.cls + '" title="' + Review.LABELS[r.cls] + '">' + Math.ceil(r.ply / 2) + (r.color === 'w' ? '.' : '…') + esc(r.san) + (r.cls === 'blunder' ? '??' : r.cls === 'mistake' ? '?' : r.cls === 'inaccuracy' ? '?!' : '') + '</span>').join('') + '</div>';
  }

  function addMsg(kind, text, opt) {
    const chat = $('chat'), d = document.createElement('div');
    if (kind === 'user') d.className = 'msg user', d.innerHTML = '<div class="who">You</div><div class="bubble"></div>', d.querySelector('.bubble').textContent = text;
    else if (kind === 'ai') {
      d.className = 'msg ai'; d.innerHTML = '<div class="who">' + esc(opt.who) + '</div><div class="bubble">' + renderMd(text) + '<button class="bcopy" type="button">Copy</button></div>';
      d.querySelector('.bcopy').onclick = () => copyText(text, 'Answer');
    } else {
      d.className = 'msg'; const b = document.createElement('div'); b.className = 'bubble ' + (kind === 'err' ? 'err' : 'sys');
      if (kind === 'err' && opt && opt.settings) { b.innerHTML = '<div></div><div class="controls tight"><button class="btn small" type="button">Open settings</button></div>'; b.firstChild.textContent = text; b.querySelector('button').onclick = () => showTab('settings'); }
      else b.textContent = text;
      d.appendChild(b);
    }
    chat.appendChild(d); chat.scrollTop = chat.scrollHeight; return d;
  }
  function renderMd(src) {
    const inline = s => esc(s).replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/`([^`]+)`/g, '<code>$1</code>');
    return String(src).replace(/\r/g, '').split(/\n{2,}/).map(block => {
      const lines = block.split('\n').filter(l => l.trim());
      if (!lines.length) return '';
      if (lines.every(l => /^\s*[-*•]\s+/.test(l))) return '<ul>' + lines.map(l => '<li>' + inline(l.replace(/^\s*[-*•]\s+/, '')) + '</li>').join('') + '</ul>';
      if (lines.every(l => /^\s*\d+[.)]\s+/.test(l))) return '<ol>' + lines.map(l => '<li>' + inline(l.replace(/^\s*\d+[.)]\s+/, '')) + '</li>').join('') + '</ol>';
      if (/^#{1,4}\s+/.test(lines[0])) return '<p><strong>' + inline(lines[0].replace(/^#{1,4}\s+/, '')) + '</strong></p>' + (lines.length > 1 ? '<p>' + lines.slice(1).map(inline).join('<br>') + '</p>' : '');
      return '<p>' + lines.map(inline).join('<br>') + '</p>';
    }).join('');
  }
  function setAskUi(busy) {
    $('btnAsk').disabled = busy; $('coachInput').disabled = busy; $('btnCoachCancel').hidden = !busy;
    document.querySelectorAll('#chips .chip-btn').forEach(c => { c.disabled = busy; });
  }
  const coachOpponent = () => (modeOf() === 'hva' ? descPlayer(playerOf(humanSide() === 'w' ? 'b' : 'w')) : modeOf() === 'ava' ? ctx.players.w.name + ' (White) vs ' + ctx.players.b.name + ' (Black)' : 'two human players');

  async function doAsk(question, quickId) {
    if (askBusy) return;
    question = (question || '').trim();
    if (!question) { toast('Type a question first'); return; }
    const model = coachModel();
    if (!model) { addMsg('err', 'Add an AI model first.', { settings: true }); return; }
    if (!Native.available) { addMsg('err', 'The coach sends requests through the ChessBuddy Android app, so it cannot run in a plain browser.'); return; }
    if (!modelReady(model)) { addMsg('err', Coach.transportError('nokey').message, { settings: true }); return; }
    askBusy = true; askAborted = false; setAskUi(true);
    addMsg('user', question); $('coachInput').value = '';
    const note = addMsg('sys', 'Preparing the position…'), noteText = t => { note.firstChild.textContent = t; };
    try {
      const fen = game.fen();
      let analysis = lastAnalysis && lastAnalysis.fen === fen ? lastAnalysis : null;
      if (!analysis && engine.state !== 'dead') { noteText('Stockfish is analysing the position…'); try { analysis = await doAnalyze(); } catch (e) { analysis = null; } }
      let prev = null, review = null;
      const hist = game.history({ verbose: true });
      if (quickId === 'last' && hist.length && engine.state !== 'dead') {
        noteText('Stockfish is checking the position before the last move…');
        try { const r = await runAnalysis({ startFen: startFenOf(game), moves: uciHistory(game).slice(0, -1), ms: Math.min(settings.engine.analysisMs, 1500), multipv: 2 }); if (!r.cancelled) prev = { fen: hist[hist.length - 1].before, san: hist[hist.length - 1].san, lines: r.lines }; } catch (e) { prev = null; }
      }
      if (quickId === 'review') {
        if (engine.state === 'dead') { note.remove(); addMsg('err', 'A full review needs Stockfish, which is not running.'); return; }
        const rr = reviewResult || await runReview((i, n) => noteText('Stockfish is reviewing every move… ' + i + '/' + n));
        review = rr ? rr.table : null;
        if (!review) { note.remove(); addMsg('sys', 'Review cancelled.'); return; }
      }
      if (askAborted) { note.remove(); addMsg('sys', 'Cancelled.'); return; }
      noteText('Sending the position to ' + Models.displayName(model) + '…');
      const shot = await maybeShot(model);
      const report = Prompts.positionReport({ game, analysis, prev, review, playerColor: humanSide(), opponent: coachOpponent(), hasImage: !!shot });
      const userMsg = Prompts.coachUserMessage(report, question);
      const msgs = chatLog.slice(-4).map(x => ({ role: x.role, content: x.content })).concat([{ role: 'user', content: userMsg }]);
      const r = await callModel(model, { system: quickId === 'review' ? Prompts.SYSTEM_REVIEW : Prompts.SYSTEM_COACH, messages: msgs, images: shot ? [shot] : [],
        maxTokens: quickId === 'review' ? 1800 : 1200, aborted: () => askAborted, onHandle: h => { askHandle = h; } });
      note.remove();
      if (r.kind === 'cancelled') { addMsg('sys', 'Cancelled.'); return; }
      if (!r.ok) { addMsg('err', r.message, { settings: ['auth', 'nokey', 'config'].indexOf(r.kind) >= 0 }); return; }
      if (r.empty) { addMsg('err', 'The model returned no text (it may have spent its whole token budget on reasoning). Try again or pick another model.'); return; }
      chatLog.push({ role: 'user', content: '(Earlier question, about an earlier position) ' + question }, { role: 'assistant', content: r.text });
      if (chatLog.length > 8) chatLog = chatLog.slice(-8);
      addMsg('ai', r.text, { who: Models.displayName(model) });
    } catch (e) { note.remove(); addMsg('err', 'Something went wrong: ' + (e && e.message ? e.message : e)); }
    finally { askBusy = false; askHandle = null; setAskUi(false); }
  }

  /* ================= archive ================= */
  function badgeFor(g) {
    if (!g.done) return '<span class="badge">…</span>';
    if (g.human && g.result !== '1/2-1/2') return g.result === (g.human === 'w' ? '1-0' : '0-1') ? '<span class="badge win">Win</span>' : '<span class="badge loss">Loss</span>';
    if (g.result === '1/2-1/2') return '<span class="badge draw">Draw</span>';
    return '<span class="badge">' + esc(g.result) + '</span>';
  }
  function renderHistory() {
    const list = lsGet(K_GAMES, []), host = $('historyList');
    if (!list.length) { host.innerHTML = '<p class="muted">No games yet. Finished games are saved here automatically.</p>'; return; }
    host.innerHTML = list.map((g, i) => '<div class="hitem" data-i="' + i + '" role="button" tabindex="0">' + badgeFor(g) + '<div class="hbody"><b>' + esc(g.white) + ' vs ' + esc(g.black) + '</b><small>' + esc(fmtDate(g.date)) + ' · ' + g.plies + ' moves · ' + esc(g.resultText) + '</small></div></div>').join('');
  }
  function openGameSheet(i) {
    const list = lsGet(K_GAMES, []), rec = list[i]; if (!rec) return;
    openModal('<h3>' + esc(rec.white) + ' vs ' + esc(rec.black) + '</h3><p class="muted tiny">' + esc(fmtDate(rec.date)) + ' · ' + esc(rec.resultText) + '</p>' +
      [['play', 'Replay', 'replay'], ['spark', 'Open in Play / Coach', 'load'], ['copy', 'Copy PGN', 'copy'], ['share', 'Share PGN', 'share'], ['flag', 'Delete', 'del']].map(x => '<button class="menu-item" data-g="' + x[2] + '" type="button">' + ic(x[0]) + '<span>' + x[1] + '</span></button>').join(''));
    $('modalCard').onclick = async e => {
      const b = e.target.closest('[data-g]'); if (!b) return;
      const a = b.getAttribute('data-g'); closeModal();
      if (a === 'replay') openReplay(rec); else if (a === 'copy') copyText(rec.pgn, 'PGN');
      else if (a === 'share') { if (!Native.share('ChessBuddy game (PGN)', rec.pgn)) copyText(rec.pgn, 'PGN'); }
      else if (a === 'load') { const g = new Chess(); try { g.loadPgn(rec.pgn); await loadImported(g); } catch (er) { toast('Could not open this game'); } }
      else if (a === 'del' && await confirmDialog('Delete this game from the archive?', 'Delete', true)) { list.splice(i, 1); lsSet(K_GAMES, list); renderHistory(); }
    };
  }
  function openReplay(rec) {
    const g = new Chess();
    try { g.loadPgn(rec.pgn); } catch (e) { toast('Could not open this game'); return; }
    const mv = g.history({ verbose: true }); let ply = mv.length;
    openModal('<h3>' + esc(rec.resultText) + '</h3><div class="muted tiny">' + esc(rec.white) + ' vs ' + esc(rec.black) + '</div><div class="rpl-board"><div id="rplBoard" class="board"></div></div><div class="center muted" id="rplInfo"></div>' +
      '<div class="rpl-ctl"><button class="btn" id="rplFirst" type="button">⏮</button><button class="btn" id="rplPrev" type="button">◀</button><button class="btn" id="rplNext" type="button">▶</button><button class="btn" id="rplLast" type="button">⏭</button></div><div class="controls" style="justify-content:center"><button class="btn small" id="rplClose" type="button">Close</button></div>');
    const draw = () => {
      const fen = ply === 0 ? (mv.length ? mv[0].before : g.fen()) : mv[ply - 1].after, v = new Chess(fen);
      Board.draw($('rplBoard'), v, { flipped: rec.human === 'b', last: ply ? { from: mv[ply - 1].from, to: mv[ply - 1].to } : null, check: Board.checkSquare(v), coords: true });
      $('rplInfo').textContent = ply === 0 ? 'Start position' : 'Move ' + Math.ceil(ply / 2) + (mv[ply - 1].color === 'w' ? '' : '…') + ' ' + mv[ply - 1].san + '  (' + ply + '/' + mv.length + ')';
      $('rplFirst').disabled = $('rplPrev').disabled = ply === 0; $('rplNext').disabled = $('rplLast').disabled = ply === mv.length;
    };
    $('rplFirst').onclick = () => { ply = 0; draw(); }; $('rplPrev').onclick = () => { ply = Math.max(0, ply - 1); draw(); };
    $('rplNext').onclick = () => { ply = Math.min(mv.length, ply + 1); draw(); }; $('rplLast').onclick = () => { ply = mv.length; draw(); };
    $('rplClose').onclick = closeModal; draw();
  }

  /* ================= settings ================= */
  function renderSettings() {
    $('modelList').innerHTML = settings.models.map(m => {
      const p = llmPlayer(m), ok = modelReady(m);
      return '<div class="mrow" data-model="' + m.id + '" role="button" tabindex="0">' + avatarHtml(p) + '<div class="hbody"><b>' + esc(p.name) + '</b><small>' + esc(Models.providerLabel(m)) + ' · ' + esc(m.model) + ' · ' + (ok ? 'key saved ✓' : 'no API key') + '</small></div></div>';
    }).join('') || '<p class="muted">No models yet.</p>';
    $('setCoachModel').innerHTML = settings.models.map(m => '<option value="' + m.id + '">' + esc(Models.displayName(m)) + '</option>').join('');
    const cm = coachModel(); if (cm) $('setCoachModel').value = cm.id;
    $('setShot').checked = settings.coach.screenshot;
    $('setThreads').value = String(settings.engine.threads); $('setHash').value = String(settings.engine.hash);
    $('setTime').value = String(settings.play.movetime); $('setAnalysisMs').value = String(settings.engine.analysisMs);
    $('togEval').checked = settings.ui.eval; $('togCoords').checked = settings.ui.coords; $('togLast').checked = settings.ui.last; $('togLegal').checked = settings.ui.legal;
    setSeg('themeSeg', settings.ui.theme); renderEngineUi();
    $('aboutVersion').textContent = 'ChessBuddy ' + (dev.version || '') + (dev.versionCode ? ' (build ' + dev.versionCode + ')' : '') + ' · ' + (dev.abi || 'web') + ' · Android API ' + (dev.sdk || '–') + ' · ' + (dev.cores || '?') + ' cores';
  }

  function openModelEditor(id) {
    const existing = id ? modelById(id) : null;
    const d = existing ? Object.assign({}, existing) : { id: Models.newId(), provider: 'anthropic', baseUrl: Coach.PROVIDERS.anthropic.baseUrl, model: '', label: '', tokenParam: 'auto', vision: true };
    openModal('<h3>' + (existing ? esc(Models.displayName(d)) : 'Add a model') + '</h3>' +
      '<div class="seg" id="mdProvider"><button type="button" data-v="anthropic">Claude</button><button type="button" data-v="openai">OpenAI-compatible</button></div>' +
      '<div class="field"><label for="mdModel">Model name</label><input id="mdModel" type="text" list="mdModels" autocapitalize="off" autocomplete="off" spellcheck="false"><datalist id="mdModels"></datalist></div>' +
      '<div class="field"><label for="mdName">Display name (optional)</label><input id="mdName" type="text" autocomplete="off" placeholder="Shown instead of the model id"></div>' +
      '<div class="field" id="mdPresetRow"><label for="mdPreset">Service</label><select id="mdPreset"></select></div>' +
      '<div class="field"><label for="mdBase">API base URL</label><input id="mdBase" type="url" inputmode="url" autocapitalize="off" autocomplete="off" spellcheck="false"></div>' +
      '<div class="field"><label for="mdKey">API key</label><input id="mdKey" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Paste key"><div id="mdKeyState" class="muted tiny"></div></div>' +
      '<div class="field" id="mdTokenRow"><label for="mdToken">Max-token parameter</label><select id="mdToken"><option value="auto">Auto</option><option value="max_tokens">max_tokens</option><option value="max_completion_tokens">max_completion_tokens</option><option value="omit">Omit</option></select></div>' +
      '<label class="toggle"><input type="checkbox" id="mdVision"><span>Accepts images (board screenshots)</span></label><div id="mdMsg" class="notice" hidden></div>' +
      '<div class="controls"><button class="btn primary" id="mdSave" type="button">Save</button><button class="btn" id="mdTest" type="button">Test</button><button class="btn" id="mdClearKey" type="button">Remove key</button>' + (existing ? '<button class="btn danger" id="mdDel" type="button">Delete</button>' : '') + '<button class="btn" id="mdNo" type="button">Close</button></div>');
    const kid = () => Models.keyId(d.provider, Coach.normalizeBaseUrl($('mdBase').value) || d.baseUrl);
    const msg = (t, k) => { const m = $('mdMsg'); m.hidden = !t; m.className = 'notice ' + (k || ''); m.textContent = t || ''; };
    const refresh = () => {
      setSeg('mdProvider', d.provider);
      $('mdPresetRow').hidden = $('mdTokenRow').hidden = d.provider !== 'openai';
      $('mdModels').innerHTML = Coach.PROVIDERS[d.provider].suggested.map(m => '<option value="' + esc(m) + '"></option>').join('');
      $('mdModel').placeholder = d.provider === 'anthropic' ? 'e.g. claude-sonnet-5-5' : 'Model name from your provider';
      $('mdPreset').innerHTML = '<option value="">Custom</option>' + Coach.BASE_URL_PRESETS.map(x => '<option value="' + esc(x.url) + '">' + esc(x.label) + '</option>').join('');
      $('mdPreset').value = Coach.BASE_URL_PRESETS.some(x => x.url === Coach.normalizeBaseUrl($('mdBase').value)) ? Coach.normalizeBaseUrl($('mdBase').value) : '';
      const has = Native.hasKey(kid()), host = Models.hostOf($('mdBase').value) || 'this provider';
      $('mdKeyState').textContent = !Native.available ? 'Key storage works only inside the Android app.' : has ? 'A key is saved for ' + host + (Native.keyHint(kid()) ? ' (…' + Native.keyHint(kid()) + ')' : '') + ' and is shared by every model on this account. Leave blank to keep it.' : 'No key saved for ' + host + ' yet.';
      $('mdClearKey').disabled = !has;
    };
    $('mdModel').value = d.model; $('mdName').value = d.label || ''; $('mdBase').value = d.baseUrl; $('mdToken').value = d.tokenParam || 'auto'; $('mdVision').checked = d.vision !== false;
    refresh();
    bindSeg('mdProvider', v => { d.provider = v; $('mdBase').value = Coach.PROVIDERS[v].baseUrl; refresh(); });
    $('mdPreset').onchange = e => { if (e.target.value) { $('mdBase').value = e.target.value; refresh(); } };
    $('mdBase').oninput = refresh;
    const readDraft = () => { d.model = $('mdModel').value.trim(); d.label = $('mdName').value.trim(); d.baseUrl = Coach.normalizeBaseUrl($('mdBase').value) || Coach.PROVIDERS[d.provider].baseUrl; d.tokenParam = $('mdToken').value; d.vision = $('mdVision').checked; };
    const persistKey = () => { const k = $('mdKey').value.trim(); if (!k) return true; const ok = Native.setKey(kid(), k); if (ok) $('mdKey').value = ''; return ok; };
    $('mdNo').onclick = closeModal;
    $('mdSave').onclick = () => {
      readDraft();
      if (!d.model) { msg('Enter the model name.', 'bad'); return; }
      if (!/^https?:\/\//i.test(d.baseUrl)) { msg('The base URL must start with https:// (or http:// for a local server).', 'bad'); return; }
      if (!persistKey()) { msg('Could not save the key (invalid key, or storage unavailable).', 'bad'); return; }
      const i = settings.models.findIndex(m => m.id === d.id);
      if (i >= 0) settings.models[i] = d; else settings.models.push(d);
      if (!modelById(settings.coach.modelId)) settings.coach.modelId = d.id;
      saveSettings(); closeModal(); renderSettings(); renderCoachSettings(); renderLobbyResume(); toast('Saved ' + Models.displayName(d));
    };
    $('mdTest').onclick = async () => {
      readDraft(); if (!d.model) { msg('Enter the model name first.', 'bad'); return; }
      if (!persistKey()) { msg('Could not save the key.', 'bad'); return; }
      msg('Testing…'); const t0 = Date.now();
      const r = await callModel(d, { messages: [{ role: 'user', content: 'Reply with the single word OK.' }], maxTokens: 200 });
      if (r.ok) msg('Connected ✓ — ' + Models.displayName(d) + ' answered in ' + (Date.now() - t0) + ' ms' + (r.text ? ': ' + clip(r.text, 40) : ''), 'ok'); else msg(r.message, 'bad');
      refresh();
    };
    $('mdClearKey').onclick = async () => { Native.clearKey(kid()); refresh(); msg('Key removed.', 'ok'); };
    if (existing) $('mdDel').onclick = async () => {
      if (!(await confirmDialog('Delete ' + Models.displayName(d) + '? Its API key stays saved for other models on the same account.', 'Delete', true))) return;
      settings.models = settings.models.filter(m => m.id !== d.id);
      if (settings.coach.modelId === d.id) settings.coach.modelId = settings.models[0] ? settings.models[0].id : '';
      saveSettings(); closeModal(); renderSettings(); renderCoachSettings(); renderLobbyResume();
    };
  }

  async function selfTest() {
    const out = $('selfTestOut'); out.hidden = false; out.textContent = 'Starting Stockfish…';
    try {
      await engine.restart();
      const t0 = Date.now();
      const r = await engine.search({ moves: [], depth: 12, options: analysisOptions(1) });
      const l = r.lines[r.lines.length - 1] || {};
      out.textContent = ['PASS — real engine answered over UCI', 'Engine:    ' + engine.idName,
        'Search:    depth ' + (l.depth || '?') + ', ' + (l.nodes || '?') + ' nodes, ' + (l.nps ? Math.round(l.nps / 1000) + ' kn/s' : '? kn/s') + ', ' + (Date.now() - t0) + ' ms total',
        'Best move: ' + (r.bestmove || '(none)') + (r.bestmove ? ' (' + (Prompts.pvToSan(Eng.START_FEN, [r.bestmove], 1)[0] || '?') + ')' : ''), 'Eval:      ' + Eng.formatScore(l.score ? Eng.scoreToWhite(l.score, 'w') : null),
        'Threads/Hash: ' + (engine.current.Threads || '?') + ' / ' + (engine.current.Hash || '?') + ' MB',
        'Strength limiter: ' + (engine.hasOption('UCI_Elo') ? 'available (' + engine.optionRange('UCI_Elo').min + '–' + engine.optionRange('UCI_Elo').max + ')' : 'not offered — bots use handicap mode')].join('\n');
    } catch (e) { out.textContent = 'FAIL — ' + e.message; }
    renderEngineUi();
  }

  /* ================= lifecycle + wiring ================= */
  window.cbBack = function () {
    if (!$('modal').hidden) { closeModal(); return true; }
    if (!$('boardOverlay').hidden && playScreen === 'game' && currentTab === 'play') { hideOverlay(); return true; }
    if (currentTab !== 'play') { showTab('play'); return true; }
    if (playScreen !== 'lobby') { showPlayScreen('lobby'); return true; }
    return false;
  };
  window.cbOnPause = function () { if (modeOf() === 'ava' && !paused && !over) { paused = true; render(); } };
  window.cbOnResume = function () { renderEngineUi(); };
  const applyTheme = () => document.body.setAttribute('data-theme', settings.ui.theme);

  function restoreCurrent() {
    const s = lsGet(K_CUR, null);
    if (!s || !s.pgn || !s.players || !s.players.w || !s.players.b) return false;
    try {
      const g = new Chess(); g.loadPgn(s.pgn);
      game = g; ctx = newCtx(s.players); ctx.flipped = !!s.flipped; ctx.startedAt = s.startedAt || Date.now(); ctx.saved = !!s.saved; ctx.evalWhite = s.evalWhite || null;
      const h = g.history({ verbose: true });
      lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
      over = computeOver(); return true;
    } catch (e) { return false; }
  }

  function buildStaticUi() {
    hydrateIcons();
    $('riBots').innerHTML = '<svg viewBox="0 0 45 45"><use href="#wN"/></svg>'; $('riModels').innerHTML = ic('robot'); $('riAvA').innerHTML = ic('versus'); $('riFriend').innerHTML = ic('users');
    $('setThreads').innerHTML = [1, 2, 3, 4, 5, 6, 7, 8].map(n => '<option>' + n + '</option>').join('');
    $('chips').innerHTML = Prompts.QUICK_PROMPTS.map(q => '<button class="chip-btn" type="button" data-q="' + q.id + '">' + esc(q.label) + '</button>').join('') + '<button class="chip-btn" type="button" data-q="review">Explain whole game</button>';
  }

  function bindEvents() {
    document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => { const n = t.getAttribute('data-tab'); showTab(n); }));
    $('hdrBack').onclick = () => window.cbBack();
    $('enginePill').onclick = () => { showTab('settings'); $('cardEngine').scrollIntoView(); };
    $('rowBots').onclick = () => { botsTab = 'sf'; showPlayScreen('bots'); };
    $('rowModels').onclick = () => { botsTab = 'llm'; showPlayScreen('bots'); };
    $('rowAvA').onclick = openAvASheet;
    $('rowFriend').onclick = () => startGame({ w: HUMAN, b: HUMAN });
    $('btnResume').onclick = () => { showPlayScreen('game'); render(); scheduleMove(); };
    bindSeg('botsTabs', v => { botsTab = v; renderBots(); renderHeader(); });
    $('botsList').addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.hasAttribute('data-addmodel')) { openModelEditor(null); return; }
      if (b.hasAttribute('data-model')) { const m = modelById(b.getAttribute('data-model')); openOpponentSheet(llmPlayer(m), 'A language model that plays from the position description and a board image.'); return; }
      const id = b.getAttribute('data-bot');
      if (id === 'custom') openCustomSheet(); else { const bot = Str.botById(id); openOpponentSheet(sfPlayer(bot), bot.blurb); }
    });
    $('board').addEventListener('click', e => { const s = e.target.closest('.sq'); if (s) onSquareTap(s.getAttribute('data-sq')); });
    $('btnMenu').onclick = openMenu; $('btnUndo').onclick = undo; $('btnHint').onclick = doHint;
    $('btnFlip').onclick = () => { ctx.flipped = !ctx.flipped; saveCurrent(); render(); };
    $('btnPause').onclick = () => { paused = !paused; render(); if (!paused) scheduleMove(); else cancelEngine(); };
    $('btnRetryEngine').onclick = () => { engine.restart().catch(noop).then(() => { renderEngineUi(); render(); scheduleMove(); }); };

    // coach
    $('modelSelect').onchange = e => { settings.coach.modelId = e.target.value; saveSettings(); renderCoachSettings(); };
    $('togShot').onchange = e => { settings.coach.screenshot = e.target.checked; saveSettings(); };
    $('btnAnalyze').onclick = () => { doAnalyze().catch(e => { $('coachLines').innerHTML = '<div class="notice bad">' + esc(e.message) + '</div>'; }); };
    $('btnReview').onclick = async () => {
      const b = $('btnReview');
      if (b.dataset.running) { reviewTok++; return; }
      b.dataset.running = '1'; reviewResult = null; renderReview();
      try { await runReview((i, n) => { b.textContent = 'Stop (' + i + '/' + n + ')'; }); }
      catch (err) { toast(err.message); }
      finally { delete b.dataset.running; b.textContent = 'Review game'; renderReview(); }
    };
    $('chips').addEventListener('click', e => {
      const b = e.target.closest('.chip-btn'); if (!b) return; const id = b.getAttribute('data-q');
      if (id === 'review') doAsk(Prompts.REVIEW_PROMPT, 'review'); else { const q = Prompts.QUICK_PROMPTS.find(x => x.id === id); doAsk(q.text, q.id); }
    });
    $('btnAsk').onclick = () => doAsk($('coachInput').value, null);
    $('coachInput').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); doAsk($('coachInput').value, null); } });
    $('btnCoachCancel').onclick = () => { askAborted = true; if (askHandle) askHandle.cancel(); };
    $('btnClearChat').onclick = () => { chatLog = []; $('chat').innerHTML = ''; };

    // archive
    $('historyList').addEventListener('click', e => { const r = e.target.closest('.hitem'); if (r) openGameSheet(+r.getAttribute('data-i')); });
    $('btnImport').onclick = async () => {
      const r = parseImport($('importText').value);
      if (r.error) { $('importMsg').textContent = r.error; return; }
      if (await loadImported(r.game)) { $('importMsg').textContent = 'Loaded.'; $('importText').value = ''; }
    };

    // settings
    $('modelList').addEventListener('click', e => { const r = e.target.closest('.mrow'); if (r) openModelEditor(r.getAttribute('data-model')); });
    $('btnAddModel').onclick = () => openModelEditor(null);
    $('setCoachModel').onchange = e => { settings.coach.modelId = e.target.value; saveSettings(); };
    $('setShot').onchange = e => { settings.coach.screenshot = e.target.checked; saveSettings(); };
    $('setThreads').onchange = e => { settings.engine.threads = parseInt(e.target.value, 10); saveSettings(); };
    $('setHash').onchange = e => { settings.engine.hash = parseInt(e.target.value, 10); saveSettings(); };
    $('setTime').onchange = e => { settings.play.movetime = parseInt(e.target.value, 10); saveSettings(); };
    $('setAnalysisMs').onchange = e => { settings.engine.analysisMs = parseInt(e.target.value, 10); saveSettings(); };
    [['togEval', 'eval'], ['togCoords', 'coords'], ['togLast', 'last'], ['togLegal', 'legal']].forEach(([id, k]) => { $(id).onchange = e => { settings.ui[k] = e.target.checked; saveSettings(); render(); }; });
    bindSeg('themeSeg', v => { settings.ui.theme = v; saveSettings(); applyTheme(); setSeg('themeSeg', v); });
    $('btnSelfTest').onclick = selfTest;
    $('btnRestartEngine').onclick = () => { engine.restart().catch(noop).then(renderEngineUi); };
    $('btnClearHistory').onclick = async () => { if (await confirmDialog('Delete all saved games?', 'Delete all', true)) { lsDel(K_GAMES); renderHistory(); toast('Archive cleared'); } };
    $('btnResetSettings').onclick = async () => {
      if (await confirmDialog('Reset all settings to their defaults? Saved API keys are kept; remove them from each model.', 'Reset', true)) { settings = defaultSettings(); saveSettings(); applyTheme(); buildStaticUi(); render(); renderSettings(); toast('Settings reset'); }
    };
    $('modal').addEventListener('click', e => { if (e.target === $('modal')) closeModal(); });
  }

  function boot() {
    applyTheme(); buildStaticUi(); bindEvents();
    if (!restoreCurrent()) { setHeaders(); saveCurrent(); }
    render(); showTab('play'); showPlayScreen('lobby');
    startEngine().then(() => renderEngineUi());
  }
  window.__cb = { get game() { return game; }, get ctx() { return ctx; }, engine, settings: () => settings, get over() { return over; }, get thinking() { return thinking; } };   // read-only debugging handle
  boot();
})();
