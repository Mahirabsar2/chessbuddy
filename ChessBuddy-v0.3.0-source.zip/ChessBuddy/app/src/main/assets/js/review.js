/* ChessBuddy game review: classifies every move from Stockfish evaluations (centipawn loss). */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./strength.js'), require('./engine.js'));
  else root.CBReview = factory(root.CBStrength, root.CBEngine);
})(typeof window !== 'undefined' ? window : globalThis, function (Str, Eng) {
  'use strict';
  var LABELS = { best: 'Best', excellent: 'Excellent', good: 'Good', inaccuracy: 'Inaccuracy', mistake: 'Mistake', blunder: 'Blunder' };
  function classify(loss) {
    return loss <= 10 ? 'best' : loss <= 25 ? 'excellent' : loss <= 50 ? 'good' : loss <= 100 ? 'inaccuracy' : loss <= 250 ? 'mistake' : 'blunder';
  }
  function accuracy(acpl) { return Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * acpl) - 3.1669)); }

  /**
   * positions[i] = { score: engine score from the side to move, best: uci } for the position BEFORE move i (i = 0..N);
   * positions[N] is the final position. history = verbose chess.js history. Terminal final position: pass score mate/0.
   */
  function compute(history, positions) {
    var rows = [], side = { w: { loss: 0, n: 0, counts: {} }, b: { loss: 0, n: 0, counts: {} } };
    for (var i = 0; i < history.length; i++) {
      var m = history[i], cur = positions[i], nxt = positions[i + 1];
      if (!cur || !nxt || !cur.score || !nxt.score) { rows.push({ ply: i + 1, san: m.san, color: m.color, cls: null }); continue; }
      var played = m.from + m.to + (m.promotion || '');
      var bestEval = Str.cpOf(cur.score), afterEval = -Str.cpOf(nxt.score);
      var loss = played === cur.best ? 0 : Math.max(0, Math.min(1000, bestEval - afterEval));
      var cls = classify(loss);
      rows.push({ ply: i + 1, san: m.san, color: m.color, loss: Math.round(loss), cls: cls, best: cur.best, bestEval: cur.score, played: played });
      var s = side[m.color]; s.loss += loss; s.n++; s.counts[cls] = (s.counts[cls] || 0) + 1;
    }
    var summary = {};
    ['w', 'b'].forEach(function (c) { var s = side[c], a = s.n ? s.loss / s.n : 0; summary[c] = { acpl: Math.round(a), accuracy: Math.round(accuracy(a) * 10) / 10, counts: s.counts, moves: s.n }; });
    return { rows: rows, summary: summary };
  }

  /** Compact table for the AI model: one line per move. bestSan(i) must return SAN of the engine's best move at position i. */
  function table(history, result, bestSan, startFen) {
    var lines = result.rows.map(function (r, i) {
      var num = history[i].before.split(' ')[5];
      var head = (r.color === 'w' ? num + '. ' : num + '... ') + r.san + ' (' + (r.color === 'w' ? 'White' : 'Black') + ')';
      if (!r.cls) return head + ' — not analysed';
      var tail = r.cls === 'best' ? 'best move' : LABELS[r.cls] + ', lost ' + r.loss + ' cp, best was ' + (bestSan(i) || '?');
      return head + ' — ' + tail;
    });
    var s = result.summary;
    lines.push('Summary: White accuracy ' + s.w.accuracy + '% (avg loss ' + s.w.acpl + ' cp over ' + s.w.moves + ' moves), Black accuracy ' + s.b.accuracy + '% (avg loss ' + s.b.acpl + ' cp over ' + s.b.moves + ' moves).');
    return lines.join('\n');
  }
  return { classify: classify, accuracy: accuracy, compute: compute, table: table, LABELS: LABELS };
});
