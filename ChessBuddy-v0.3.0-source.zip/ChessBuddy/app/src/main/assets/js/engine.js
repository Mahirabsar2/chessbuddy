/* ChessBuddy UCI engine client.
 *
 * Speaks the UCI protocol to a real Stockfish process through a "transport":
 *   transport.start()  -> Promise<{ok:boolean, error?:string}>
 *   transport.send(line)
 *   transport.stop()
 *   transport.onLine = function (line) {}          (set by this module)
 *   transport.onExit = function (code, message) {} (set by this module)
 * The Android transport lives in native.js; tests use scripted transports.
 * There is deliberately NO built-in fallback engine: if Stockfish cannot run,
 * every call fails with a clear EngineError instead of playing fake moves. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBEngine = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  var START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

  function EngineError(kind, message) {
    this.name = 'EngineError';
    this.kind = kind;            // 'start' | 'timeout' | 'exited' | 'protocol' | 'dead'
    this.message = message;
    this.stack = (new Error(message)).stack;
  }
  EngineError.prototype = Object.create(Error.prototype);
  EngineError.prototype.constructor = EngineError;

  /* ---------- line parsers ---------- */

  var INFO_ARITY = { depth: 1, seldepth: 1, multipv: 1, nodes: 1, nps: 1, time: 1, hashfull: 1,
    tbhits: 1, currmovenumber: 1, currmove: 1, cpuload: 1, sbhits: 1, wdl: 3 };

  function parseInfo(line) {
    if (typeof line !== 'string' || line.indexOf('info ') !== 0) return null;
    var t = line.trim().split(/\s+/);
    var out = { depth: null, seldepth: null, multipv: 1, score: null, bound: null, nodes: null,
      nps: null, time: null, pv: [], string: null, wdl: null };
    for (var i = 1; i < t.length; i++) {
      var k = t[i];
      if (k === 'string') { out.string = t.slice(i + 1).join(' '); return out; }
      if (k === 'pv') { out.pv = t.slice(i + 1); return out; }
      if (k === 'refutation' || k === 'currline') return out;
      if (k === 'score') {
        var type = t[i + 1], val = parseInt(t[i + 2], 10);
        i += 2;
        if ((type === 'cp' || type === 'mate') && !isNaN(val)) out.score = { type: type, value: val };
        if (t[i + 1] === 'lowerbound' || t[i + 1] === 'upperbound') out.bound = t[++i];
        continue;
      }
      if (Object.prototype.hasOwnProperty.call(INFO_ARITY, k)) {
        var n = INFO_ARITY[k];
        if (k === 'depth' || k === 'seldepth' || k === 'multipv' || k === 'nodes' || k === 'nps' || k === 'time') {
          var num = parseInt(t[i + 1], 10);
          out[k] = isNaN(num) ? null : num;
        } else if (k === 'wdl') {
          out.wdl = [parseInt(t[i + 1], 10), parseInt(t[i + 2], 10), parseInt(t[i + 3], 10)];
        }
        i += n;
      }
    }
    return out;
  }

  var OPT_KEYS = { name: 1, type: 1, 'default': 1, min: 1, max: 1, 'var': 1 };
  function parseOption(line) {
    if (typeof line !== 'string' || line.indexOf('option name ') !== 0) return null;
    var t = line.trim().split(/\s+/);
    var o = { name: '', type: '', 'default': null, min: null, max: null, vars: [] };
    var cur = null, buf = [];
    function flush() {
      if (cur === null) return;
      var v = buf.join(' ');
      if (cur === 'name') o.name = v;
      else if (cur === 'type') o.type = v;
      else if (cur === 'default') o['default'] = v;
      else if (cur === 'min') o.min = parseInt(v, 10);
      else if (cur === 'max') o.max = parseInt(v, 10);
      else if (cur === 'var') o.vars.push(v);
      buf = [];
    }
    for (var i = 1; i < t.length; i++) {
      if (Object.prototype.hasOwnProperty.call(OPT_KEYS, t[i])) {
        flush(); cur = t[i];
      } else buf.push(t[i]);
    }
    flush();
    return o.name ? o : null;
  }

  function parseBestmove(line) {
    if (typeof line !== 'string' || line.indexOf('bestmove') !== 0) return null;
    var t = line.trim().split(/\s+/);
    var out = { move: t[1] || null, ponder: null };
    var p = t.indexOf('ponder');
    if (p > 0 && t[p + 1]) out.ponder = t[p + 1];
    return out;
  }

  /* ---------- score helpers (UCI scores are from the side to move) ---------- */

  function scoreToWhite(score, turn) {
    if (!score) return null;
    return { type: score.type, value: turn === 'w' ? score.value : -score.value };
  }
  function formatScore(score) {
    if (!score) return '–';
    if (score.type === 'mate') return (score.value < 0 ? '-' : '') + '#' + Math.abs(score.value);
    var v = score.value / 100;
    if (Math.abs(v) < 0.005) return '0.00';
    return (v > 0 ? '+' : '') + v.toFixed(2);
  }
  /** White's winning chances in percent (0..100), lichess-style logistic. */
  function whitePercent(score) {
    if (!score) return 50;
    if (score.type === 'mate') return score.value > 0 ? 100 : (score.value < 0 ? 0 : 50);
    var cp = Math.max(-1000, Math.min(1000, score.value));
    return 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * cp)) - 1);
  }

  /* ---------- command builders ---------- */

  function positionCommand(startFen, uciMoves) {
    var base = (!startFen || startFen === START_FEN) ? 'position startpos' : 'position fen ' + startFen;
    return uciMoves && uciMoves.length ? base + ' moves ' + uciMoves.join(' ') : base;
  }
  function goCommand(req) {
    if (req.depth) return 'go depth ' + (req.depth | 0);
    if (req.nodes) return 'go nodes ' + (req.nodes | 0);
    return 'go movetime ' + Math.max(50, (req.movetime | 0) || 1000);
  }
  function uciMovesFromHistory(verboseHistory) {
    return verboseHistory.map(function (m) { return m.from + m.to + (m.promotion || ''); });
  }
  function sanitizeLine(line) { return String(line).replace(/[\r\n]+/g, ' ').trim(); }

  /* ---------- the engine ---------- */

  function UciEngine(transport, opts) {
    opts = opts || {};
    this.t = transport;
    this.startTimeoutMs = opts.startTimeoutMs || 15000;
    this.readyTimeoutMs = opts.readyTimeoutMs || 15000;
    this.searchGraceMs = opts.searchGraceMs || 10000;
    this.state = 'idle';           // idle | starting | ready | dead
    this.options = {};             // name -> parsed option
    this.current = {};             // name -> last value we sent
    this.idName = '';
    this.idAuthor = '';
    this.criticalError = null;
    this.lastError = null;
    this.onState = null;           // optional (state, detail) => void
    this._waiters = [];
    this._search = null;
    this._startPromise = null;
    this._lock = Promise.resolve();   // serializes searches
    this._needSync = false;           // set after a timeout: drain stale bestmove with isready
    var self = this;
    transport.onLine = function (l) { self._onLine(l); };
    transport.onExit = function (c, m) { self._onExit(c, m); };
  }

  UciEngine.prototype._setState = function (s, detail) {
    this.state = s;
    if (typeof this.onState === 'function') { try { this.onState(s, detail || ''); } catch (e) { /* ignore UI errors */ } }
  };

  UciEngine.prototype._onLine = function (raw) {
    var line = String(raw).trim();
    if (!line) return;
    if (line.indexOf('id name ') === 0) this.idName = line.slice(8);
    else if (line.indexOf('id author ') === 0) this.idAuthor = line.slice(10);
    else if (line.indexOf('option name ') === 0) {
      var o = parseOption(line);
      if (o) this.options[o.name] = o;
    } else if (line.indexOf('info string CRITICAL ERROR') === 0 || line.indexOf('CRITICAL ERROR') !== -1) {
      this.criticalError = line;
    }
    // waiters (uciok / readyok)
    for (var i = this._waiters.length - 1; i >= 0; i--) {
      var w = this._waiters[i];
      if (w.test(line)) { this._waiters.splice(i, 1); clearTimeout(w.timer); w.resolve(line); }
    }
    // active search
    var s = this._search;
    if (!s) return;
    if (line.indexOf('info ') === 0) {
      var info = parseInfo(line);
      if (info && info.pv.length && info.score) {
        var prev = s.byPv[info.multipv];
        if (!(info.bound && prev && prev.depth === info.depth)) {
          s.byPv[info.multipv] = info;
          if (typeof s.onInfo === 'function') { try { s.onInfo(info, s.byPv); } catch (e) { /* ignore */ } }
        }
      }
    } else if (line.indexOf('bestmove') === 0) {
      this._finishSearch(parseBestmove(line));
    }
  };

  UciEngine.prototype._finishSearch = function (bm) {
    var s = this._search;
    if (!s) return;
    this._search = null;
    clearTimeout(s.timer);
    var lines = Object.keys(s.byPv).map(function (k) { return s.byPv[k]; })
      .sort(function (a, b) { return a.multipv - b.multipv; });
    var move = bm && bm.move;
    s.resolve({
      bestmove: move && move !== '(none)' && move !== '0000' ? move : null,
      ponder: bm ? bm.ponder : null,
      none: !move || move === '(none)' || move === '0000',
      cancelled: s.cancelled,
      lines: lines,
      elapsedMs: Date.now() - s.t0,
      searchId: s.id
    });
  };

  UciEngine.prototype._failAll = function (err) {
    var w = this._waiters; this._waiters = [];
    w.forEach(function (x) { clearTimeout(x.timer); x.reject(err); });
    var s = this._search;
    if (s) { this._search = null; clearTimeout(s.timer); s.reject(err); }
  };

  UciEngine.prototype._onExit = function (code, message) {
    var detail = message || 'Engine process exited';
    if (this.criticalError) detail += ' — ' + this.criticalError;
    var err = new EngineError('exited', detail);
    this.lastError = err;
    this.current = {};
    this._setState('dead', detail);
    this._failAll(err);
  };

  UciEngine.prototype._waitFor = function (test, ms, label) {
    var self = this;
    return new Promise(function (resolve, reject) {
      var w = { test: test, resolve: resolve, reject: reject, timer: null };
      w.timer = setTimeout(function () {
        var i = self._waiters.indexOf(w);
        if (i >= 0) self._waiters.splice(i, 1);
        reject(new EngineError('timeout', 'Engine did not answer (' + label + ') within ' + Math.round(ms / 1000) + 's'));
      }, ms);
      self._waiters.push(w);
    });
  };

  UciEngine.prototype._send = function (line) { this.t.send(sanitizeLine(line)); };

  UciEngine.prototype._ready = function () {
    var w = this._waitFor(function (l) { return l === 'readyok'; }, this.readyTimeoutMs, 'readyok');
    this._send('isready');
    return w;
  };

  /** Starts the process and completes the uci/isready handshake. */
  UciEngine.prototype.start = function () {
    var self = this;
    if (this.state === 'ready') return Promise.resolve(this);
    if (this._startPromise) return this._startPromise;
    this._startPromise = (function () {
      self._setState('starting');
      self.options = {}; self.current = {}; self.criticalError = null;
      return Promise.resolve(self.t.start()).then(function (r) {
        if (!r || !r.ok) throw new EngineError('start', (r && r.error) || 'Stockfish failed to start');
        var ok = self._waitFor(function (l) { return l === 'uciok'; }, self.startTimeoutMs, 'uciok');
        self._send('uci');
        return ok;
      }).then(function () { return self._ready(); })
        .then(function () { self._setState('ready', self.idName); return self; });
    })().then(function (v) { self._startPromise = null; return v; }, function (e) {
      self._startPromise = null;
      self.lastError = e;
      self._setState('dead', e.message);
      try { self.t.stop(); } catch (x) { /* ignore */ }
      throw e;
    });
    return this._startPromise;
  };

  UciEngine.prototype.restart = function () {
    var self = this;
    try { this.t.stop(); } catch (e) { /* ignore */ }
    this._failAll(new EngineError('exited', 'Engine restarted'));
    this.state = 'idle';
    return this.start();
  };

  UciEngine.prototype.ensureReady = function () {
    if (this.state === 'ready') return Promise.resolve(this);
    if (this.state === 'dead' || this.state === 'idle') return this.restart();
    return this.start();
  };

  UciEngine.prototype.hasOption = function (name) { return Object.prototype.hasOwnProperty.call(this.options, name); };
  UciEngine.prototype.optionRange = function (name) {
    var o = this.options[name];
    return o && typeof o.min === 'number' && typeof o.max === 'number' ? { min: o.min, max: o.max, def: o['default'] } : null;
  };

  /** Sends only the options that changed; clamps spin values to the engine's range. */
  UciEngine.prototype.setOptions = function (map) {
    var self = this, sent = 0, skipped = [];
    Object.keys(map).forEach(function (name) {
      var opt = self.options[name];
      if (!opt) { skipped.push(name); return; }
      var v = map[name];
      if (opt.type === 'spin') {
        v = Math.round(Number(v));
        if (isNaN(v)) return;
        if (typeof opt.min === 'number') v = Math.max(opt.min, v);
        if (typeof opt.max === 'number') v = Math.min(opt.max, v);
      } else if (opt.type === 'check') {
        v = (v === true || v === 'true') ? 'true' : 'false';
      } else if (opt.type === 'button') {
        return;
      }
      v = String(v);
      if (self.current[name] === v) return;
      self._send('setoption name ' + name + ' value ' + v);
      self.current[name] = v;
      sent++;
    });
    var p = sent ? this._ready() : Promise.resolve();
    return p.then(function () { return { sent: sent, skipped: skipped }; });
  };

  UciEngine.prototype.newGame = function () {
    this._send('ucinewgame');
    return this._ready();
  };

  var CANCELLED = function () {
    return { bestmove: null, ponder: null, none: false, cancelled: true, lines: [], elapsedMs: 0, searchId: 0 };
  };

  /**
   * Runs one search; a newer search cancels a running one ("latest wins").
   * req: { startFen, moves: [uci], movetime | depth | nodes, options: {name: value},
   *        onInfo(info, byPv), isStale() }
   * Resolves { bestmove|null, none, cancelled, lines:[info per multipv], elapsedMs }.
   */
  UciEngine.prototype.search = function (req) {
    var self = this;
    if (this._search) this.stop();
    var run = function () {
      if (req.isStale && req.isStale()) return Promise.resolve(CANCELLED());
      return self.ensureReady()
        .then(function () {
          if (!self._needSync) return null;
          self._needSync = false;
          return self._ready();
        })
        .then(function () { return req.options ? self.setOptions(req.options) : null; })
        .then(function () {
          if (req.isStale && req.isStale()) return CANCELLED();
          return new Promise(function (resolve, reject) {
            var graceBase = req.depth || req.nodes ? 120000 : ((req.movetime | 0) || 1000);
            var s = { id: (self._nextId = (self._nextId || 0) + 1), resolve: resolve, reject: reject, byPv: {},
              onInfo: req.onInfo, cancelled: false, t0: Date.now(), timer: null };
            s.timer = setTimeout(function () {
              if (self._search !== s) return;
              self._search = null;
              self._needSync = true;
              try { self._send('stop'); } catch (e) { /* ignore */ }
              s.reject(new EngineError('timeout', 'Stockfish did not return a move in time'));
            }, graceBase + self.searchGraceMs);
            self._search = s;
            self._send(positionCommand(req.startFen, req.moves || []));
            self._send(goCommand(req));
          });
        });
    };
    var p = this._lock.then(run, run);
    this._lock = p.then(function () {}, function () {});
    return p;
  };

  /** Cancels the running search (if any); resolves after the engine's bestmove arrives. */
  UciEngine.prototype.stop = function () {
    var s = this._search;
    if (!s) return Promise.resolve();
    s.cancelled = true;
    try { this._send('stop'); } catch (e) { /* ignore */ }
    return new Promise(function (res) {
      var done = function () { res(); };
      s.resolve = (function (orig) { return function (v) { orig(v); done(); }; })(s.resolve);
      s.reject = (function (orig) { return function (e) { orig(e); done(); }; })(s.reject);
    });
  };

  UciEngine.prototype.isSearching = function () { return !!this._search; };

  UciEngine.prototype.shutdown = function () {
    try { this._send('quit'); } catch (e) { /* ignore */ }
    try { this.t.stop(); } catch (e) { /* ignore */ }
    this._failAll(new EngineError('exited', 'Engine shut down'));
    this.state = 'idle';
  };

  return {
    START_FEN: START_FEN,
    UciEngine: UciEngine,
    EngineError: EngineError,
    parseInfo: parseInfo,
    parseOption: parseOption,
    parseBestmove: parseBestmove,
    scoreToWhite: scoreToWhite,
    formatScore: formatScore,
    whitePercent: whitePercent,
    positionCommand: positionCommand,
    goCommand: goCommand,
    uciMovesFromHistory: uciMovesFromHistory
  };
});
