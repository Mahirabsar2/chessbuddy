/* ChessBuddy AI model registry helpers: human-readable names and shared key slots. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CBModels = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  var cap = function (w) { return w ? w.charAt(0).toUpperCase() + w.slice(1) : w; };

  /** "claude-sonnet-5-5" -> "Claude Sonnet 5.5", "gpt-4o-mini" -> "GPT-4o Mini", "google/gemini-2.5-pro" -> "Gemini 2.5 Pro" */
  function prettyModelName(id) {
    var s = String(id || '').trim();
    if (!s) return 'Model';
    s = s.replace(/^.*\//, '').replace(/:latest$/, '').replace(/[-_]\d{8}$/, '').replace(/@.*$/, '');
    var parts = s.split(/[-_ ]+/).filter(Boolean), out = [];
    parts.forEach(function (p) {
      if (/^\d+$/.test(p) && out.length && /^\d+(\.\d+)*$/.test(out[out.length - 1])) out[out.length - 1] += '.' + p;
      else out.push(p);
    });
    if (out.length && out[0].toLowerCase() === 'gpt') {
      var head = 'GPT' + (out[1] ? '-' + out[1] : '');
      return [head].concat(out.slice(2).map(cap)).join(' ');
    }
    return out.map(function (w) { return /^\d/.test(w) ? w : cap(w); }).join(' ');
  }

  function hostOf(url) { var m = /^[a-z]+:\/\/([^\/?#]+)/i.exec(url || ''); return m ? m[1].toLowerCase().replace(/:\d+$/, '') : ''; }
  /** One API key per provider account (provider + host), shared by all models on that account. */
  function keyId(provider, baseUrl) {
    return 'k_' + provider + '_' + (hostOf(baseUrl) || 'default').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  }
  function displayName(m) { return (m && m.label && m.label.trim()) || prettyModelName(m && m.model); }
  function providerLabel(m) { return m.provider === 'anthropic' ? 'Anthropic' : (hostOf(m.baseUrl) || 'OpenAI-compatible'); }

  var ANTHROPIC = 'https://api.anthropic.com/v1';
  function defaultModels() {
    return [
      { id: 'm_sonnet', provider: 'anthropic', baseUrl: ANTHROPIC, model: 'claude-sonnet-5-5', label: '', tokenParam: 'auto', vision: true },
      { id: 'm_haiku', provider: 'anthropic', baseUrl: ANTHROPIC, model: 'claude-haiku-5-5', label: '', tokenParam: 'auto', vision: true },
      { id: 'm_opus', provider: 'anthropic', baseUrl: ANTHROPIC, model: 'claude-opus-5-5', label: '', tokenParam: 'auto', vision: true }
    ];
  }
  function newId() { return 'm_' + Date.now().toString(36) + Math.floor(Math.random() * 1296).toString(36); }

  return { prettyModelName: prettyModelName, keyId: keyId, displayName: displayName, providerLabel: providerLabel, defaultModels: defaultModels, hostOf: hostOf, newId: newId };
});
