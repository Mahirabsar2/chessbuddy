/* ChessBuddy board screenshot: renders the current position to a PNG (canvas) for vision-capable models.
 * Coordinates are drawn outside the board; the last move is highlighted; White is at the bottom
 * unless `flipped` is set. */
(function (root) {
  'use strict';
  var cache = null;
  function loadPieces(px) {
    if (cache && cache.px === px) return cache.p;
    var p = {}, jobs = [];
    ['w', 'b'].forEach(function (c) {
      'pnbrqk'.split('').forEach(function (t) {
        jobs.push(new Promise(function (res, rej) {
          var img = new Image();
          img.onload = function () { p[c + t] = img; res(); };
          img.onerror = function () { rej(new Error('piece image failed')); };
          img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(root.CBPieces.standalone(c, t, px));
        }));
      });
    });
    cache = { px: px, p: Promise.all(jobs).then(function () { return p; }) };
    return cache.p;
  }

  /** o: { size (board px, default 560), flipped, last:{from,to}|null } -> Promise<{mediaType, data, dataUrl, width, height}> */
  function render(chess, o) {
    o = o || {};
    var S = o.size || 560, M = Math.round(S * 0.06), sq = S / 8, W = S + 2 * M;
    return loadPieces(Math.round(sq)).then(function (pieces) {
      var cv = document.createElement('canvas'); cv.width = W; cv.height = W;
      var g = cv.getContext('2d');
      g.fillStyle = '#262522'; g.fillRect(0, 0, W, W);
      g.font = 'bold ' + Math.round(M * 0.62) + 'px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#d8d6d2';
      var board = chess.board(), files = 'abcdefgh';
      for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++) {
        var rank = o.flipped ? r : 7 - r, file = o.flipped ? 7 - c : c;
        var name = files[file] + (rank + 1);
        var x = M + c * sq, y = M + r * sq;
        g.fillStyle = (rank + file) % 2 === 0 ? '#739552' : '#ebecd0'; g.fillRect(x, y, sq, sq);
        if (o.last && (o.last.from === name || o.last.to === name)) { g.fillStyle = 'rgba(255,235,59,0.55)'; g.fillRect(x, y, sq, sq); }
        var p = board[7 - rank][file];
        if (p) g.drawImage(pieces[p.color + p.type], x, y, sq, sq);
      }
      g.fillStyle = '#d8d6d2';
      for (var i = 0; i < 8; i++) {
        var f = o.flipped ? 7 - i : i, rk = o.flipped ? i + 1 : 8 - i;
        g.fillText(files[f], M + i * sq + sq / 2, W - M / 2);
        g.fillText(files[f], M + i * sq + sq / 2, M / 2);
        g.fillText(String(rk), M / 2, M + i * sq + sq / 2);
        g.fillText(String(rk), W - M / 2, M + i * sq + sq / 2);
      }
      var url = cv.toDataURL('image/png');
      return { mediaType: 'image/png', data: url.split(',')[1], dataUrl: url, width: W, height: W };
    });
  }
  root.CBSnapshot = { render: render };
})(window);
