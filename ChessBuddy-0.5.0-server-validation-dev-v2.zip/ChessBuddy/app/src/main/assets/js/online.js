/* ChessBuddy private friend-play client. Uses the native HTTP bridge; no browser fetch or service-role key. */
(function (root) {
  'use strict';
  var URL = 'https://npicptuurxuqxepxzumi.supabase.co';
  var KEY = 'sb_publishable_ZRVaTdi8h8IPoL8srCD6Ww_uCf7smm4';
  var KEY_ID = 'cb_supabase_public';
  var session = null;

  function parse(s) { try { return JSON.parse(s); } catch (_) { return null; } }
  function message(body, fallback) {
    var x = parse(body);
    return x && (x.msg || x.message || x.error_description || x.error) || fallback || 'The server rejected the request.';
  }
  function auth(operation, payload) {
    return root.CBNative.supabaseAuth(operation, payload).promise.then(function (r) {
      if (r.kind) throw new Error(r.message || 'Network error');
      var data = parse(r.body);
      if (r.status < 200 || r.status >= 300) throw new Error(message(r.body, 'Authentication failed (HTTP ' + r.status + ').'));
      if (data && data.access_token) session = { accessToken: data.access_token, user: data.user || (session && session.user) || null };
      if (operation === 'logout') session = null;
      return data || {};
    });
  }
  function headers() {
    if (!session || !session.accessToken) throw new Error('Sign in to use online play.');
    return 'apikey: ' + KEY + '\nAuthorization: Bearer ' + session.accessToken;
  }
  function request(method, path, body) {
    var url = URL + '/rest/v1/' + path;
    var h = headers();
    var handle = method === 'GET' ? root.CBNative.httpGet(url, h) : root.CBNative.http({ keyId: KEY_ID, authScheme: 'none', url: url, extraHeaders: h, body: JSON.stringify(body || {}) });
    return handle.promise.then(function (r) {
      if (r.kind) throw new Error(r.message || 'Online request failed.');
      if (r.status < 200 || r.status >= 300) throw new Error(message(r.body, 'Online request failed (HTTP ' + r.status + ').'));
      return r.body ? (parse(r.body) == null ? r.body : parse(r.body)) : null;
    });
  }
  function rpc(name, args) { return request('POST', 'rpc/' + name, args); }
  function query(table, params) { return request('GET', table + '?' + params); }
  function validatedMove(body) {
    var handle = root.CBNative.http({ keyId: KEY_ID, authScheme: 'none', url: URL + '/functions/v1/chessbuddy-apply-move', extraHeaders: headers(), body: JSON.stringify(body) });
    return handle.promise.then(function (r) {
      if (r.kind) throw new Error(r.message || 'Online move validation failed.');
      var data = parse(r.body);
      if (r.status < 200 || r.status >= 300) throw new Error(message(r.body, 'Move rejected (HTTP ' + r.status + ').'));
      return data || {};
    });
  }
  function signedIn() { return !!(session && session.accessToken && session.user && session.user.id); }

  var api = {
    available: !!(root.CBNative && root.CBNative.available),
    signedIn: signedIn,
    user: function () { return session && session.user || null; },
    signUp: function (email, password) { return auth('signup', { email: email, password: password }); },
    signIn: function (email, password) { return auth('signin', { email: email, password: password }); },
    restore: function () {
      return auth('refresh', {}).catch(function (e) { session = null; throw e; });
    },
    signOut: function () { var token = session && session.accessToken; return auth('logout', { access_token: token || '' }); },
    profile: function () {
      var id = api.user().id;
      return query('chessbuddy_profiles', 'select=user_id,username,display_name&user_id=eq.' + encodeURIComponent(id) + '&limit=1').then(function (rows) { return rows && rows[0] || null; });
    },
    registerProfile: function (username, displayName) {
      return rpc('cb_register_profile', { p_username: username, p_display_name: displayName });
    },
    setPresence: function (status) { return rpc('cb_set_presence', { p_status: status || 'online' }); },
    roster: function () {
      return Promise.all([
        query('chessbuddy_profiles', 'select=user_id,username,display_name&order=username.asc&limit=200'),
        query('chessbuddy_presence', 'select=user_id,status,last_seen&limit=200')
      ]).then(function (both) {
        var presence = {}, cutoff = Date.now() - 120000;
        (both[1] || []).forEach(function (p) { presence[p.user_id] = p; });
        return (both[0] || []).filter(function (p) { return p.user_id !== api.user().id; }).map(function (p) {
          var s = presence[p.user_id], live = !!(s && new Date(s.last_seen).getTime() > cutoff);
          return { user_id: p.user_id, username: p.username, display_name: p.display_name, online: live && s.status === 'online', last_seen: s && s.last_seen || null };
        }).sort(function (a, b) { return Number(b.online) - Number(a.online) || a.display_name.localeCompare(b.display_name); });
      });
    },
    challenges: function () {
      var id = api.user().id, or = encodeURIComponent('(from_user_id.eq.' + id + ',to_user_id.eq.' + id + ')');
      return query('chessbuddy_challenges', 'select=id,from_user_id,to_user_id,time_control,from_color,status,game_id,created_at,expires_at&or=' + or + '&status=eq.pending&expires_at=gte.' + encodeURIComponent(new Date().toISOString()) + '&order=created_at.desc&limit=40');
    },
    sendChallenge: function (userId, timeControl, color) {
      return rpc('cb_send_challenge', { p_to_user: userId, p_time_control: timeControl, p_color: color || 'r' });
    },
    respondChallenge: function (challengeId, accept) {
      return rpc('cb_respond_challenge', { p_challenge_id: challengeId, p_accept: !!accept });
    },
    cancelChallenge: function (challengeId) { return rpc('cb_cancel_challenge', { p_challenge_id: challengeId }); },
    game: function (gameId) {
      return query('chessbuddy_games', 'select=id,white_user_id,black_user_id,time_control,initial_fen,current_fen,pgn,turn_user_id,turn_color,white_ms,black_ms,status,result,winner_user_id,updated_at&id=eq.' + encodeURIComponent(gameId) + '&limit=1').then(function (rows) { return rows && rows[0] || null; });
    },
    activeGames: function () {
      var id = api.user().id, or = encodeURIComponent('(white_user_id.eq.' + id + ',black_user_id.eq.' + id + ')');
      return query('chessbuddy_games', 'select=id,white_user_id,black_user_id,time_control,current_fen,pgn,turn_user_id,turn_color,white_ms,black_ms,status,result,winner_user_id,updated_at&or=' + or + '&status=eq.active&order=updated_at.desc&limit=20');
    },
    resignGame: function (gameId) { return rpc('cb_resign_game', { p_game_id: gameId }); },
    claimTimeout: function (gameId) { return rpc('cb_claim_timeout', { p_game_id: gameId }); },
    applyMove: function (g) {
      if (!g || !g.id || !g.move || !/^[a-h][1-8]$/.test(g.move.from || '') || !/^[a-h][1-8]$/.test(g.move.to || '')) {
        return Promise.reject(new Error('A valid chess move is required.'));
      }
      var promotion = g.move.promotion ? String(g.move.promotion).toLowerCase() : undefined;
      if (promotion && !/^[qrbn]$/.test(promotion)) return Promise.reject(new Error('Invalid promotion piece.'));
      return validatedMove({
        game_id: g.id,
        from: g.move.from,
        to: g.move.to,
        promotion: promotion
      });
    },
    clearMemorySession: function () { session = null; }
  };

  // The publishable key is non-secret; NativeBridge keeps it in app-private encrypted storage for POST transport.
  if (root.CBNative && root.CBNative.available) root.CBNative.setKey(KEY_ID, KEY);
  root.CBOnline = api;
})(typeof window !== 'undefined' ? window : globalThis);
